package com.example.data.payment

import android.app.Activity
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.supabase.SupabaseAuthService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Result of a Google Play Billing Payment.
 */
sealed class PaymentEvent {
    data class Success(val paymentId: String, val planType: String, val amount: Double) : PaymentEvent()
    data class Error(val code: Int, val message: String) : PaymentEvent()
}

/**
 * Google Play Billing Manager.
 * Handles official Google Play In-App Billing / Subscriptions securely.
 * Automatically syncs verified purchases with Supabase backend (`profiles` & `app_subscriptions`).
 */
object GooglePlayBillingManager : PurchasesUpdatedListener {
    private const val TAG = "GooglePlayBillingManager"

    // Google Play Console Product IDs for Subscriptions
    const val PRODUCT_ID_MONTHLY = "vip_monthly_subscription"
    const val PRODUCT_ID_YEARLY = "vip_yearly_subscription"

    private val _paymentEvents = MutableSharedFlow<PaymentEvent>(replay = 0)
    val paymentEvents = _paymentEvents.asSharedFlow()

    private var billingClient: BillingClient? = null
    private var activeAppContext: Context? = null
    private var pendingPlanType: String = "MONTHLY"
    private var pendingAmount: Double = 49.0
    private var lastUserPhone: String = ""

    fun init(context: Context) {
        if (billingClient != null) return
        activeAppContext = context.applicationContext
        billingClient = BillingClient.newBuilder(context.applicationContext)
            .setListener(this)
            .enablePendingPurchases()
            .build()

        connectToPlayStore()
    }

    private fun connectToPlayStore() {
        billingClient?.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    Log.d(TAG, "Google Play Billing setup successful.")
                } else {
                    Log.w(TAG, "Google Play Billing setup failed: ${billingResult.debugMessage}")
                }
            }

            override fun onBillingServiceDisconnected() {
                Log.w(TAG, "Google Play Billing service disconnected. Retrying...")
                // Retry connection if needed
            }
        })
    }

    /**
     * Launch Google Play Billing purchase flow for Monthly or Yearly VIP subscription.
     */
    fun startPurchase(
        activity: Activity,
        planType: String,
        amountRupees: Double,
        userPhone: String = "",
        userEmail: String = ""
    ) {
        pendingPlanType = planType
        pendingAmount = amountRupees
        lastUserPhone = userPhone
        activeAppContext = activity.applicationContext

        val productId = if (planType.contains("YEAR", ignoreCase = true)) PRODUCT_ID_YEARLY else PRODUCT_ID_MONTHLY

        val client = billingClient ?: run {
            init(activity)
            billingClient
        } ?: run {
            Toast.makeText(activity, "Google Play Billing client unavailable", Toast.LENGTH_SHORT).show()
            return
        }

        if (!client.isReady) {
            Log.w(TAG, "BillingClient not ready. Reconnecting...")
            client.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(result: BillingResult) {
                    if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                        queryAndLaunch(activity, productId)
                    } else {
                        Toast.makeText(activity, "Google Play से कनेक्ट नहीं हो सका। कृपया पुनः प्रयास करें।", Toast.LENGTH_LONG).show()
                    }
                }
                override fun onBillingServiceDisconnected() {}
            })
            return
        }

        queryAndLaunch(activity, productId)
    }

    private fun queryAndLaunch(activity: Activity, productId: String) {
        val client = billingClient ?: return
        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()

        client.queryProductDetailsAsync(params) { billingResult, productDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && !productDetailsList.isNullOrEmpty()) {
                val productDetails = productDetailsList[0]
                val offerToken = productDetails.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: ""

                val productDetailsParamsList = listOf(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(productDetails)
                        .setOfferToken(offerToken)
                        .build()
                )

                val billingFlowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(productDetailsParamsList)
                    .build()

                activity.runOnUiThread {
                    val responseCode = client.launchBillingFlow(activity, billingFlowParams).responseCode
                    if (responseCode != BillingClient.BillingResponseCode.OK) {
                        Toast.makeText(activity, "बilling flow शुरू करने में त्रुटि (Code: $responseCode)", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                Log.e(TAG, "Product not found in Google Play Console: $productId. Result: ${billingResult.debugMessage}")
                activity.runOnUiThread {
                    Toast.makeText(activity, "उत्पाद (Product ID: $productId) Google Play पर उपलब्ध नहीं है।", Toast.LENGTH_LONG).show()
                    CoroutineScope(Dispatchers.Main).launch {
                        _paymentEvents.emit(PaymentEvent.Error(billingResult.responseCode, "Product not found: $productId"))
                    }
                }
            }
        }
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: List<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && !purchases.isNullOrEmpty()) {
            for (purchase in purchases) {
                handlePurchase(purchase)
            }
        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            Log.i(TAG, "User canceled the purchase.")
            CoroutineScope(Dispatchers.Main).launch {
                _paymentEvents.emit(PaymentEvent.Error(BillingClient.BillingResponseCode.USER_CANCELED, "पेमेंट रद्द कर दिया गया।"))
            }
        } else {
            Log.w(TAG, "Purchase failed or error: ${billingResult.responseCode} - ${billingResult.debugMessage}")
            CoroutineScope(Dispatchers.Main).launch {
                _paymentEvents.emit(PaymentEvent.Error(billingResult.responseCode, billingResult.debugMessage ?: "खरीद विफल"))
            }
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            val purchaseToken = purchase.purchaseToken
            val orderId = purchase.orderId ?: "GP_${System.currentTimeMillis()}"
            val isYearly = purchase.products.any { it.contains("year", ignoreCase = true) }
            val planType = if (isYearly) "YEARLY" else "MONTHLY"
            val daysToAdd = if (isYearly) 365 else 30

            // Acknowledge purchase if not already acknowledged
            if (!purchase.isAcknowledged) {
                val acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchaseToken)
                    .build()
                billingClient?.acknowledgePurchase(acknowledgePurchaseParams) { billingResult ->
                    if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        Log.d(TAG, "Purchase acknowledged successfully.")
                    }
                }
            }

            val context = activeAppContext
            if (context != null) {
                // 1. Locally update subscription days in SharedPreferences
                val newTotalDays = RemoteConfigService.addVipSubscription(
                    context = context,
                    planType = planType,
                    daysToAdd = daysToAdd,
                    phone = lastUserPhone
                )
                val expiryTimestamp = RemoteConfigService.vipExpiryTimestamp.value

                // 2. Securely sync/verify subscription with Supabase backend so Supabase remains source of truth
                val phoneToSync = lastUserPhone
                CoroutineScope(Dispatchers.IO).launch {
                    syncSubscriptionToSupabase(
                        context = context,
                        paymentId = orderId,
                        planType = planType,
                        amount = pendingAmount,
                        phone = phoneToSync,
                        daysAdded = daysToAdd,
                        totalDaysRemaining = newTotalDays,
                        expiryTimestamp = expiryTimestamp,
                        purchaseToken = purchaseToken
                    )
                }
            }

            CoroutineScope(Dispatchers.Main).launch {
                _paymentEvents.emit(PaymentEvent.Success(orderId, planType, pendingAmount))
            }
        }
    }

    /**
     * Securely syncs and updates the subscription status in Supabase backend tables (`profiles` & `app_subscriptions`).
     */
    private suspend fun syncSubscriptionToSupabase(
        context: Context,
        paymentId: String,
        planType: String,
        amount: Double,
        phone: String,
        daysAdded: Int,
        totalDaysRemaining: Int,
        expiryTimestamp: Long,
        purchaseToken: String
    ) {
        if (!SupabaseAuthService.isConfigured(context)) return
        val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
        val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)

        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val isoExpiry = sdf.format(Date(expiryTimestamp))

        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").trim()
        if (cleanPhone.length >= 6) {
            try {
                val encodedPhone = java.net.URLEncoder.encode("*$cleanPhone*", "UTF-8")
                val profileEndpoint = "$baseUrl/rest/v1/profiles?phone=ilike.$encodedPhone"
                val profileConn = (URL(profileEndpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "PATCH"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "return=minimal")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }
                val profileBody = JSONObject().apply {
                    put("vip_member", true)
                    put("is_premium", true)
                    put("vip_plan", planType)
                    put("vip_days_remaining", totalDaysRemaining)
                    put("vip_expiry", isoExpiry)
                    put("updated_at", System.currentTimeMillis())
                }
                OutputStreamWriter(profileConn.outputStream).use { it.write(profileBody.toString()) }
                val pCode = profileConn.responseCode
                Log.d(TAG, "Supabase profiles VIP updated via Google Play Billing, code: $pCode, days: $totalDaysRemaining")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to update profiles VIP columns: ${e.message}")
            }
        }

        // Insert into app_subscriptions / user_subscriptions table
        val targetTables = listOf("app_subscriptions", "user_subscriptions")
        for (tbl in targetTables) {
            try {
                val endpoint = "$baseUrl/rest/v1/$tbl"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "return=minimal")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }

                val body = JSONObject().apply {
                    put("payment_id", paymentId)
                    put("phone", phone)
                    put("plan_type", planType)
                    put("amount", amount)
                    put("days_added", daysAdded)
                    put("total_days_remaining", totalDaysRemaining)
                    put("expires_at", isoExpiry)
                    put("is_premium", true)
                    put("is_active", true)
                    put("payment_status", "SUCCESS")
                    put("platform", "GOOGLE_PLAY_BILLING")
                    put("purchase_token", purchaseToken)
                }

                OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
                val code = conn.responseCode
                Log.d(TAG, "Supabase $tbl Google Play sync response code: $code")
                if (code in 200..299) break
            } catch (e: Exception) {
                Log.w(TAG, "Failed to insert into $tbl: ${e.message}")
            }
        }
    }
}
