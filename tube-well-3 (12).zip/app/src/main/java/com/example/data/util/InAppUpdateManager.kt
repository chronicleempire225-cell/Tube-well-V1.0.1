package com.example.data.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

/**
 * UI State for Google Play Flexible In-App Updates.
 */
sealed class AppUpdateUiState {
    data object Idle : AppUpdateUiState()
    data class UpdateAvailable(val availableVersionCode: Int) : AppUpdateUiState()
    data class Downloading(val progressPercent: Int) : AppUpdateUiState()
    data object ReadyToInstall : AppUpdateUiState()
}

/**
 * Official Google Play Flexible In-App Update Manager.
 *
 * Key behavior:
 * 1. Automatically queries Google Play Store for newer versions (no hardcoded version numbers needed).
 * 2. Shows a friendly non-blocking popup with a large Close ("बंद करें / बाद में") button.
 * 3. Respects a 24-hour cooldown when the user dismisses the popup so it never nags repeatedly.
 * 4. Downloads updates in the background (FLEXIBLE mode) while the user continues using the app.
 * 5. Prompts to restart once downloaded (and re-checks on onResume so downloaded updates aren't left hanging).
 * 6. 100% crash-safe on emulators, offline devices, and sideloaded builds.
 */
object InAppUpdateManager {
    private const val TAG = "InAppUpdateManager"
    private const val PREFS_NAME = "bahi_khata_app_update_prefs"
    private const val KEY_DISMISSED_VERSION = "dismissed_version_code"
    private const val KEY_DISMISSED_AT_MS = "dismissed_at_ms"
    private const val DISMISS_COOLDOWN_MS = 24L * 60L * 60L * 1000L // 24 hours

    private var appUpdateManager: AppUpdateManager? = null
    private var cachedUpdateInfo: AppUpdateInfo? = null
    private var launcherRef: WeakReference<ActivityResultLauncher<IntentSenderRequest>>? = null
    private var isListenerRegistered = false

    private val _uiState = MutableStateFlow<AppUpdateUiState>(AppUpdateUiState.Idle)
    val uiState: StateFlow<AppUpdateUiState> = _uiState.asStateFlow()

    private val _showUpdateDialog = MutableStateFlow(false)
    val showUpdateDialog: StateFlow<Boolean> = _showUpdateDialog.asStateFlow()

    private val _isDownloadBannerDismissed = MutableStateFlow(false)
    val isDownloadBannerDismissed: StateFlow<Boolean> = _isDownloadBannerDismissed.asStateFlow()

    private val installStateListener = InstallStateUpdatedListener { state ->
        try {
            when (state.installStatus()) {
                InstallStatus.DOWNLOADING -> {
                    val downloaded = state.bytesDownloaded()
                    val total = state.totalBytesToDownload()
                    val percent = if (total > 0L) {
                        ((downloaded * 100L) / total).toInt().coerceIn(0, 100)
                    } else {
                        0
                    }
                    _uiState.value = AppUpdateUiState.Downloading(percent)
                }
                InstallStatus.DOWNLOADED -> {
                    _isDownloadBannerDismissed.value = false
                    _showUpdateDialog.value = false
                    _uiState.value = AppUpdateUiState.ReadyToInstall
                }
                InstallStatus.INSTALLED,
                InstallStatus.CANCELED,
                InstallStatus.FAILED -> {
                    _uiState.value = AppUpdateUiState.Idle
                }
                else -> {}
            }
        } catch (t: Throwable) {
            Log.w(TAG, "InstallStateUpdatedListener error safely caught: ${t.message}")
        }
    }

    private fun isPlayStoreAvailable(context: Context): Boolean {
        return try {
            val info = context.applicationContext.packageManager.getApplicationInfo("com.android.vending", 0)
            info.enabled
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Initializes the Play AppUpdateManager and registers the ActivityResultLauncher.
     * Call cleanly after first UI frame from MainActivity.
     */
    fun init(
        context: Context,
        launcher: ActivityResultLauncher<IntentSenderRequest>
    ) {
        launcherRef = WeakReference(launcher)
        if (!isPlayStoreAvailable(context)) {
            Log.d(TAG, "Google Play Store not available on this device/emulator — skipping automatic update check.")
            return
        }
        try {
            val manager = appUpdateManager ?: AppUpdateManagerFactory.create(context.applicationContext).also {
                appUpdateManager = it
            }
            if (!isListenerRegistered) {
                manager.registerListener(installStateListener)
                isListenerRegistered = true
            }
            // Silent automatic background check on launch
            checkForUpdate(context.applicationContext, forcePrompt = false)
        } catch (t: Throwable) {
            Log.w(TAG, "InAppUpdateManager init failed safely (likely emulator/no Play Store): ${t.message}")
        }
    }

    /**
     * Checks Google Play for an available update.
     *
     * @param forcePrompt true when user taps "Check for Update" in Settings (bypasses 24h cooldown
     *                    and displays feedback if already up to date).
     */
    fun checkForUpdate(
        context: Context,
        forcePrompt: Boolean = false,
        onManualCheckFinished: ((hasUpdate: Boolean, message: String) -> Unit)? = null
    ) {
        val appContext = context.applicationContext
        if (!isPlayStoreAvailable(appContext)) {
            if (forcePrompt) {
                onManualCheckFinished?.invoke(
                    false,
                    "इस डिवाइस पर Play Store उपलब्ध नहीं है (वर्तमान वर्ज़न v${getCurrentVersionName()})।"
                )
            }
            return
        }
        try {
            val manager = appUpdateManager ?: AppUpdateManagerFactory.create(appContext).also {
                appUpdateManager = it
            }
            if (!isListenerRegistered) {
                manager.registerListener(installStateListener)
                isListenerRegistered = true
            }

            manager.appUpdateInfo
                .addOnSuccessListener { info ->
                    try {
                        // 1. If a flexible update already finished downloading, immediately invite user to install
                        if (info.installStatus() == InstallStatus.DOWNLOADED) {
                            cachedUpdateInfo = info
                            _isDownloadBannerDismissed.value = false
                            _showUpdateDialog.value = false
                            _uiState.value = AppUpdateUiState.ReadyToInstall
                            onManualCheckFinished?.invoke(true, "नया अपडेट डाउनलोड होकर इंस्टॉल के लिए तैयार है!")
                            return@addOnSuccessListener
                        }

                        // 2. Check if Play Store has a newer version available for Flexible update
                        val isUpdateAvailable =
                            info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                                info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)

                        if (isUpdateAvailable) {
                            cachedUpdateInfo = info
                            val availableCode = info.availableVersionCode()
                            _uiState.value = AppUpdateUiState.UpdateAvailable(availableCode)

                            if (forcePrompt || shouldShowPromptForVersion(appContext, availableCode)) {
                                _showUpdateDialog.value = true
                            }
                            onManualCheckFinished?.invoke(true, "नया अपडेट उपलब्ध है!")
                        } else {
                            if (forcePrompt) {
                                onManualCheckFinished?.invoke(
                                    false,
                                    "आप पहले से नवीनतम वर्ज़न (v${getCurrentVersionName()}) इस्तेमाल कर रहे हैं।"
                                )
                            }
                        }
                    } catch (t: Throwable) {
                        Log.w(TAG, "Error handling appUpdateInfo: ${t.message}")
                        if (forcePrompt) {
                            onManualCheckFinished?.invoke(
                                false,
                                "आप नवीनतम वर्ज़न (v${getCurrentVersionName()}) इस्तेमाल कर रहे हैं।"
                            )
                        }
                    }
                }
                .addOnFailureListener { e ->
                    // Normal on emulators, debug/sideloaded builds, or offline devices — never crash
                    Log.d(TAG, "Play In-App Update check unavailable: ${e.message}")
                    if (forcePrompt) {
                        onManualCheckFinished?.invoke(
                            false,
                            "नया अपडेट जांचने के लिए Play Store खोलें (वर्ज़न v${getCurrentVersionName()})।"
                        )
                    }
                }
        } catch (t: Throwable) {
            Log.w(TAG, "checkForUpdate failed safely: ${t.message}")
            if (forcePrompt) {
                onManualCheckFinished?.invoke(
                    false,
                    "वर्तमान वर्ज़न v${getCurrentVersionName()} है।"
                )
            }
        }
    }

    /**
     * Re-checks on Activity.onResume() so any update that finished downloading while the user
     * was away is surfaced cleanly for installation.
     */
    fun checkOnResume(context: Context) {
        try {
            val manager = appUpdateManager ?: return
            manager.appUpdateInfo.addOnSuccessListener { info ->
                try {
                    if (info.installStatus() == InstallStatus.DOWNLOADED) {
                        cachedUpdateInfo = info
                        _isDownloadBannerDismissed.value = false
                        _showUpdateDialog.value = false
                        _uiState.value = AppUpdateUiState.ReadyToInstall
                    }
                } catch (_: Throwable) {}
            }
        } catch (t: Throwable) {
            Log.w(TAG, "checkOnResume failed safely: ${t.message}")
        }
    }

    /**
     * Starts the official Google Play Flexible update flow when the user taps "अभी अपडेट करें".
     * Falls back cleanly to opening the app's Play Store listing if the in-app flow cannot launch.
     */
    fun startFlexibleUpdate(context: Context) {
        _showUpdateDialog.value = false
        val manager = appUpdateManager
        val info = cachedUpdateInfo
        val launcher = launcherRef?.get()

        if (manager != null && info != null && launcher != null) {
            try {
                val options = AppUpdateOptions.newBuilder(AppUpdateType.FLEXIBLE).build()
                val started = manager.startUpdateFlowForResult(info, launcher, options)
                if (started) {
                    _isDownloadBannerDismissed.value = false
                    return
                }
            } catch (t: Throwable) {
                Log.w(TAG, "startUpdateFlowForResult failed, opening Play Store fallback: ${t.message}")
            }
        }

        openPlayStoreListing(context)
    }

    /**
     * Handles the ActivityResult returned by Google Play's update consent sheet.
     */
    fun onUpdateFlowResult(resultCode: Int, context: Context) {
        if (resultCode != Activity.RESULT_OK) {
            // User cancelled Play's consent dialog — respect their choice cleanly
            val version = cachedUpdateInfo?.availableVersionCode() ?: 0
            dismissUpdatePrompt(context, version)
        }
    }

    /**
     * Completes and installs an already-downloaded flexible update (restarts the app cleanly).
     */
    fun completeDownloadedUpdate(context: Context) {
        try {
            appUpdateManager?.completeUpdate()
        } catch (t: Throwable) {
            Log.w(TAG, "completeUpdate failed safely: ${t.message}")
            openPlayStoreListing(context)
        }
    }

    /**
     * Dismisses the update popup cleanly when the user taps the big Close ("बंद करें") button
     * and sets a 24-hour cooldown for that version so it doesn't nag on every launch.
     */
    fun dismissUpdatePrompt(context: Context, versionCode: Int? = null) {
        _showUpdateDialog.value = false
        val codeToSave = versionCode ?: (uiState.value as? AppUpdateUiState.UpdateAvailable)?.availableVersionCode ?: 0
        try {
            context.applicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_DISMISSED_VERSION, codeToSave)
                .putLong(KEY_DISMISSED_AT_MS, System.currentTimeMillis())
                .apply()
        } catch (_: Throwable) {}
    }

    /**
     * Dismisses the floating download / ready-to-install banner without interrupting the user.
     */
    fun dismissBanner() {
        _isDownloadBannerDismissed.value = true
    }

    /**
     * Returns true if the update dialog should be shown automatically for the given version code.
     */
    internal fun shouldShowPromptForVersion(
        context: Context,
        availableVersionCode: Int,
        nowMs: Long = System.currentTimeMillis()
    ): Boolean {
        return try {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val dismissedVersion = prefs.getInt(KEY_DISMISSED_VERSION, -1)
            val dismissedAt = prefs.getLong(KEY_DISMISSED_AT_MS, 0L)
            if (dismissedVersion != availableVersionCode) {
                true
            } else {
                (nowMs - dismissedAt) >= DISMISS_COOLDOWN_MS
            }
        } catch (_: Throwable) {
            true
        }
    }

    /**
     * Opens the app's Google Play Store listing safely (fallback or manual check).
     */
    fun openPlayStoreListing(context: Context) {
        val pkg = context.packageName
        try {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(marketIntent)
        } catch (_: Throwable) {
            try {
                val webIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$pkg")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            } catch (_: Throwable) {
                try {
                    Toast.makeText(context, "Play Store नहीं खुल सका।", Toast.LENGTH_SHORT).show()
                } catch (_: Throwable) {}
            }
        }
    }

    fun getCurrentVersionName(): String {
        return try {
            com.example.BuildConfig.VERSION_NAME
        } catch (_: Throwable) {
            "1.0.16"
        }
    }

    fun cleanup(launcher: ActivityResultLauncher<IntentSenderRequest>? = null) {
        if (launcher != null && launcherRef?.get() != null && launcherRef?.get() !== launcher) {
            return
        }
        try {
            if (isListenerRegistered) {
                appUpdateManager?.unregisterListener(installStateListener)
                isListenerRegistered = false
            }
        } catch (_: Throwable) {}
        launcherRef = null
    }
}
