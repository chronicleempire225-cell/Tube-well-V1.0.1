# ===================================================================
# ProGuard / R8 Rules for Digital Bahi Khata
# Enables DEX Code Optimization & Obfuscation for Google Play
# ===================================================================

# Preserve source file names and line numbers for de-obfuscation and crash analysis
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,Exceptions

# -------------------------------------------------------------------
# Android Architecture Components & Room Database
# -------------------------------------------------------------------
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keep @androidx.room.Database class * { *; }
-keep class com.example.data.db.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    <init>(...);
}

# SQLCipher Database Encryption
-keep class net.sqlcipher.** { *; }
-keep class net.sqlcipher.database.** { *; }
-keep class net.zetetic.** { *; }
-keep class net.zetetic.database.** { *; }
-dontwarn net.sqlcipher.**
-dontwarn net.zetetic.**

# -------------------------------------------------------------------
# Networking, Moshi & Retrofit
# -------------------------------------------------------------------
-keepclassmembers class * {
    @com.squareup.moshi.* <fields>;
    @com.squareup.moshi.* <methods>;
}
-keep class com.squareup.moshi.** { *; }
-dontwarn com.squareup.moshi.**
-keepclassmembers enum * { *; }
-keep class retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}
-dontwarn retrofit2.**
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**

# -------------------------------------------------------------------
# Razorpay Checkout
# -------------------------------------------------------------------
-keep class com.razorpay.** { *; }
-dontwarn com.razorpay.**
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# -------------------------------------------------------------------
# Kotlin Coroutines & Serialization
# -------------------------------------------------------------------
-dontwarn kotlinx.coroutines.**
-keep class kotlinx.coroutines.** { *; }

# -------------------------------------------------------------------
# WorkManager Background Workers
# -------------------------------------------------------------------
-keep class * extends androidx.work.Worker { *; }
-keep class * extends androidx.work.CoroutineWorker { *; }
-keep class * extends androidx.work.ListenableWorker { *; }
-keep class com.example.data.service.** { *; }

# -------------------------------------------------------------------
# Google Mobile Ads (AdMob)
# -------------------------------------------------------------------
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.ads.**
-keep class com.google.ads.mediation.** { *; }

# -------------------------------------------------------------------
# Application Domain, Services & Security Layers
# -------------------------------------------------------------------
-keep class com.example.data.models.** { *; }
-keep class com.example.data.local.** { *; }
-keep class com.example.data.remoteconfig.** { *; }
-keep class com.example.data.security.** { *; }
-keep class com.example.data.supabase.** { *; }
-keep class com.example.data.payment.** { *; }
-keep class com.example.data.pdf.** { *; }
-keep class com.example.data.util.** { *; }
-keep class com.example.data.gemini.** { *; }
-keep class com.example.data.localization.** { *; }
-keep class com.example.data.repository.** { *; }
-keep class com.example.ui.viewmodel.** { *; }

# -------------------------------------------------------------------
# Jetpack Compose
# -------------------------------------------------------------------
-dontwarn androidx.compose.**

