package com.example

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.AppDatabase
import com.example.data.remoteconfig.RewardedAdManager
import com.example.data.service.LivePumpTimerService
import com.example.data.service.LiveTimerManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Tubewell Bahi Khata", appName)
  }

  @Test
  fun `MainActivity launches and resumes cleanly without crashing`() {
    val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
    val activity = controller.get()
    assertNotNull(activity)
    assertFalse(activity.isFinishing)
    controller.pause().stop().destroy()
  }

  @Test
  fun `RewardedAdManager preload from background thread never crashes`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val errorRef = AtomicReference<Throwable?>(null)
    val latch = CountDownLatch(1)

    Thread {
      try {
        RewardedAdManager.preload(context)
      } catch (t: Throwable) {
        errorRef.set(t)
      } finally {
        latch.countDown()
      }
    }.start()

    assertTrue(latch.await(5, TimeUnit.SECONDS))
    assertEquals(null, errorRef.get())
  }

  @Test
  fun `LiveTimerManager stop uses stopService instead of startForegroundService`() {
    val app = ApplicationProvider.getApplicationContext<DigitalBahiKhataApplication>()
    val shadowApp = Shadows.shadowOf(app)
    shadowApp.clearStartedServices()

    LiveTimerManager.start(app, "cust_1", "रामू किसान", 200.0, 60L)
    shadowApp.clearStartedServices()

    LiveTimerManager.stop(app)

    // Ensure stop() did NOT call startService/startForegroundService with ACTION_STOP
    val nextStarted = shadowApp.nextStartedService
    assertEquals(null, nextStarted)
    val stoppedIntent = shadowApp.nextStoppedService
    assertNotNull(stoppedIntent)
    assertEquals(LivePumpTimerService::class.java.name, stoppedIntent.component?.className)
  }

  @Test
  fun `AppDatabase opens lazily and falls back cleanly without native sqlcipher`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = AppDatabase.getDatabase(context)
    assertNotNull(db)
    assertNotNull(db.openHelper.writableDatabase)
  }

  @Test
  fun `InAppUpdateManager respects 24h dismiss cooldown and resets for newer version`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val v17 = 17
    val v18 = 18

    // Initially should prompt for v17
    assertTrue(com.example.data.util.InAppUpdateManager.shouldShowPromptForVersion(context, v17))

    // User taps the big Close button -> suppresses prompt for v17 immediately
    com.example.data.util.InAppUpdateManager.dismissUpdatePrompt(context, v17)
    val now = System.currentTimeMillis()
    assertFalse(com.example.data.util.InAppUpdateManager.shouldShowPromptForVersion(context, v17, now + 60_000L))

    // After 24+ hours, v17 may prompt again
    val after25Hours = now + (25L * 60L * 60L * 1000L)
    assertTrue(com.example.data.util.InAppUpdateManager.shouldShowPromptForVersion(context, v17, after25Hours))

    // If a brand new version (v18) launches, it prompts immediately even within 24h
    assertTrue(com.example.data.util.InAppUpdateManager.shouldShowPromptForVersion(context, v18, now + 60_000L))
  }

  @Test
  fun `InAppUpdateManager checkForUpdate never crashes in emulator or offline environment`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    com.example.data.util.InAppUpdateManager.checkForUpdate(context, forcePrompt = false)
    assertNotNull(com.example.data.util.InAppUpdateManager.getCurrentVersionName())
  }

}
