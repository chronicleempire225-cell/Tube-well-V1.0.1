package com.example.data.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * SharedPreferences storage for storing persistent timer state.
 * Survives app kills, process termination, phone restarts, and app clears from recents.
 */
object LiveTimerPreferences {
    private const val PREFS_NAME = "bahi_khata_live_timer_prefs"
    private const val KEY_IS_RUNNING = "key_is_running"
    private const val KEY_IS_PAUSED = "key_is_paused"
    private const val KEY_START_TIME_MS = "key_start_time_ms"
    private const val KEY_ACCUMULATED_SECS = "key_accumulated_secs"
    private const val KEY_CUSTOMER_ID = "key_customer_id"
    private const val KEY_CUSTOMER_NAME = "key_customer_name"
    private const val KEY_RATE_PER_HOUR = "key_rate_per_hour"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun saveTimerState(
        context: Context,
        isRunning: Boolean,
        isPaused: Boolean,
        startTimeMs: Long,
        accumulatedSecs: Long,
        customerId: String?,
        customerName: String,
        ratePerHour: Double
    ) {
        getPrefs(context).edit()
            .putBoolean(KEY_IS_RUNNING, isRunning)
            .putBoolean(KEY_IS_PAUSED, isPaused)
            .putLong(KEY_START_TIME_MS, startTimeMs)
            .putLong(KEY_ACCUMULATED_SECS, accumulatedSecs)
            .putString(KEY_CUSTOMER_ID, customerId ?: "")
            .putString(KEY_CUSTOMER_NAME, customerName)
            .putFloat(KEY_RATE_PER_HOUR, ratePerHour.toFloat())
            .apply()
    }

    fun getIsRunning(context: Context): Boolean = getPrefs(context).getBoolean(KEY_IS_RUNNING, false)
    fun getIsPaused(context: Context): Boolean = getPrefs(context).getBoolean(KEY_IS_PAUSED, false)
    fun getStartTimeMs(context: Context): Long = getPrefs(context).getLong(KEY_START_TIME_MS, 0L)
    fun getAccumulatedSecs(context: Context): Long = getPrefs(context).getLong(KEY_ACCUMULATED_SECS, 0L)
    fun getCustomerId(context: Context): String? = getPrefs(context).getString(KEY_CUSTOMER_ID, null)?.takeIf { it.isNotBlank() }
    fun getCustomerName(context: Context): String = getPrefs(context).getString(KEY_CUSTOMER_NAME, "") ?: ""
    fun getRatePerHour(context: Context): Double = getPrefs(context).getFloat(KEY_RATE_PER_HOUR, 160f).toDouble()

    fun clear(context: Context) {
        getPrefs(context).edit().clear().apply()
    }
}

/**
 * Central In-Memory & Persistent Live Timer Manager.
 * Uses real wall-clock timestamps (`System.currentTimeMillis()`) to ensure 100% time accuracy
 * even if the app process is terminated or backgrounded.
 */
object LiveTimerManager {
    private const val TAG = "LiveTimerManager"

    private val _isRunning = MutableStateFlow(false)
    val isRunning = _isRunning.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused = _isPaused.asStateFlow()

    private val _seconds = MutableStateFlow(0L)
    val seconds = _seconds.asStateFlow()

    private val _customerId = MutableStateFlow<String?>(null)
    val customerId = _customerId.asStateFlow()

    private val _customerName = MutableStateFlow<String>("")
    val customerName = _customerName.asStateFlow()

    private val _ratePerHour = MutableStateFlow(160.0)
    val ratePerHour = _ratePerHour.asStateFlow()

    private var startTimeMillis: Long = 0L
    private var accumulatedSeconds: Long = 0L

    private var tickerJob: Job? = null
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate + CoroutineExceptionHandler { _, t ->
            Log.w(TAG, "LiveTimerManager coroutine error: ${t.message}")
        }
    )
    @Volatile
    private var isInitialized = false

    /**
     * Initializes state from persistent storage upon app startup.
     */
    @Synchronized
    fun init(context: Context, notifyService: Boolean = true) {
        if (isInitialized) return
        isInitialized = true

        val running = LiveTimerPreferences.getIsRunning(context)
        if (running) {
            val paused = LiveTimerPreferences.getIsPaused(context)
            startTimeMillis = LiveTimerPreferences.getStartTimeMs(context)
            accumulatedSeconds = LiveTimerPreferences.getAccumulatedSecs(context)
            _customerId.value = LiveTimerPreferences.getCustomerId(context)
            _customerName.value = LiveTimerPreferences.getCustomerName(context)
            _ratePerHour.value = LiveTimerPreferences.getRatePerHour(context)
            _isRunning.value = true
            _isPaused.value = paused

            updateCalculatedSeconds()

            if (!paused) {
                startTicker(context)
                if (notifyService) startService(context, LivePumpTimerService.ACTION_START)
            } else {
                if (notifyService) startService(context, LivePumpTimerService.ACTION_PAUSE)
            }
        }
    }

    fun start(
        context: Context,
        custId: String,
        custName: String,
        rate: Double,
        initialSecs: Long = 0L
    ) {
        _customerId.value = custId
        _customerName.value = custName
        _ratePerHour.value = rate
        accumulatedSeconds = initialSecs.coerceAtLeast(0L)
        startTimeMillis = System.currentTimeMillis()

        _seconds.value = accumulatedSeconds
        _isRunning.value = true
        _isPaused.value = false

        persistState(context)
        startTicker(context)
        startService(context, LivePumpTimerService.ACTION_START)
    }

    fun pause(context: Context, notifyService: Boolean = true) {
        if (!_isRunning.value || _isPaused.value) return

        // Compute accumulated seconds up to right now
        updateCalculatedSeconds()
        accumulatedSeconds = _seconds.value
        _isPaused.value = true

        tickerJob?.cancel()
        persistState(context)
        if (notifyService) {
            startService(context, LivePumpTimerService.ACTION_PAUSE)
        }
    }

    fun resume(context: Context, notifyService: Boolean = true) {
        if (_isRunning.value && !_isPaused.value) return

        _isRunning.value = true
        _isPaused.value = false
        startTimeMillis = System.currentTimeMillis()

        persistState(context)
        startTicker(context)
        if (notifyService) {
            startService(context, LivePumpTimerService.ACTION_RESUME)
        }
    }

    /**
     * Safely synchronizes the Foreground Service when the app is explicitly in the foreground (e.g., Activity.onResume).
     */
    fun syncServiceIfRunning(context: Context) {
        init(context, notifyService = false)
        if (_isRunning.value) {
            val action = if (_isPaused.value) LivePumpTimerService.ACTION_PAUSE else LivePumpTimerService.ACTION_START
            startService(context, action)
        }
    }

    fun stop(context: Context) {
        _isRunning.value = false
        _isPaused.value = false
        tickerJob?.cancel()

        accumulatedSeconds = 0L
        startTimeMillis = 0L
        _seconds.value = 0L
        _customerId.value = null
        _customerName.value = ""

        LiveTimerPreferences.clear(context)
        // NEVER call startForegroundService(ACTION_STOP) — use stopService to avoid ForegroundServiceDidNotStartInTimeException
        try {
            context.applicationContext.stopService(Intent(context.applicationContext, LivePumpTimerService::class.java))
        } catch (t: Throwable) {
            Log.w(TAG, "Error stopping LivePumpTimerService: ${t.message}")
        }
    }

    fun adjustSeconds(context: Context, delta: Long) {
        val current = _seconds.value
        val updated = (current + delta).coerceAtLeast(0L)
        accumulatedSeconds = updated
        startTimeMillis = System.currentTimeMillis()
        _seconds.value = updated

        persistState(context)
        if (_isRunning.value && !_isPaused.value) {
            startService(context, LivePumpTimerService.ACTION_RESUME)
        } else if (_isRunning.value && _isPaused.value) {
            startService(context, LivePumpTimerService.ACTION_PAUSE)
        }
    }

    fun setCustomerAndRate(context: Context, custId: String, custName: String, rate: Double) {
        if (custId.isNotBlank() && (_customerId.value != custId || _customerName.value != custName || _ratePerHour.value != rate)) {
            _customerId.value = custId
            _customerName.value = custName
            _ratePerHour.value = rate
            persistState(context)
        }
    }

    fun setSeconds(context: Context, newSecs: Long) {
        val cleanSecs = newSecs.coerceAtLeast(0L)
        if (cleanSecs == 0L && (!_isRunning.value || _isPaused.value)) {
            if (_isRunning.value) {
                stop(context)
            } else {
                accumulatedSeconds = 0L
                startTimeMillis = 0L
                _seconds.value = 0L
            }
            return
        }

        accumulatedSeconds = cleanSecs
        startTimeMillis = System.currentTimeMillis()
        _seconds.value = cleanSecs

        // If timer was stopped or not started yet, activate in paused state so user can tap Resume
        if (!_isRunning.value) {
            _isRunning.value = true
            _isPaused.value = true
        }

        persistState(context)
        if (_isRunning.value && !_isPaused.value) {
            startTicker(context)
            startService(context, LivePumpTimerService.ACTION_RESUME)
        } else if (_isRunning.value && _isPaused.value) {
            tickerJob?.cancel()
            startService(context, LivePumpTimerService.ACTION_PAUSE)
        }
    }

    fun updateCalculatedSeconds(): Long {
        if (!_isRunning.value) {
            _seconds.value = accumulatedSeconds
            return accumulatedSeconds
        }
        if (_isPaused.value) {
            _seconds.value = accumulatedSeconds
            return accumulatedSeconds
        }
        val now = System.currentTimeMillis()
        val elapsedSinceStart = ((now - startTimeMillis) / 1000L).coerceAtLeast(0L)
        val totalSecs = accumulatedSeconds + elapsedSinceStart
        _seconds.value = totalSecs
        return totalSecs
    }

    private fun persistState(context: Context) {
        LiveTimerPreferences.saveTimerState(
            context = context,
            isRunning = _isRunning.value,
            isPaused = _isPaused.value,
            startTimeMs = startTimeMillis,
            accumulatedSecs = accumulatedSeconds,
            customerId = _customerId.value,
            customerName = _customerName.value,
            ratePerHour = _ratePerHour.value
        )
    }

    private fun startTicker(context: Context) {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (_isRunning.value && !_isPaused.value) {
                updateCalculatedSeconds()
                delay(1000)
            }
        }
    }

    private fun startService(context: Context, action: String) {
        val appContext = context.applicationContext
        val intent = Intent(appContext, LivePumpTimerService::class.java).apply {
            this.action = action
            putExtra(LivePumpTimerService.EXTRA_FROM_MANAGER, true)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(intent)
            } else {
                appContext.startService(intent)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Error starting LivePumpTimerService ($action): ${t.message}")
        }
    }
}

/**
 * Android Foreground Service with Sticky Lifecycle & Permanent Notification.
 * Stays running in background and keeps the persistent notification pinned
 * even when the user closes the app or clears it from recent apps.
 */
class LivePumpTimerService : Service() {

    companion object {
        const val CHANNEL_ID = "tubewell_live_pump_channel"
        const val NOTIFICATION_ID = 9012

        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_PAUSE = "com.example.service.ACTION_PAUSE"
        const val ACTION_RESUME = "com.example.service.ACTION_RESUME"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val EXTRA_FROM_MANAGER = "com.example.service.EXTRA_FROM_MANAGER"
    }

    private val serviceScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate + CoroutineExceptionHandler { _, t ->
            Log.w("LivePumpTimerService", "Service coroutine error: ${t.message}")
        }
    )
    private var updateJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun enterForegroundSafely() {
        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (t: Throwable) {
            Log.e("LivePumpTimerService", "Error calling startForeground: ${t.message}")
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            createNotificationChannel()
            LiveTimerManager.init(applicationContext, notifyService = false)
            enterForegroundSafely()
        } catch (t: Throwable) {
            Log.e("LivePumpTimerService", "Error in onCreate: ${t.message}")
        }
    }

    private fun stopSelfSafely() {
        updateJob?.cancel()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (t: Throwable) {
            Log.w("LivePumpTimerService", "Error stopping foreground: ${t.message}")
        }
        try {
            stopSelf()
        } catch (t: Throwable) {
            Log.w("LivePumpTimerService", "Error in stopSelf: ${t.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // ALWAYS satisfy startForeground BEFORE any early return to prevent ForegroundServiceDidNotStartInTimeException
        enterForegroundSafely()

        val action = intent?.action
        val fromManager = intent?.getBooleanExtra(EXTRA_FROM_MANAGER, false) ?: false

        if (action == ACTION_STOP) {
            stopSelfSafely()
            return START_NOT_STICKY
        }

        when (action) {
            ACTION_PAUSE -> {
                if (!fromManager) {
                    LiveTimerManager.pause(applicationContext, notifyService = false)
                }
                updateJob?.cancel()
                updateNotification()
            }
            ACTION_RESUME -> {
                if (!fromManager) {
                    LiveTimerManager.resume(applicationContext, notifyService = false)
                }
                updateNotification()
                startPeriodicNotificationUpdate()
            }
            ACTION_START, null -> {
                if (!fromManager) {
                    LiveTimerManager.init(applicationContext, notifyService = false)
                }
                if (LiveTimerManager.isRunning.value) {
                    updateNotification()
                    if (!LiveTimerManager.isPaused.value) {
                        startPeriodicNotificationUpdate()
                    } else {
                        updateJob?.cancel()
                    }
                } else {
                    stopSelfSafely()
                    return START_NOT_STICKY
                }
            }
        }
        return START_STICKY
    }

    /**
     * Called when the app is removed from Android's Recent Apps screen.
     * We keep the service and persistent notification alive because irrigation pump is active.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        val isRunning = LiveTimerManager.isRunning.value || LiveTimerPreferences.getIsRunning(applicationContext)
        if (isRunning) {
            // Schedule an immediate revive broadcast through AlarmManager in case OS terminates task process
            try {
                val restartIntent = Intent(applicationContext, LiveTimerRestartReceiver::class.java).apply {
                    action = LiveTimerRestartReceiver.ACTION_RESTART_TIMER_SERVICE
                }
                val pendingIntent = PendingIntent.getBroadcast(
                    applicationContext,
                    8899,
                    restartIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val alarmManager = getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager
                if (alarmManager != null) {
                    val canScheduleExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        alarmManager.canScheduleExactAlarms()
                    } else true
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && canScheduleExact) {
                        alarmManager.setExactAndAllowWhileIdle(
                            android.app.AlarmManager.RTC_WAKEUP,
                            System.currentTimeMillis() + 500,
                            pendingIntent
                        )
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setAndAllowWhileIdle(
                            android.app.AlarmManager.RTC_WAKEUP,
                            System.currentTimeMillis() + 500,
                            pendingIntent
                        )
                    } else {
                        alarmManager.set(
                            android.app.AlarmManager.RTC_WAKEUP,
                            System.currentTimeMillis() + 500,
                            pendingIntent
                        )
                    }
                }
            } catch (t: Throwable) {
                Log.w("LivePumpTimerService", "Failed to set restart alarm: ${t.message}")
            }

            // Keep notification active and service in foreground
            updateNotification()
            startPeriodicNotificationUpdate()
        }
    }

    private fun startPeriodicNotificationUpdate() {
        updateJob?.cancel()
        updateJob = serviceScope.launch {
            while (LiveTimerManager.isRunning.value && !LiveTimerManager.isPaused.value) {
                LiveTimerManager.updateCalculatedSeconds()
                updateNotification()
                delay(1000)
            }
        }
    }

    private fun updateNotification() {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            val notification = buildNotification()
            manager?.notify(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            Log.w("LivePumpTimerService", "Error updating notification: ${e.message}")
        }
    }

    private fun buildNotification(): Notification {
        val seconds = LiveTimerManager.updateCalculatedSeconds()
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60

        val customerName = LiveTimerManager.customerName.value.ifBlank { "किसान (Farmer)" }
        val rate = LiveTimerManager.ratePerHour.value
        val hoursDecimal = seconds / 3600.0
        val totalCharge = hoursDecimal * rate
        val isPaused = LiveTimerManager.isPaused.value

        val timeString = String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, secs)
        val title = if (isPaused) {
            "⏸️ मोटर रुकी हुई है • $customerName"
        } else {
            "🚜 ट्यूबवेल मोटर चालू है (लाइव) • $customerName"
        }
        val contentText = "⏱ समय: $timeString ($hours घं. $minutes मि.) • बिल: ₹${String.format(Locale.ROOT, "%.1f", totalCharge)}"

        // 1. Open App Intent (Returns to MainActivity)
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 2. Pause/Resume Action Intent
        val toggleActionIntent = Intent(this, LivePumpTimerService::class.java).apply {
            action = if (isPaused) ACTION_RESUME else ACTION_PAUSE
        }
        val togglePendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PendingIntent.getForegroundService(
                this,
                1,
                toggleActionIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else {
            PendingIntent.getService(
                this,
                1,
                toggleActionIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val toggleLabel = if (isPaused) "▶ पुनः शुरू करें" else "⏸ मोटर रोकें"
        val toggleIcon = if (isPaused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_pump)
            .setContentTitle(title)
            .setContentText(contentText)
            .setSubText("डिजिटल बही-खाता • ट्यूबवेल सेवा")
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setColor(0xFF1B5E20.toInt())
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)

        // Use Android system chronometer for smooth native notification ticks when running
        if (!isPaused) {
            builder.setUsesChronometer(true)
            builder.setShowWhen(true)
            builder.setWhen(System.currentTimeMillis() - (seconds * 1000L))
        } else {
            builder.setUsesChronometer(false)
            builder.setShowWhen(false)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        }

        // Action 1: Pause / Resume Toggle
        builder.addAction(
            toggleIcon,
            toggleLabel,
            togglePendingIntent
        )

        // Action 2: Open App / Complete Session
        builder.addAction(
            android.R.drawable.ic_menu_save,
            "✓ ऐप खोलें / हिसाब करें",
            openAppPendingIntent
        )

        return builder.build()
    }

    private fun createNotificationChannel() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "ट्यूबवेल लाइव टाइमर (Live Pump Tracker)",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "मोटर चलने का समय, लाइव बिलिंग एवं परमानेंट स्टेटस नोटिफिकेशन"
                    setShowBadge(true)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                manager?.createNotificationChannel(channel)
            }
        } catch (t: Throwable) {
            Log.w("LivePumpTimerService", "Failed to create notification channel: ${t.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        updateJob?.cancel()
        try {
            serviceScope.cancel()
        } catch (_: Throwable) {}
    }
}
