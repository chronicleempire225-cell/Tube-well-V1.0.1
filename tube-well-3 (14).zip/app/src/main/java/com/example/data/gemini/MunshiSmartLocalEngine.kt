package com.example.data.gemini

import com.example.data.db.ProfileEntity
import com.example.data.db.TubewellSessionEntity
import com.example.ui.viewmodel.CustomerWithStats
import java.util.Calendar
import java.util.Locale

/**
 * Top languages & Indian agricultural dialects supported by Munshi AI
 */
enum class MunshiLang(val code: String, val displayName: String, val nativeName: String) {
    HINDI("hi", "Hindi", "हिंदी"),
    ENGLISH("en", "English", "English"),
    HARYANVI("hr", "Haryanvi", "हरियाणवी"),
    BHOJPURI("bho", "Bhojpuri", "भोजपुरी"),
    RAJASTHANI("raj", "Rajasthani", "राजस्थानी"),
    PUNJABI("pa", "Punjabi", "ਪੰਜਾਬੀ"),
    GUJARATI("gu", "Gujarati", "ગુજરાતી"),
    MARATHI("mr", "Marathi", "मराठी"),
    BENGALI("bn", "Bengali", "বাংলা"),
    TELUGU("te", "Telugu", "తెలుగు"),
    TAMIL("ta", "Tamil", "தமிழ்"),
    KANNADA("kn", "Kannada", "ಕನ್ನಡ"),
    URDU("ur", "Urdu", "اردو")
}

/**
 * Intelligent Local Engine for Munshi Voice Assistant:
 * High-accuracy, offline-capable intent parser, multi-lingual chitchat handler,
 * and tubewell ledger calculator.
 *
 * Supports Hindi, Haryanvi, Bhojpuri, Rajasthani, Punjabi, English, Marathi, Gujarati, and other major languages.
 */
object MunshiSmartLocalEngine {

    /**
     * Checks if the user is explicitly requesting to switch the speaking language.
     * E.g. "इंग्लिश में बात करो", "हरियाणवी में बोलो", "talk in english", "भोजपुरी में बात करीं", "राजस्थानी बोलो"
     */
    fun detectLanguageSwitchRequest(query: String): MunshiLang? {
        val q = query.trim().lowercase(Locale.ROOT)

        val targetLang = when {
            q.contains("हरियाणवी") || q.contains("haryanvi") || q.contains("हरियाणा") -> MunshiLang.HARYANVI
            q.contains("भोजपुरी") || q.contains("bhojpuri") || q.contains("bhojpuree") -> MunshiLang.BHOJPURI
            q.contains("राजस्थानी") || q.contains("rajasthani") || q.contains("मारवाड़ी") || q.contains("marwari") || q.contains("मारवाडी") || q.contains("राजस्थान") -> MunshiLang.RAJASTHANI
            q.contains("पंजाबी") || q.contains("punjabi") || q.contains("ਪੰਜਾਬੀ") -> MunshiLang.PUNJABI
            q.contains("इंग्लिश") || q.contains("अंग्रेजी") || q.contains("english") || q.contains("angreji") || q.contains("अंगरेजी") -> MunshiLang.ENGLISH
            q.contains("मराठी") || q.contains("marathi") || q.contains("मराठीत") -> MunshiLang.MARATHI
            q.contains("गुजराती") || q.contains("gujarati") || q.contains("ગુજરાતી") -> MunshiLang.GUJARATI
            q.contains("बंगाली") || q.contains("bengali") || q.contains("বাংলা") || q.contains("বাঙালি") -> MunshiLang.BENGALI
            q.contains("तेलुगु") || q.contains("telugu") || q.contains("తెలుగు") -> MunshiLang.TELUGU
            q.contains("तमिल") || q.contains("tamil") || q.contains("தமிழ்") -> MunshiLang.TAMIL
            q.contains("कन्नड़") || q.contains("kannada") || q.contains("ಕನ್ನಡ") -> MunshiLang.KANNADA
            q.contains("उर्दू") || q.contains("urdu") || q.contains("اردو") -> MunshiLang.URDU
            q.contains("हिंदी") || q.contains("hindi") || q.contains("हिन्दी") -> MunshiLang.HINDI
            else -> null
        } ?: return null

        val wordCount = q.split("\\s+".toRegex()).size
        val hasSwitchIntent = wordCount <= 3 ||
                q.contains("बात") || q.contains("बोल") || q.contains("बता") ||
                q.contains("talk") || q.contains("speak") || q.contains("switch") || q.contains("change") ||
                q.contains("करो") || q.contains("कर") || q.contains("करीं") || q.contains("बोला") ||
                q.contains("भाषा") || q.contains("बोली") || q.contains("language") || q.contains("लगाओ") ||
                q.contains("चलाओ") || q.contains("दसो") || q.contains("ਦੱਸੋ") || q.contains("ਗੱਲ") ||
                q.contains("बतियाव") || q.contains("सांग") || q.contains("બોલો") || q.contains("फरमा") ||
                q.contains("में") || q.contains("मांय") || q.contains("ਵਿੱਚ") || q.contains("in")

        return if (hasSwitchIntent) targetLang else null
    }

    /**
     * Auto-detects language/dialect from query tokens if no explicit switch was made.
     * Uses strict token-boundary matching so common Hindi words like "पैसे", "कैसे", "जैसे", "बाकी", "बात"
     * are never mistaken for regional dialects.
     */
    fun detectDialectFromQuery(query: String, currentLang: MunshiLang): MunshiLang {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isBlank()) return currentLang

        val tokens = q.split("[\\s,?.!;:\"'()/-]+".toRegex()).filter { it.isNotBlank() }.toSet()

        // 1. Punjabi (Gurmukhi script or distinctive Punjabi tokens/phrases)
        if (q.any { it.code in 0x0A00..0x0A7F } ||
            q.contains("ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ") || q.contains("ਸਤਿ ਸ਼੍ਰੀ ਅਕਾਲ") ||
            tokens.any { it in setOf("ਕਿੰਨਾ", "ਕਿਵੇਂ", "ਰਹਿੰਦਾ", "ਕੁੱਲ", "ਕਿੰਨੇ", "ਪੈਸੇ", "ਦੱਸੋ", "ਹੈਗਾ", "ਕਿਹਦਾ", "ਕਿਸਾਨਾਂ", "ਕੀਤਾ", "ਹੋਇਆ", "ਹੋਏ", "ਦਸੋ", "ਰਹਿਂਦਾ", "ਕਿਸਾਨਾ") } ||
            tokens.any { it in setOf("किन्ना", "किन्ने", "रहिंदा", "दसो") }
        ) {
            return MunshiLang.PUNJABI
        }

        // 2. Gujarati script or distinctive Gujarati tokens
        if (q.any { it.code in 0x0A80..0x0AFF } ||
            q.contains("બાકી છે") || q.contains("કેમ છો") ||
            tokens.any { it in setOf("કેટલા", "કલાક", "રૂપિયા", "બોરવેલ", "હિસાબ") && q.any { it.code in 0x0A80..0x0AFF } }
        ) {
            return MunshiLang.GUJARATI
        }

        // 3. Bengali, Telugu, Tamil, Kannada, Urdu scripts
        if (q.any { it.code in 0x0980..0x09FF }) return MunshiLang.BENGALI
        if (q.any { it.code in 0x0C00..0x0C7F }) return MunshiLang.TELUGU
        if (q.any { it.code in 0x0B80..0x0BFF }) return MunshiLang.TAMIL
        if (q.any { it.code in 0x0C80..0x0CFF }) return MunshiLang.KANNADA
        if (q.any { it.code in 0x0600..0x06FF }) return MunshiLang.URDU

        // 4. English (Pure Latin text with English keywords)
        val isPureLatin = q.matches(Regex("^[a-zA-Z0-9\\s\\?,\\.!\\-']+$"))
        if (isPureLatin) {
            val englishKeywords = setOf("how", "what", "who", "when", "where", "total", "balance", "due", "dues", "session", "sessions", "rate", "hello", "hi", "farmer", "customer", "customers", "tubewell", "hours", "bill", "billing", "payment", "paid", "money", "help", "please", "thanks", "thank", "account", "ledger")
            if (tokens.any { it in englishKeywords }) {
                return MunshiLang.ENGLISH
            }
        }

        // 5. Marathi distinctive phrases/tokens
        if (q.contains("बाकी आहे") || q.contains("कसे आहात") || q.contains("काय हिशोब") || q.contains("कूपनलिका") ||
            tokens.any { it in setOf("किती", "सांगा", "शिल्लक", "झाले", "झाला", "आहेत", "माहिती", "करावे", "करा") && (tokens.contains("आहे") || tokens.contains("आहेत") || tokens.contains("किती")) }
        ) {
            return MunshiLang.MARATHI
        }

        // 6. Rajasthani / Marwari distinctive phrases & tokens
        val hasRajasthaniPhrase = q.contains("घणी खम्मा") || q.contains("खम्मा घणी") || q.contains("राम-राम सा") ||
                q.contains("राम राम सा") || q.contains("रो हिसाब") || q.contains("री पर्ची") || q.contains("अबे तांई") ||
                (tokens.contains("सा") && (tokens.contains("घणी") || tokens.contains("खम्मा") || tokens.contains("राम-राम") || tokens.contains("बतावो")))
        val hasRajasthaniTokens = tokens.any { it in setOf("थांरो", "थांरा", "थांरी", "थांके", "थांने", "म्हांरो", "म्हांरा", "म्हांरी", "म्हांके", "सगळा", "दीज्यो", "बतावो", "चाल्यो", "हुयो", "छै", "छो", "छूं", "कांई", "किण") }
        if (hasRajasthaniPhrase || hasRajasthaniTokens) {
            return MunshiLang.RAJASTHANI
        }

        // 7. Bhojpuri distinctive phrases & tokens (Must be standalone words, not substring of "बाकी" or "बात")
        val hasBhojpuriPhrase = q.contains("का हाल बा") || q.contains("बाकी बा") || q.contains("चलल बा") ||
                q.contains("गो किसान") || q.contains("कवनो बा") || q.contains("केतना बा") || q.contains("केतने बा")
        val hasBhojpuriTokens = tokens.any { it in setOf("केतना", "केतने", "बाटे", "बाड़े", "बानी", "रउआ", "रउरा", "हमार", "हमरा", "तोहार", "तोहरा", "बताईं", "बतियाव", "भइल", "भईल", "नइखे", "नाइखे", "कवनो", "किसानन", "अहिले") } ||
                (tokens.contains("बा") && !tokens.contains("बाकी") && !tokens.contains("बात"))
        if (hasBhojpuriPhrase || hasBhojpuriTokens) {
            return MunshiLang.BHOJPURI
        }

        // 8. Haryanvi distinctive phrases & tokens (Strict whole-word checks ONLY, never match "पैसे", "कैसे")
        val hasHaryanviPhrase = q.contains("बाकी सै") || q.contains("के हाल सै") || q.contains("के हिसाब") ||
                q.contains("के बात") || q.contains("बता भाई") || q.contains("सुनूं सूं") ||
                q.contains("चाल रह्या सै") || q.contains("चाल्या सै") || q.contains("आया सै") || q.contains("होया सै")
        val hasHaryanviTokens = tokens.any { it in setOf("कितणा", "कितणे", "कितणी", "चाल्या", "चालण", "म्हारा", "म्हारी", "म्हारै", "थारा", "थारी", "थारै", "कोन्या", "कोनी", "कुकर", "इबै", "जब्बे", "गेलै", "म्हाने", "तने", "थारे", "म्हारे") } ||
                (tokens.contains("सै") || tokens.contains("सैं"))
        if (hasHaryanviPhrase || hasHaryanviTokens) {
            return MunshiLang.HARYANVI
        }

        // 9. Standard Hindi markers (e.g. "है", "हैं", "पैसे", "रुपये", "बकाया", "हिसाब", "घंटे", "चला", "किसान", "नमस्ते", "बताओ")
        val hasHindiMarkers = tokens.any { it in setOf("है", "हैं", "था", "थे", "थी", "होगा", "होगी", "होंगे", "सकता", "सकते", "बताइए", "बताओ", "कितना", "कितने", "कितनी", "पैसे", "रुपये", "रुपया", "बकाया", "बाकी", "हिसाब", "घंटे", "घंटा", "चला", "किसान", "ग्राहक", "नमस्ते", "खाता", "ट्यूबवेल", "पानी", "सिंचाई") }
        if (hasHindiMarkers) {
            return MunshiLang.HINDI
        }

        return currentLang
    }

    /**
     * Normalizes Speech-to-Text typos, phonetic confusions, and dialect variations.
     * Intelligently infers intended meaning from surrounding words (Contextual STT Correction).
     */
    fun normalizeVoiceQuery(raw: String): String {
        var text = raw.trim()
        if (text.isBlank()) return text

        // 1. Spacing fixes for digits and units (e.g., "1साल" -> "1 साल", "6महीने" -> "6 महीने")
        text = text.replace(Regex("(\\d+)([a-zA-Z\u0900-\u097F]+)"), "$1 $2")

        // 2. "आधार" / "उधर" / "उद्धार" / "अधार" -> "उधार" (Contextual Phonetic Correction)
        // Android Google Voice STT frequently recognizes "उधार" (debt/credit) as "आधार" (Aadhaar), "उधर" (there), or "उद्धार" (upliftment).
        val hasAadhaarCard = text.contains("आधार कार्ड") || text.contains("aadhaar") || text.contains("aadhar")
        if (!hasAadhaarCard) {
            val lowerText = text.lowercase(Locale.ROOT)
            val hasDebtContext = lowerText.contains("साल") || lowerText.contains("महीने") || lowerText.contains("महीना") ||
                    lowerText.contains("दिन") || lowerText.contains("वर्ष") || lowerText.contains("कितने") ||
                    lowerText.contains("कितनों") || lowerText.contains("लोग") || lowerText.contains("लोगों") ||
                    lowerText.contains("किसका") || lowerText.contains("किनका") || lowerText.contains("किसकी") ||
                    lowerText.contains("किनकी") || lowerText.contains("बाकी") || lowerText.contains("बकाया") ||
                    lowerText.contains("रुपया") || lowerText.contains("रुपये") || lowerText.contains("पैसा") ||
                    lowerText.contains("पैसे") || lowerText.contains("हिसाब") || lowerText.contains("खाता") ||
                    lowerText.contains("बही") || lowerText.contains("लेना") || lowerText.contains("देना") ||
                    lowerText.contains("चुकता") || lowerText.contains("जमा") || lowerText.contains("पुराना") ||
                    lowerText.contains("पुराने") || lowerText.contains("ज्यादा") || lowerText.contains("कम") ||
                    lowerText.contains("है") || lowerText.contains("सै") || lowerText.contains("बा") ||
                    lowerText.contains("छै") || lowerText.contains("का") || lowerText.contains("की") ||
                    lowerText.contains("के")

            if (hasDebtContext) {
                // "आधार" in financial/ledger context is 100% "उधार"
                text = text.replace(Regex("\\bआधार\\b"), "उधार")
                    .replace(Regex("\\bअधार\\b"), "उधार")
                    .replace(Regex("\\bउद्धार\\b"), "उधार")
                    .replace(Regex("\\bओधार\\b"), "उधार")
                    .replace(Regex("\\bऔधार\\b"), "उधार")

                // "उधर" (meaning 'there') is frequently spoken as 'उधार'
                // e.g. "कितने लोगों का उधर है", "उधर कितना है", "उधर बाकी", "किसका उधर है"
                if (text.contains("उधर") && !text.contains("उधार")) {
                    text = text.replace(Regex("का\\s+उधर\\b"), "का उधार")
                        .replace(Regex("की\\s+उधर\\b"), "की उधार")
                        .replace(Regex("के\\s+उधर\\b"), "के उधार")
                        .replace(Regex("\\bउधर\\s+है\\b"), "उधार है")
                        .replace(Regex("\\bउधर\\s+बाकी\\b"), "उधार बाकी")
                        .replace(Regex("\\bउधर\\s+कितना\\b"), "उधार कितना")
                        .replace(Regex("\\bकितना\\s+उधर\\b"), "कितना उधार")
                        .replace(Regex("\\bकुल\\s+उधर\\b"), "कुल उधार")
                }
            }

            // General phrase endings: "...का आधार है" or "...आधार कितना है" or "...आधार बाकी" is always "उधार"
            text = text.replace(Regex("का\\s+आधार\\b"), "का उधार")
                .replace(Regex("की\\s+आधार\\b"), "की उधार")
                .replace(Regex("के\\s+आधार\\b"), "के उधार")
                .replace(Regex("\\bआधार\\s+है\\b"), "उधार है")
                .replace(Regex("\\bआधार\\s+बाकी\\b"), "उधार बाकी")
                .replace(Regex("\\bआधार\\s+कितना\\b"), "उधार कितना")
                .replace(Regex("\\bकितना\\s+आधार\\b"), "कितना उधार")
                .replace(Regex("\\bकुल\\s+आधार\\b"), "कुल उधार")
                .replace(Regex("\\bआधार\\s+बताओ\\b"), "उधार बताओ")
                .replace(Regex("\\bआधार\\s+वाले\\b"), "उधार वाले")
        }

        // 3. "बकाया" / "बाकी" phonetic variations
        text = text.replace(Regex("\\bबाकि\\b"), "बाकी")
            .replace(Regex("\\bबाके\\b"), "बाकी")
            .replace(Regex("\\bबकैया\\b"), "बकाया")
            .replace(Regex("\\bबकिया\\b"), "बकाया")
            .replace(Regex("\\bबाकया\\b"), "बकाया")

        // 4. "हिसाब" phonetic variations
        text = text.replace(Regex("\\bहिसब\\b"), "हिसाब")
            .replace(Regex("\\bइसब\\b"), "हिसाब")
            .replace(Regex("\\bहिसाब\\s*किताब\\b"), "हिसाब")

        // 5. "सत्र" (Session) phonetic variations ("शस्त्र", "सस्तर", "सेशन", आदि)
        text = text.replace("सेसन", "सत्र")
            .replace("सैसन", "सत्र")
            .replace("सेशन", "सत्र")
            .replace("sechan", "सत्र")
            .replace(Regex("(?i)\\b(शस्त्र|सस्तर|शस्तर|सस्त्र|सत्तर|सत्टर|सतर)\\b"), "सत्र")

        // 6. "पर्ची" / "रसीद" / "पीडीएफ" phonetic variations
        text = text.replace("परची", "पर्ची")
            .replace("परचा", "पर्ची")
            .replace("पर्चा", "पर्ची")
            .replace("रशीद", "रसीद")
            .replace("रसिट", "रसीद")
            .replace(Regex("(?i)\\b(पिडिएफ|पिडीएफ|पी डी एफ|pdf|pdf file)\\b"), "पीडीएफ")
            .replace(Regex("(?i)\\b(अवधी|अवध|समय\\s*सीमा|टाइम\\s*फिल्टर)\\b"), "अवधि")

        // 7. "ट्यूबवेल" phonetic variations
        text = text.replace("ट्यूबेल", "ट्यूबवेल")
            .replace("टूबवेल", "ट्यूबवेल")
            .replace("टुबेल", "ट्यूबवेल")
            .replace("टुबवेल", "ट्यूबवेल")
            .replace("टयूबवेल", "ट्यूबवेल")
            .replace("नलकुप", "नलकूप")

        // 8. "सिंचाई" / "पटाई"
        text = text.replace("सिचाई", "सिंचाई")
            .replace("सींचाई", "सिंचाई")
        if (text.contains("पताई") && (text.contains("पानी") || text.contains("घंटे") || text.contains("खेत") || text.contains("दर") || text.contains("रेट"))) {
            text = text.replace("पताई", "पटाई")
        }

        // 9. "डीजल" / "मीटर"
        text = text.replace("डिजल", "डीजल")
            .replace("मिटर", "मीटर")

        // 10. "यूरिया" / "डीएपी"
        text = text.replace("युरिया", "यूरिया")
            .replace("डी ए पी", "डीएपी")

        // 11. "गन्ना" / "गेहूं"
        if (text.contains("गाना") && (text.contains("फसल") || text.contains("पेड़ी") || text.contains("बुवाई") || text.contains("कटाई") || text.contains("खेत") || text.contains("रोग") || text.contains("मिल"))) {
            text = text.replace("गाना", "गन्ना")
        }
        text = text.replace(Regex("\\bगेहू\\b"), "गेहूं")
            .replace(Regex("\\bगेहु\\b"), "गेहूं")

        // 12. "ग्राहक" / "किसान" phonetic & dialect variants
        text = text.replace(Regex("(?i)\\bग्रह\\b"), "ग्राहक")
        if (text.contains("ग्रह") && (text.contains("जोड़") || text.contains("नया") || text.contains("बना") || text.contains("खोल") || text.contains("खाता"))) {
            text = text.replace("ग्रह", "ग्राहक")
        }
        text = text.replace("गिराहक", "ग्राहक")
            .replace("गिराक", "ग्राहक")
            .replace("गराक", "ग्राहक")
            .replace("गिराकों", "ग्राहकों")
            .replace("गिराहकों", "ग्राहकों")

        if (text.contains("किस") && !text.contains("किसान") && !text.contains("किस-किस") &&
            !text.contains("किसका") && !text.contains("किसे") && !text.contains("किसने") && !text.contains("किसके") && !text.contains("किसी")
        ) {
            if (text.contains("नया किस") || text.contains("किस जोड़") || text.contains("किस बना") ||
                text.contains("किस का हिसाब") || text.contains("एक किस") || text.contains("पुराने किस")
            ) {
                text = text.replace("किस", "किसान")
            }
        }

        // 13. Month Names (महीनों के नाम) Phonetic & Typo Normalization across Indian languages & English
        // Maps dialectal, mispronounced, or misspelled month queries to standard Hindi month names
        // January: जनवरी, जनबरी, जनवारी, जेनवरी, जनुअरी, ਜਨਵਰੀ, જાન્યુઆરી, january, jan
        text = text.replace(Regex("(?i)\\b(जनबरी|जनवारी|जेनवरी|जनुअरी|ਜਨਵਰੀ|જાન્યુઆરી|january|jan)\\b"), "जनवरी")
            // February: फ़रवरी, फरवरी, फेब्रुअरी, फबरवरी, फगवाड़ा, फरबरी, ਫਰਵਰੀ, ફેબ્રુઆરી, february, feb
            .replace(Regex("(?i)\\b(फ़रवरी|फरबरी|फेब्रुअरी|फबरवरी|ਫਰਵਰੀ|ફેબ્રુઆરી|february|feb)\\b"), "फरवरी")
            // March: मार्च, मार्चे, मारच, ਮਾਰਚ, માર્ચ, march, mar
            .replace(Regex("(?i)\\b(मारच|मार्चे|ਮਾਰਚ|માર્ચ|march|mar)\\b"), "मार्च")
            // April: अप्रैल, अप्रेल, एप्रिल, अप्रिल, ਅਪ੍ਰੈਲ, એપ્રિલ, april, apr
            .replace(Regex("(?i)\\b(अप्रेल|एप्रिल|अप्रिल|ਅਪ੍ਰੈਲ|એપ્રિલ|april|apr)\\b"), "अप्रैल")
            // May: मई, मेई, ਮਈ, મે, may
            .replace(Regex("(?i)\\b(मेई|ਮਈ|મે|may)\\b"), "मई")
            // June: जून, जुन, ਜੂਨ, જૂન, june, jun
            .replace(Regex("(?i)\\b(जुन|ਜੂਨ|જૂન|june|jun)\\b"), "जून")
            // July: जुलाई, जुलाइ, ਜੁਲਾਈ, જુલાઈ, july, jul
            .replace(Regex("(?i)\\b(जुलाइ|ਜੁਲਾਈ|જુલાઈ|july|jul)\\b"), "जुलाई")
            // August: अगस्त, अगस्थ, ओगस्ट, ਅਗਸਤ, ઓગસ્ટ, august, aug
            .replace(Regex("(?i)\\b(अगस्थ|ओगस्ट|अगस्त्य|ਅਗਸਤ|ઓગસ્ટ|august|aug)\\b"), "अगस्त")
            // September: सितंबर, सितम्बर, सितम्वर, ਸਤੰਬਰ, સપ્ટેમ્બર, september, sept, sep
            .replace(Regex("(?i)\\b(सितम्बर|सितम्वर|सितंबर|ਸਤੰਬਰ|સપ્ટેમ્બર|september|sept|sep)\\b"), "सितंबर")
            // October: अक्टूबर, अक्तूबर, अक्तुबर, अक्टूवर, ਅਕਤੂਬਰ, ઓક્ટોબર, october, oct
            .replace(Regex("(?i)\\b(अक्तूबर|अक्तुबर|अक्टूवर|अकटूबर|ਅਕਤੂਬਰ|ઓક્ટોબર|october|oct)\\b"), "अक्टूबर")
            // November: नवंबर, नवम्बर, नवम्वर, ನವೆಂಬರ್, ਨਵੰਬਰ, નવેમ્બર, november, nov
            .replace(Regex("(?i)\\b(नवम्बर|नवम्वर|ਨਵੰਬਰ|નવેમ્બર|november|nov)\\b"), "नवंबर")
            // December: दिसंबर, दिसम्बर, दिसम्वर, ਦਸੰਬਰ, ડિસેમ્બર, december, dec
            .replace(Regex("(?i)\\b(दिसम्बर|दिसम्वर|दिसंबर|ਦਸੰਬਰ|ડિસેમ્બર|december|dec)\\b"), "दिसंबर")

        return text
    }

    /**
     * Resolves the query locally from in-memory ledger and database state.
     * Returns a ready-to-speak response string, or null if outside local domain.
     */
    fun tryAnswerFromAppLogic(
        query: String,
        customersWithStats: List<CustomerWithStats>,
        sessions: List<TubewellSessionEntity>,
        profile: ProfileEntity?,
        isVipActive: Boolean,
        vipDaysRemaining: Int,
        vipPlan: String,
        hasPriorChat: Boolean = false,
        activeLang: MunshiLang = MunshiLang.HINDI
    ): String? {
        val normalized = normalizeVoiceQuery(query)
        val q = normalized.trim().lowercase(Locale.ROOT)
        if (q.isBlank()) return null

        // 1. Check for explicit Language Switch request (e.g. "हरियाणवी में बात करो", "इंग्लिश में बोलो")
        val switchRequest = detectLanguageSwitchRequest(q)
        if (switchRequest != null) {
            return buildLanguageSwitchConfirmation(switchRequest)
        }

        // 2. Determine effective dialect (auto-adopts spoken dialect or respects active selection)
        val lang = detectDialectFromQuery(q, activeLang)

        // 3. Friendly Chitchat & Greetings
        val chitchatReply = handleChitchat(q, lang)
        if (chitchatReply != null) {
            return chitchatReply
        }

        val greeting = if (hasPriorChat) "" else getInitialGreeting(lang)

        // 4. Prominent Farming & Agronomy Consultation: Answer prominent agriculture questions locally first!
        val farmingAnswer = tryAnswerFarmingQuery(q, lang, greeting)
        if (farmingAnswer != null) {
            return farmingAnswer
        }

        // If it's an agricultural query not matched by local prominent knowledge, return null so Gemini AI can answer!
        if (GeminiMunshiService.isFarmingOrCropAdviceQuery(q)) {
            return null
        }

        // =========================================================================
        // 4.5. High-Priority Specific Customer Query / Account / Ledger Lookup
        // =========================================================================
        val matchedCustomerResult = findMatchingCustomerResult(q, customersWithStats)
        if (matchedCustomerResult != null) {
            return buildCustomerSpecificResponse(matchedCustomerResult, q, lang, greeting)
        }

        // =========================================================================
        // 4. Detail Follow-up ("डिटेल से बताओ", "मुझे समझ में नहीं आया", "विस्तार से बताओ")
        // =========================================================================
        val isDetailRequest = q.contains("डिटेल") || q.contains("विस्तार") || q.contains("समझ नहीं") ||
                q.contains("समझ मे नहीं") || q.contains("समझ में नहीं") || q.contains("पूरा बताओ") ||
                q.contains("आसान तरीके से") || q.contains("detail")

        if (isDetailRequest) {
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}हाँ भाई, म्हैं तने बिल्कुल आसान ढाळ तै 3 बातां म्ह समझाऊँ सूं:\n" +
                        "1. नीचे मेनू म्ह 'ग्राहक' (Customers) आले टैब पै जा।\n" +
                        "2. उड़े नीचे दाएँ कोने पै लाल रंग का गोल बटन ('+ नया किसान जोड़ें') सै, उस पै क्लिक कर।\n" +
                        "3. इब किसान का नाम, उसके बाबू का नाम अर मोबाइल नंबर भरकै 'सुरक्षित करें' दबा दे। नया गिराहक तुरंत जुड़ जावेगा!"
                MunshiLang.BHOJPURI -> "${greeting}हाँ भाई जी, हम रउआ के एकदम आसान तरीका से 3 गो स्टेप में समझावतानी:\n" +
                        "1. नीचे मेनू में 'ग्राहक' वाला टैब पर टैप करीं।\n" +
                        "2. नीचे दहिनें कोना में लाल रंग के गोल बटन ('+ नया किसान जोड़ें') बा, ओकरा पर क्लिक करीं।\n" +
                        "3. अब किसान के नाम, पिता के नाम आ मोबाइल नंबर डाल के 'सुरक्षित करें' पर दबा दीहीं। तुरंत नया किसान जुड़ जाई!"
                MunshiLang.RAJASTHANI -> "${greeting}हाँ सा, म्हूं आपणे एकदम सरल 3 बातां मांय समझावूं छूं:\n" +
                        "1. नीचे मेनू मांय 'ग्राहक' टैब माथे दबाओ सा।\n" +
                        "2. नीचे जमणे हाथे लाल रंग रो गोल बटन ('+ नया किसान जोड़ें') छै, उण पै क्लिक करो।\n" +
                        "3. अब किसान रो नाम, पिता रो नाम अर मोबाइल नंबर लिख'र 'सुरक्षित करें' पै दबा दीज्यो। नयो किसान झटपट जुड़ जावेला!"
                MunshiLang.PUNJABI -> "${greeting}ਹਾਂਜੀ ਵੀਰ ਜੀ, ਮੈਂ ਤੁਹਾਨੂੰ ਬਿਲਕੁਲ ਆਸਾਨ ਤਰੀਕੇ ਨਾਲ 3 ਕਦਮਾਂ ਵਿੱਚ ਸਮਝਾਉਂਦਾ ਹਾਂ:\n" +
                        "1. ਹੇਠਾਂ 'ਗਾਹਕ' (Customers) ਟੈਬ 'ਤੇ ਜਾਓ।\n" +
                        "2. ਹੇਠਾਂ ਸੱਜੇ ਪਾਸੇ ਲਾਲ ਰੰਗ ਦੇ ਗੋਲ ਬਟਨ ('+ ਨਵਾਂ ਕਿਸਾਨ ਜੋੜੋ') 'ਤੇ ਕਲਿੱਕ ਕਰੋ।\n" +
                        "3. ਕਿਸਾਨ ਦਾ ਨਾਮ, ਪਿਤਾ ਦਾ ਨਾਮ ਅਤੇ ਮੋਬਾਈਲ ਨੰਬਰ ਭਰ ਕੇ 'ਸੁਰੱਖਿਅਤ ਕਰੋ' 'ਤੇ ਟੈਪ ਕਰੋ।"
                MunshiLang.ENGLISH -> "${greeting}Sure! Here is a simple step-by-step guide:\n" +
                        "1. Tap the 'Customers' tab in the bottom navigation.\n" +
                        "2. Tap the red circular button ('+ Add New Farmer') at the bottom-right.\n" +
                        "3. Enter the farmer's name, father's name, and mobile number, then tap 'Save'."
                else -> "${greeting}हाँ भाईजी, मैं आपको बिल्कुल आसान और विस्तृत तरीके से 3 चरणों में समझाता हूँ:\n" +
                        "1. नीचे मुख्य मेनू में 'ग्राहक' (Customers) वाले टैब पर टैप करें।\n" +
                        "2. स्क्रीन पर नीचे दाएँ (Right) कोने में लाल रंग का गोल बटन ('+ नया किसान जोड़ें') है, उस पर क्लिक करें।\n" +
                        "3. अब किसान का नाम, उनके पिता का नाम (ताकि पहचान रहे) और मोबाइल नंबर डालकर 'सुरक्षित करें' पर टैप कर दें। नया किसान तुरंत आपके खाते में जुड़ जाएगा!"
            }
        }

        // =========================================================================
        // 5. VIP Membership Pricing & Benefits (वीआईपी प्लान कितने का है / मासिक व वार्षिक प्लान)
        // =========================================================================
        val isVipPricingQuery = (q.contains("वीआईपी") || q.contains("vip") || q.contains("प्लान") ||
                q.contains("मेंबर") || q.contains("सदस्यता")) &&
                (q.contains("कितने") || q.contains("कितना") || q.contains("मासिक") || q.contains("वार्षिक") ||
                 q.contains("दाम") || q.contains("चार्ज") || q.contains("फीस") || q.contains("रुपये") || q.contains("का है"))

        if (isVipPricingQuery) {
            val pricingConfig = com.example.data.remoteconfig.RemoteConfigService.getPricingConfig()
            if (!pricingConfig.isVipEnabled) {
                return when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}ट्यूबवेल बही-खाता सारे किसान भाइयां खातर बिल्कुल मुफ्त (Free) ऐप सै भाई। इस म्ह कोई VIP या पेड प्लान की जरूरत कोन्या, आप सारा हिसाब-किताब आराम तै संभाल सको सो।"
                    MunshiLang.BHOJPURI -> "${greeting}ट्यूबवेल बही-खाता सभई किसान भाई लोगिन खातिर बिल्कुल मुफ्त (Free) ऐप बा। एहमें कवनो VIP प्लान के जरूरत नइखे, रउआ आपन सारा हिसाब आराम से रख सकेनी।"
                    MunshiLang.RAJASTHANI -> "${greeting}ट्यूबवेल बही-खाता सारा किसान भायां सारू बिल्कुल मुफ्त ऐप छै सा। अठे कोई VIP प्लान री जरूरत कोनी, आप पूरो बही-खातो आराम सूं संभाल सको छा।"
                    MunshiLang.PUNJABI -> "${greeting}ਟਿਊਬਵੈੱਲ ਬਹੀ-ਖਾਤਾ ਸਾਰੇ ਕਿਸਾਨ ਭਰਾਵਾਂ ਲਈ ਬਿਲਕੁਲ ਮੁਫ਼ਤ (Free) ਐਪ ਹੈ ਜੀ। ਇਸ ਵਿੱਚ ਕਿਸੇ VIP ਪਲਾਨ ਦੀ ਲੋੜ ਨਹੀਂ ਹੈ, ਤੁਸੀਂ ਸਾਰਾ ਹਿਸਾਬ-ਕਿਤਾਬ ਆਰਾਮ ਨਾਲ ਸੰਭਾਲ ਸਕਦੇ ਹੋ।"
                    MunshiLang.ENGLISH -> "${greeting}Tubewell Bahi-Khata is completely free for all farmers. No VIP or paid plans are required to manage your ledger."
                    else -> "${greeting}ट्यूबवेल बही-खाता सभी किसान भाइयों के लिए बिल्कुल मुफ्त (Free) डिजिटल ऐप है। इसमें किसी VIP या पेड प्लान की आवश्यकता नहीं है, आप अपने सभी किसानों का हिसाब, सिंचाई के घंटे और पर्ची बिना किसी शुल्क के आसानी से संभाल सकते हैं।"
                }
            }

            val monthlyPrice = pricingConfig.getEffectiveMonthlyPrice().toInt()
            val yearlyPrice = pricingConfig.getEffectiveYearlyPrice().toInt()
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}ट्यूबवेल बही-खाता म्ह VIP सदस्यता के प्लान सैं भाई:\n" +
                        "1. महीना आला: मात्र ₹$monthlyPrice महीना\n" +
                        "2. साल आला: ₹$yearlyPrice साल (सारे तै घणा पसंद करा जावै सै)\n\n" +
                        "VIP लेण तै सारे ऐड हमेशा खातर बंद हो ज्यावैंगे अर सुरक्षित बैकअप मिलैगा। सेटिंग्स म्ह जाकै '👑 VIP सदस्यता' पै टैप करकै ले सकै सै।"
                MunshiLang.BHOJPURI -> "${greeting}ट्यूबवेल बही-खाता में VIP सदस्यता के प्लान बा:\n" +
                        "1. मासिक प्लान: मात्र ₹$monthlyPrice महीना\n" +
                        "2. सालाना प्लान: ₹$yearlyPrice साल (सभसे ज्यादा पसंद)\n\n" +
                        "VIP लिहला पर सभई विज्ञापन हमेशा खातिर बंद हो जाई आ बैकअप मिली। सेटिंग्स में '👑 VIP सदस्यता' से ले सकेनी।"
                MunshiLang.RAJASTHANI -> "${greeting}ट्यूबवेल बही-खाता मांय VIP सदस्यता रा प्लान छै सा:\n" +
                        "1. महीना रो: मात्र ₹$monthlyPrice महीना\n" +
                        "2. साल रो: ₹$yearlyPrice साल (सबसूं घणो पसंद)\n\n" +
                        "VIP लेवां सूं सारा विज्ञापन हमेशा सारू बंद हो जावेला अर डेटा सुरक्षित रहेला।"
                MunshiLang.PUNJABI -> "${greeting}ਟਿਊਬਵੈੱਲ ਬਹੀ-ਖਾਤਾ ਵਿੱਚ VIP ਮੈਂਬਰਸ਼ਿਪ ਦੇ ਪਲਾਨ ਹਨ:\n" +
                        "1. ਮਹੀਨਾਵਾਰ: ਸਿਰਫ਼ ₹$monthlyPrice ਪ੍ਰਤੀ ਮਹੀਨਾ\n" +
                        "2. ਸਾਲਾਨਾ: ₹$yearlyPrice ਪ੍ਰਤੀ ਸਾਲ (ਸਭ ਤੋਂ ਪ੍ਰਸਿੱਧ)\n\n" +
                        "VIP ਲੈਣ ਨਾਲ ਸਾਰੇ ਇਸ਼ਤਿਹਾਰ ਹਮੇਸ਼ਾ ਲਈ ਬੰਦ ਹੋ ਜਾਂਦੇ ਹਨ ਅਤੇ ਪੂਰਾ ਬੈਕਅੱਪ ਮਿਲਦਾ ਹੈ।"
                MunshiLang.ENGLISH -> "${greeting}Tubewell Bahi-Khata offers VIP membership plans:\n" +
                        "1. Monthly Plan: ₹$monthlyPrice per month\n" +
                        "2. Annual Plan: ₹$yearlyPrice per year (Most Popular)\n\n" +
                        "VIP membership permanently removes 100% of ads and provides unlimited cloud backup."
                else -> "${greeting}ट्यूबवेल बही-खाता में VIP सदस्यता के प्लान उपलब्ध हैं:\n" +
                        "1. मासिक प्लान: मात्र ₹$monthlyPrice प्रति माह\n" +
                        "2. वार्षिक प्लान: मात्र ₹$yearlyPrice प्रति वर्ष (भारी छूट)\n\n" +
                        "VIP सदस्य बनने पर:\n" +
                        "• ऐप में सभी विज्ञापन 100% बंद रहते हैं।\n" +
                        "• कोई वीडियो ऐड नहीं देखना पड़ता और सभी फीचर्स सीधे अनलॉक रहते हैं।\n" +
                        "• असीमित सुरक्षित डेटा बैकअप और प्राथमिकता सपोर्ट मिलता है।\n" +
                        "आप 'सेटिंग्स' में जाकर '👑 VIP सदस्यता' कार्ड पर टैप करके इसे एक्टिवेट कर सकते हैं।"
            }
        }

        // =========================================================================
        // 6. VIP / Ads Removal Query (ऐड हटाना / विज्ञापन बंद करना)
        // =========================================================================
        if (q.contains("ऐड") || q.contains("विज्ञापन") || q.contains("ad") || q.contains("ads") ||
            (q.contains("हटा") && (q.contains("कैसे") || q.contains("बंद"))) ||
            q.contains("विज्ञापनों")
        ) {
            val pricingConfig = com.example.data.remoteconfig.RemoteConfigService.getPricingConfig()
            if (!pricingConfig.isVipEnabled) {
                return when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}ट्यूबवेल बही-खाता सारे किसान भाइयां खातर बिल्कुल फ्री ऐप सै भाई। ऐप म्ह आराम तै खाता चलाओ अर पर्ची भेजो, सारा हिसाब सुरक्षित रहवैगा।"
                    MunshiLang.BHOJPURI -> "${greeting}ट्यूबवेल बही-खाता सभई किसान भाई लोगिन खातिर एकदम मुफ्त ऐप बा। रउआ आराम से अपना सब किसानन के हिसाब-किताब आ पर्ची भेज सकेनी।"
                    MunshiLang.RAJASTHANI -> "${greeting}ट्यूबवेल बही-खाता सारा किसान भायां सारू बिल्कुल मुफ्त ऐप छै सा। आप बिना कोई फीस रा पूरो हिसाब-किताब राख सको छा।"
                    MunshiLang.PUNJABI -> "${greeting}ਟਿਊਬਵੈੱਲ ਬਹੀ-ਖਾਤਾ ਸਾਰੇ ਕਿਸਾਨ ਭਰਾਵਾਂ ਲਈ ਬਿਲਕੁਲ ਮੁਫ਼ਤ ਐਪ ਹੈ ਜੀ। ਤੁਸੀਂ ਆਰਾਮ ਨਾਲ ਸਾਰਾ ਖਾਤਾ ਤੇ ਪਰਚੀ ਭੇਜ ਸਕਦੇ ਹੋ।"
                    MunshiLang.ENGLISH -> "${greeting}Tubewell Bahi-Khata is a completely free application for all farmers to easily manage accounts, irrigation hours, and billing slips."
                    else -> "${greeting}ट्यूबवेल बही-खाता सभी किसान भाइयों की सुविधा के लिए बिल्कुल मुफ्त (Free) ऐप है। आप बिना किसी शुल्क के अपने सभी ग्राहकों का हिसाब, पर्ची और बिलिंग आसानी से संभाल सकते हैं।"
                }
            }

            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}ऐप म्ह तै सारे ऐड (विज्ञापन) हटाण खातर VIP सदस्यता दे राखी सै भाई। सेटिंग्स म्ह जाकै '👑 VIP सदस्यता (Ad-Free)' पै टैप करकै VIP ले ल्यो, फेर एक भी ऐड कोन्या आवैगा।"
                MunshiLang.BHOJPURI -> "${greeting}ऐप से सारा विज्ञापन (ऐड) हटावे खातिर VIP सदस्यता फीचर बा। सेटिंग्स में जाके '👑 VIP सदस्यता (Ad-Free)' कार्ड से प्लान ले लीहीं, सारा ऐड तुरंत बंद हो जाई।"
                MunshiLang.RAJASTHANI -> "${greeting}ऐप मांय सूं सारा विज्ञापन हटावा सारू VIP सदस्यता दे रखी छै सा। सेटिंग्स मांय '👑 VIP सदस्यता' माथे टैप कर'र प्लान ले सको छा।"
                MunshiLang.PUNJABI -> "${greeting}ਐਪ ਵਿੱਚੋਂ ਸਾਰੇ ਇਸ਼ਤਿਹਾਰ (Ads) ਹਟਾਉਣ ਲਈ VIP ਮੈਂਬਰਸ਼ਿਪ ਫੀਚਰ ਹੈ। ਤੁਸੀਂ 'ਸੈਟਿੰਗਜ਼' ਵਿੱਚ ਜਾ ਕੇ '👑 VIP ਮੈਂਬਰਸ਼ਿਪ (Ad-Free)' ਕਾਰਡ ਤੋਂ VIP ਪਲਾਨ ਚੁਣ ਸਕਦੇ ਹੋ।"
                MunshiLang.ENGLISH -> "${greeting}To remove all ads permanently, open Settings and tap on '👑 VIP Membership (Ad-Free)'. Activating VIP completely stops all ads across the app."
                else -> "${greeting}ऐप से सारे विज्ञापन (ऐड) हटाने के लिए VIP सदस्यता फीचर दिया गया है। आप 'सेटिंग्स' में जाएं और '👑 VIP सदस्यता' कार्ड पर टैप करके VIP प्लान चुन लें। इससे सभी विज्ञापन 100% बंद हो जाएंगे और सभी फीचर्स बिना वीडियो देखे अनलॉक रहेंगे।"
            }
        }

        // =========================================================================
        // 7. Profile & Email Verification Status (ईमेल वेरीफाइड है या नहीं / प्रोफाइल)
        // =========================================================================
        val isEmailVerifiedQuery = (q.contains("ईमेल") || q.contains("email") || q.contains("मेल")) &&
                (q.contains("वेरीफाइड") || q.contains("वेरीफाई") || q.contains("सत्यापित") ||
                 q.contains("verified") || q.contains("चेक") || q.contains("जाँच") || q.contains("है या नहीं"))

        if (isEmailVerifiedQuery) {
            val userEmail = profile?.email?.trim() ?: ""
            val isVerified = profile?.isEmailVerified == true
            return when (lang) {
                MunshiLang.HARYANVI -> if (userEmail.isBlank()) {
                    "${greeting}थारे खाते म्ह इब कोई ईमेल कोन्या जुड़ी सै भाई। सेटिंग्स म्ह जाकै प्रोफ़ाइल तै जोड़ सकै सै।"
                } else if (isVerified) {
                    "${greeting}हाँ भाई, थारी ईमेल '$userEmail' पूरी ढाळ वेरीफाइड (सत्यापित) सै!"
                } else {
                    "${greeting}भाई, थारी ईमेल '$userEmail' जुड़ी तो सै, पर इब ताहीं वेरीफाइड कोन्या। सेटिंग्स म्ह जाकै वेरीफाई कर ले।"
                }
                MunshiLang.BHOJPURI -> if (userEmail.isBlank()) {
                    "${greeting}रउआ खाता में अभी कवनो ईमेल नइखे जुड़ल। सेटिंग्स में प्रोफ़ाइल से जोड़ सकेनी।"
                } else if (isVerified) {
                    "${greeting}हाँ भाई जी, रउआ ईमेल '$userEmail' 100% वेरीफाइड बा।"
                } else {
                    "${greeting}भाई जी, रउआ ईमेल '$userEmail' जुड़ल बा, बाकी अभी वेरीफाइड नइखे।"
                }
                MunshiLang.RAJASTHANI -> if (userEmail.isBlank()) {
                    "${greeting}थांके खाते मांय अबे कोई ईमेल कोनी जुड़ी छै सा। सेटिंग्स मांय जा'र जोड़ सको छा।"
                } else if (isVerified) {
                    "${greeting}हाँ सा, आपरी ईमेल '$userEmail' 100% वेरीफाइड छै!"
                } else {
                    "${greeting}आपरी ईमेल '$userEmail' लिखी तो छै, पण अबे तांई वेरीफाइड कोनी सा।"
                }
                MunshiLang.PUNJABI -> if (userEmail.isBlank()) {
                    "${greeting}ਤੁਹਾਡੇ ਖਾਤੇ ਵਿੱਚ ਅਜੇ ਕੋਈ ਈਮੇਲ ਨਹੀਂ ਜੁੜੀ। ਤੁਸੀਂ ਸੈਟਿੰਗਜ਼ ਵਿੱਚ ਜਾ ਕੇ ਈਮੇਲ ਜੋੜ ਸਕਦੇ ਹੋ।"
                } else if (isVerified) {
                    "${greeting}ਹਾਂਜੀ ਵੀਰ ਜੀ, ਤੁਹਾਡੀ ਈਮੇਲ '$userEmail' 100% ਵੈਰੀਫਾਈਡ ਹੈ।"
                } else {
                    "${greeting}ਵੀਰ ਜੀ, ਈਮੇਲ '$userEmail' ਦਰਜ ਹੈ, ਪਰ ਅਜੇ ਵੈਰੀਫਾਈਡ ਨਹੀਂ ਹੈ।"
                }
                MunshiLang.ENGLISH -> if (userEmail.isBlank()) {
                    "${greeting}There is no email linked to your account yet. You can add one in Settings > Edit Profile."
                } else if (isVerified) {
                    "${greeting}Yes! Your email '$userEmail' is 100% verified."
                } else {
                    "${greeting}Your email '$userEmail' is registered but not yet verified."
                }
                else -> if (userEmail.isBlank()) {
                    "${greeting}आपके खाते में अभी कोई ईमेल पंजीकृत नहीं है। आप सेटिंग्स में 'प्रोफ़ाइल संपादित करें' में जाकर ईमेल जोड़ सकते हैं।"
                } else if (isVerified) {
                    "${greeting}हाँ भाईजी, आपकी ईमेल '$userEmail' 100% सफलतापूर्वक वेरीफाइड (सत्यापित) है।"
                } else {
                    "${greeting}भाईजी, आपकी ईमेल '$userEmail' दर्ज है, लेकिन अभी वेरीफाइड नहीं है। आप सेटिंग्स में जाकर प्रोफ़ाइल से इसे वेरीफाई कर सकते हैं।"
                }
            }
        }

        val isProfileOrEmailQuery = q.contains("ईमेल") || q.contains("email") || q.contains("मेल") ||
                q.contains("फोन") || q.contains("मोबाइल") || q.contains("mobile") || q.contains("phone") ||
                q.contains("प्रोफाइल") || q.contains("profile") || q.contains("मेरा नाम") || q.contains("आईडी") ||
                (q.contains("लगी") && (q.contains("है") || q.contains("सै") || q.contains("बा")))

        if (isProfileOrEmailQuery) {
            val userEmail = profile?.email?.trim() ?: ""
            val hasEmail = userEmail.isNotBlank()
            val ownerName = profile?.name?.trim() ?: "किसान साथी"
            val phoneNum = profile?.phone?.trim() ?: ""
            val agency = profile?.agencyName?.trim() ?: ""
            val isVerified = profile?.isEmailVerified == true

            if (q.contains("ईमेल") || q.contains("email") || q.contains("मेल") || q.contains("लगी")) {
                return when (lang) {
                    MunshiLang.HARYANVI -> if (hasEmail) {
                        val statusText = if (isVerified) " (वेरीफाइड ✓)" else " (अनवेरीफाइड)"
                        "${greeting}हाँ भाई, थारे खाते म्ह ईमेल '$userEmail'$statusText जुड़ी सै।"
                    } else {
                        "${greeting}ना भाई, इब थारे खाते म्ह कोई ईमेल कोन्या जुड़ी।"
                    }
                    MunshiLang.BHOJPURI -> if (hasEmail) {
                        val statusText = if (isVerified) " (वेरीफाइड ✓)" else " (अनवेरीफाइड)"
                        "${greeting}हाँ जी, खाता में ईमेल '$userEmail'$statusText जुड़ल बा।"
                    } else {
                        "${greeting}ना भाई जी, अभी कवनो ईमेल नइखे जुड़ल।"
                    }
                    MunshiLang.RAJASTHANI -> if (hasEmail) {
                        val statusText = if (isVerified) " (वेरीफाइड ✓)" else " (अनवेरीफाइड)"
                        "${greeting}हाँ सा, थांके खाते मांय ईमेल '$userEmail'$statusText जुड़ी छै।"
                    } else {
                        "${greeting}ना सा, अबे कोई ईमेल कोनी जुड़ी छै।"
                    }
                    MunshiLang.PUNJABI -> if (hasEmail) {
                        val statusText = if (isVerified) " (ਵੈਰੀਫਾਈਡ ✓)" else " (ਅਣਵੈਰੀਫਾਈਡ)"
                        "${greeting}ਹਾਂਜੀ, ਤੁਹਾਡੇ ਖਾਤੇ ਵਿੱਚ ਈਮੇਲ '$userEmail'$statusText ਜੁੜੀ ਹੈ।"
                    } else {
                        "${greeting}ਨਹੀਂ ਵੀਰ ਜੀ, ਅਜੇ ਕੋਈ ਈਮੇਲ ਨਹੀਂ ਜੁੜੀ।"
                    }
                    MunshiLang.ENGLISH -> if (hasEmail) {
                        val statusText = if (isVerified) " (Verified ✓)" else " (Unverified)"
                        "${greeting}Yes, your account is linked with email '$userEmail'$statusText."
                    } else {
                        "${greeting}No, there is currently no email linked to your account."
                    }
                    else -> if (hasEmail) {
                        val statusText = if (isVerified) " (वेरीफाइड ✓)" else " (अभी अनवेरीफाइड)"
                        "${greeting}हाँ जी, आपके खाते में ईमेल '$userEmail'$statusText जुड़ी हुई है।"
                    } else {
                        "${greeting}नहीं भाईजी, अभी आपके खाते में कोई ईमेल नहीं जुड़ी है।"
                    }
                }
            } else if (q.contains("फोन") || q.contains("मोबाइल") || q.contains("phone") || q.contains("mobile")) {
                return when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}थारे खाते म्ह पंजीकृत मोबाइल नंबर $phoneNum अर नाम '$ownerName' सै।"
                    MunshiLang.BHOJPURI -> "${greeting}रउआ खाता में पंजीकृत मोबाइल नंबर $phoneNum आ नाम '$ownerName' दर्ज बा।"
                    MunshiLang.RAJASTHANI -> "${greeting}थांके खाते मांय मोबाइल नंबर $phoneNum अर नाम '$ownerName' दर्ज छै सा।"
                    MunshiLang.PUNJABI -> "${greeting}ਤੁਹਾਡੇ ਖਾਤੇ ਵਿੱਚ ਰਜਿਸਟਰਡ ਮੋਬਾਈਲ ਨੰਬਰ $phoneNum ਅਤੇ ਨਾਮ '$ownerName' ਹੈ।"
                    MunshiLang.ENGLISH -> "${greeting}Your registered mobile number is $phoneNum under the name '$ownerName'."
                    else -> "${greeting}आपके खाते में पंजीकृत मोबाइल नंबर $phoneNum है और नाम '$ownerName' दर्ज है।"
                }
            } else {
                return "${greeting}आपकी प्रोफ़ाइल में नाम '$ownerName'${if (agency.isNotBlank()) ", ट्यूबवेल '$agency'" else ""}, मोबाइल $phoneNum ${if (hasEmail) "और ईमेल '$userEmail'" else "दर्ज है।"}।"
            }
        }

        // =========================================================================
        // 8. App Share, Help/Support, Logout, Privacy Policy
        // =========================================================================
        if (q.contains("शेयर") || q.contains("share") || q.contains("भेजें ऐप") || q.contains("दोस्त")) {
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}ऐप नै दूसरे गिराहक भायां गैल शेयर करण खातर: सेटिंग्स म्ह जाकै 'मित्रों के साथ शेयर करें' (Share App) पै दबाओ अर WhatsApp तै भेज द्यो।"
                MunshiLang.BHOJPURI -> "${greeting}ऐप के दोसर किसान भाई लोगन के भेजे खातिर: सेटिंग्स में जाईं आ 'मित्रों के साथ शेयर करें' पर दबा के WhatsApp से भेज दीहीं।"
                MunshiLang.RAJASTHANI -> "${greeting}ऐप ने दूजा किसान भाईयां सागे शेयर करवा सारू: सेटिंग्स मांय 'मित्रों के साथ शेयर करें' दबा'र WhatsApp पै भेज दीज्यो सा।"
                MunshiLang.PUNJABI -> "${greeting}ਐਪ ਨੂੰ ਹੋਰ ਕਿਸਾਨ ਵੀਰਾਂ ਨਾਲ ਸਾਂਝਾ ਕਰਨ ਲਈ: ਸੈਟਿੰਗਜ਼ ਵਿੱਚ 'Share App' ਵਿਕਲਪ 'ਤੇ ਟੈਪ ਕਰਕੇ WhatsApp ਰਾਹੀਂ ਭੇਜੋ।"
                MunshiLang.ENGLISH -> "${greeting}To share the app with other farmers: Go to Settings and tap 'Share with Friends'. You can easily send the download link via WhatsApp."
                else -> "${greeting}ऐप को अन्य किसान भाइयों के साथ शेयर करने के लिए:\n1. नीचे दाएँ कोने में 'सेटिंग्स' (Settings) टैब पर टैप करें।\n2. वहाँ 'मित्रों के साथ शेयर करें' (Share App) विकल्प पर क्लिक करें और WhatsApp से भेज दें।"
            }
        }

        if (q.contains("सपोर्ट") || q.contains("हेल्प") || q.contains("help") || q.contains("support") ||
            q.contains("कस्टमर केयर") || q.contains("सहायता") || q.contains("शिकायत")
        ) {
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}मदद खातर सेटिंग्स म्ह जाकै 'हेल्प एवं सपोर्ट' पै दबाओ भाई, उड़े सीधा म्हारै आधिकारिक WhatsApp पै चैट हो ज्यावैगी।"
                MunshiLang.BHOJPURI -> "${greeting}मदद खातिर सेटिंग्स में जाके 'हेल्प एवं सपोर्ट' पर टैप करीं, उहाँ से सीधा WhatsApp हेल्पलाइन पर बात हो जाई।"
                MunshiLang.RAJASTHANI -> "${greeting}सहायता सारू सेटिंग्स मांय जा'र 'हेल्प एवं सपोर्ट' माथे दबाओ सा, उण सूं सीधा WhatsApp हेल्पलाइन पै बात हो जावेला।"
                MunshiLang.PUNJABI -> "${greeting}ਸਹਾਇਤਾ ਲਈ ਸੈਟਿੰਗਜ਼ ਵਿੱਚ 'Help & Support' 'ਤੇ ਟੈਪ ਕਰੋ, ਉੱਥੇ ਤੁਸੀਂ ਸਿੱਧਾ ਸਾਡੀ WhatsApp ਹੈਲਪਲਾਈਨ 'ਤੇ ਗੱਲਬਾਤ ਕਰ ਸਕਦੇ ਹੋ।"
                MunshiLang.ENGLISH -> "${greeting}For help and support, open Settings and tap 'Help & Support' to chat directly with our official WhatsApp support helpline."
                else -> "${greeting}सहायता और सपोर्ट पाने के लिए सेटिंग्स (Settings) में जाएं और 'हेल्प एवं सपोर्ट' (Help & Support) विकल्प पर टैप करें। वहाँ आप सीधे हमारी आधिकारिक WhatsApp हेल्पलाइन पर चैट कर सकते हैं।"
            }
        }

        if (q.contains("लॉगआउट") || q.contains("logout") || q.contains("लॉग आउट") || q.contains("बाहर कैसे")) {
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}लॉगआउट करण खातर सेटिंग्स म्ह सबसे नीचे लाल रंग का 'लॉगआउट' बटन सै भाई, उस पै दबाते ही बाहर आ ज्याओगे।"
                MunshiLang.BHOJPURI -> "${greeting}लॉगआउट करे खातिर सेटिंग्स में सभसे नीचे लाल रंग के 'लॉगआउट' बटन बा, ओकरा पर दबा के बाहर आ जाईं।"
                MunshiLang.RAJASTHANI -> "${greeting}लॉगआउट करवा सारू सेटिंग्स मांय सबसूं नीचे लाल रंग रो 'लॉगआउट' बटन छै सा।"
                MunshiLang.PUNJABI -> "${greeting}ਲੌਗਆਉਟ ਕਰਨ ਲਈ ਸੈਟਿੰਗਜ਼ ਸਕ੍ਰੀਨ ਵਿੱਚ ਸਭ ਤੋਂ ਹੇਠਾਂ ਦਿੱਤੇ ਲਾਲ 'Logout' ਬਟਨ 'ਤੇ ਟੈਪ ਕਰੋ।"
                MunshiLang.ENGLISH -> "${greeting}To logout, scroll to the bottom of the Settings screen and tap the red 'Logout' button."
                else -> "${greeting}लॉगआउट करने के लिए सेटिंग्स (Settings) स्क्रीन में सबसे नीचे जाएँ। वहाँ लाल रंग का 'लॉगआउट' (Logout) बटन दिया गया है।"
            }
        }

        // =========================================================================
        // 9. Send Receipt / Parchhi (पर्ची कैसे सेंड करें / हिसाब कैसे भेजें)
        // =========================================================================
        if ((q.contains("पर्ची") || q.contains("रसीद") || q.contains("बिल") || q.contains("हिसाब")) &&
            (q.contains("सेंड") || q.contains("भेज") || q.contains("whatsapp") || q.contains("व्हाट्सएप") || q.contains("शेयर"))
        ) {
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}गिराहक ताहीं पर्ची भेजण खातर:\n1. 'ग्राहक' (Customers) स्क्रीन पै उसके नाम पै टैप करो।\n2. उड़े हरे रंग का 'सेंड पर्ची' (WhatsApp) बटन दिखेगा।\n3. उस पै टैप करदे ही उसके WhatsApp पै घंटे, बिल, जमा अर बकाया की रसीद तुरंत चाल्या जावेगी!"
                MunshiLang.BHOJPURI -> "${greeting}किसान के पर्ची भेजे खातिर:\n1. 'ग्राहक' स्क्रीन पर ओकरा नाम पर टैप करीं।\n2. उहाँ हरियर रंग के 'सेंड पर्ची' (WhatsApp) बटन लउकी।\n3. ओकरा पर टैप करतहीं WhatsApp पर घंटा, बिल, जमा आ बकाया के डिजिटल रसीद तुरंत चल जाई!"
                MunshiLang.RAJASTHANI -> "${greeting}किसान ने परची भेजवा सारू:\n1. 'ग्राहक' स्क्रीन मांय किसान रे नाम माथे टैप करो।\n2. उण मांय हरी रंग रो 'सेंड पर्ची' (WhatsApp) बटन दिखेला।\n3. उण पै टैप करतां ही किसान रे WhatsApp पै घंटा, बिल, जमा अर बकाया री रसीद झटपट जावेला सा!"
                MunshiLang.PUNJABI -> "${greeting}ਕਿਸਾਨ ਨੂੰ ਪਰਚੀ ਭੇਜਣ ਲਈ:\n1. 'ਗਾਹਕ' (Customers) ਸਕ੍ਰੀਨ 'ਤੇ ਉਸਦੇ ਨਾਮ 'ਤੇ ਟੈਪ ਕਰੋ।\n2. ਉੱਥੇ ਹਰੇ ਰੰਗ ਦਾ 'ਸੈਂਡ ਪਰਚੀ' (WhatsApp) ਬਟਨ ਹੈ।\n3. ਉਸ 'ਤੇ ਟੈਪ ਕਰਦਿਆਂ ਹੀ WhatsApp 'ਤੇ ਘੰਟੇ, ਬਿੱਲ, ਜਮ੍ਹਾਂ ਅਤੇ ਬਕਾਏ ਦੀ ਰਸੀਦ ਤੁਰੰਤ ਚਲੀ ਜਾਵੇਗੀ!"
                MunshiLang.ENGLISH -> "${greeting}To send a digital receipt:\n1. Tap the farmer's name in 'Customers'.\n2. Tap the green 'Send Parchhi' (WhatsApp) button.\n3. A full receipt with running hours, total bill, payments, and balance is sent instantly via WhatsApp!"
                else -> "${greeting}किसान को पर्ची या हिसाब भेजने के लिए:\n1. 'ग्राहक' (Customers) स्क्रीन पर उस किसान के नाम पर टैप करें।\n2. वहाँ हरे रंग का 'सेंड पर्ची' (WhatsApp) बटन दिखेगा।\n3. उस पर टैप करते ही किसान के WhatsApp पर पूरे घंटे, बिल, जमा और बकाया की सुंदर डिजिटल रसीद तुरंत चली जाएगी।"
            }
        }

        // =========================================================================
        // 10. Buttons & Navigation Guidance (नया किसान कैसे जोड़ें)
        // =========================================================================
        val isAddCustomerQuery = (q.contains("किसान") || q.contains("ग्राहक") ||
                q.contains("कस्टमर") || q.contains("customer") || q.contains("खाता")) &&
                (q.contains("जोड़") || q.contains("add") || q.contains("बना") || q.contains("खोल") ||
                 q.contains("कैसे") || q.contains("बटन") || q.contains("कहाँ") || q.contains("किधर") || q.contains("रंग"))

        if (isAddCustomerQuery) {
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}नया गिराहक जोड़ण खातर नीचे 'ग्राहक' (Customers) टैब पै जा भाई। उड़े नीचे दाएँ कोने पै लाल रंग का गोल बटन ('+ नया किसान जोड़ें') सै। उस पै टैप करकै किसान का नाम, बाबू का नाम अर फोन नंबर लिख द्यो।"
                MunshiLang.BHOJPURI -> "${greeting}नया किसान जोड़े खातिर नीचे 'ग्राहक' टैब पर जाईं। उहाँ नीचे दहिनें कोना में लाल रंग के गोल बटन ('+ नया किसान जोड़ें') बा। ओकरा पर टैप करके किसान के नाम, पिता के नाम आ मोबाइल नंबर डाल दीहीं।"
                MunshiLang.RAJASTHANI -> "${greeting}नयो किसान जोड़वा सारू नीचे 'ग्राहक' टैब माथे जाओ सा। उण रे नीचे जमणे हाथे लाल रंग रो गोल बटन ('+ नया किसान जोड़ें') छै। उण पै दबा'र किसान रो नाम, पिता रो नाम अर मोबाइल नंबर लिख दीज्यो सा।"
                MunshiLang.PUNJABI -> "${greeting}ਨਵਾਂ ਕਿਸਾਨ ਜੋੜਨ ਲਈ ਹੇਠਾਂ 'ਗਾਹਕ' (Customers) ਟੈਬ 'ਤੇ ਜਾਓ। ਉੱਥੇ ਹੇਠਾਂ ਸੱਜੇ ਪਾਸੇ ਲਾਲ ਰੰਗ ਦਾ ਗੋਲ ਬਟਨ ('+ ਨਵਾਂ ਕਿਸਾਨ ਜੋੜੋ') ਹੈ। ਉਸ 'ਤੇ ਟੈਪ ਕਰਕੇ ਨਾਮ, ਪਿਤਾ ਦਾ ਨਾਮ ਅਤੇ ਫੋਨ ਨੰਬਰ ਦਰਜ ਕਰੋ।"
                MunshiLang.ENGLISH -> "${greeting}To add a new farmer, tap the 'Customers' tab at the bottom. Then tap the red circular button ('+ Add New Farmer') in the bottom-right corner, enter their details, and save."
                else -> "${greeting}नया किसान (ग्राहक) जोड़ने के लिए नीचे 'ग्राहक' (Customers) टैब पर जाएं। वहाँ नीचे दाएँ कोने पर लाल रंग का गोल बटन ('+ नया किसान जोड़ें') है। उस पर टैप करके किसान का नाम, पिता का नाम व मोबाइल नंबर दर्ज करें।"
            }
        }

        // =========================================================================
        // 11. How to Start Session / Irrigation (सिंचाई कैसे चालू करें / नया सत्र)
        // =========================================================================
        if ((q.contains("सिंचाई") || q.contains("सत्र") || q.contains("session") || q.contains("पानी") || q.contains("ट्यूबवेल")) &&
            (q.contains("चालू") || q.contains("शुरू") || q.contains("start") || q.contains("कैसे") || q.contains("मीटर"))
        ) {
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}नया सत्र चालू करण खातर होम स्क्रीन पै हरे रंग के बटन ('▶ नया सिंचाई सत्र') पै टैप करो भाई। गिराहक छांटो, टाइम या मीटर रीडिंग डालकै सत्र चालू कर द्यो।"
                MunshiLang.BHOJPURI -> "${greeting}नया सत्र शुरू करे खातिर होम स्क्रीन पर हरियर बटन ('▶ नया सिंचाई सत्र') पर टैप करीं। किसान चुनीं, टाइम भा मीटर रीडिंग डाल के चालू कर दीहीं।"
                MunshiLang.RAJASTHANI -> "${greeting}नयो सत्र चालू करवा सारू होम स्क्रीन माथे हरी रंग रो बटन ('▶ नया सिंचाई सत्र') दबाओ। किसान छांटो, टाइम या मीटर रीडिंग डाल'र सत्र चालू कर द्यो सा।"
                MunshiLang.PUNJABI -> "${greeting}ਨਵਾਂ ਸਿੰਚਾਈ ਸੈਸ਼ਨ ਸ਼ੁਰੂ ਕਰਨ ਲਈ ਹੋਮ ਸਕ੍ਰੀਨ 'ਤੇ ਹਰੇ ਰੰਗ ਦੇ ਬਟਨ ('▶ ਨਵਾਂ ਸਿੰਚਾਈ ਸੈਸ਼ਨ') 'ਤੇ ਟੈਪ ਕਰੋ। ਕਿਸਾਨ ਚੁਣੋ ਅਤੇ ਟਾਈਮ ਜਾਂ ਮੀਟਰ ਰੀਡਿੰਗ ਦਰਜ ਕਰਕੇ ਸੈਸ਼ਨ ਸ਼ੁਰੂ ਕਰੋ।"
                MunshiLang.ENGLISH -> "${greeting}To start an irrigation session, tap the green '▶ Start New Session' button on the Home screen. Select the farmer, enter start time or meter reading, and start the timer."
                else -> "${greeting}नया सिंचाई सत्र शुरू करने के लिए होम स्क्रीन पर हरे रंग के बटन ('▶ नया सिंचाई सत्र') पर टैप करें। किसान चुनें, समय या मीटर रीडिंग डालें और सत्र चालू कर दें।"
            }
        }

        // =========================================================================
        // 12. How to Record Payment / Jama (पैसे कैसे जमा करें / भुगतान)
        // =========================================================================
        if ((q.contains("पैसा") || q.contains("पैसे") || q.contains("रुपये") || q.contains("जमा") || q.contains("भुगतान") || q.contains("payment")) &&
            (q.contains("कैसे") || q.contains("कहाँ") || q.contains("दर्ज") || q.contains("करूं") || q.contains("करें"))
        ) {
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}पैसे जमा करण खातर 'ग्राहक' स्क्रीन पै उस गिराहक के नाम पै टैप करो भाई, फेर नीचे '₹ भुगतान दर्ज करें' दबाकै जमा रकम भर द्यो।"
                MunshiLang.BHOJPURI -> "${greeting}पैसा जमा करे खातिर 'ग्राहक' स्क्रीन पर किसान के नाम पर टैप करीं, फेर नीचे '₹ भुगतान दर्ज करें' दबा के जमा रकम भर दीहीं।"
                MunshiLang.RAJASTHANI -> "${greeting}रुपिया जमा करवा सारू 'ग्राहक' स्क्रीन मांय किसान रे नाम पै टैप करो, फेर नीचे '₹ भुगतान दर्ज करें' दबा'र रकम भर दीज्यो सा।"
                MunshiLang.PUNJABI -> "${greeting}ਪੈਸੇ ਜਮ੍ਹਾਂ ਕਰਨ ਲਈ 'ਗਾਹਕ' ਸਕ੍ਰੀਨ 'ਤੇ ਕਿਸਾਨ ਦੇ ਨਾਮ 'ਤੇ ਟੈਪ ਕਰੋ, ਫਿਰ ਹੇਠਾਂ '₹ ਭੁਗਤਾਨ ਦਰਜ ਕਰੋ' ਦਬਾ ਕੇ ਰਕਮ ਭਰੋ।"
                MunshiLang.ENGLISH -> "${greeting}To record a payment, tap the farmer's name in the 'Customers' screen, then tap '₹ Record Payment' at the bottom and enter the amount received."
                else -> "${greeting}पैसे जमा करने के लिए 'ग्राहक' (Customers) स्क्रीन पर उस किसान के नाम पर टैप करें। फिर नीचे '₹ भुगतान दर्ज करें' बटन दबाकर जमा रकम भर दें।"
            }
        }

        // =========================================================================
        // 13. Hourly Rate (सिंचाई दर / भाव / रेट)
        // =========================================================================
        if ((q.contains("दर") || q.contains("रेट") || q.contains("प्रति घंटा") || q.contains("भाव") || q.contains("rate")) &&
            !q.contains("रमेश") && !q.contains("अनीता") && !q.contains("सोनू") && !q.contains("सुरेश")
        ) {
            val rate = profile?.ratePerHour ?: 160.0
            val rateStr = "%.0f".format(rate)
            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}इब थारे ट्यूबवेल का रेट ₹$rateStr प्रति घंटा सेट सै भाई। सेटिंग्स म्ह जाकै थू इब कदे भी बदल सकै सै।"
                MunshiLang.BHOJPURI -> "${greeting}अहिले रउआ ट्यूबवेल के रेट ₹$rateStr प्रति घंटा सेट बा। सेटिंग्स में जाके रउआ जब मन करे बदल सकेनी।"
                MunshiLang.RAJASTHANI -> "${greeting}अबे थांके ट्यूबवेल रो भाव ₹$rateStr प्रति घंटा तय छै सा। थे सेटिंग्स मांय जा'र कदे भी बदल सको छा।"
                MunshiLang.PUNJABI -> "${greeting}ਇਸ ਵੇਲੇ ਤੁਹਾਡੇ ਟਿਊਬਵੈੱਲ ਦੀ ਦਰ ₹$rateStr ਪ੍ਰਤੀ ਘੰਟਾ ਸੈੱਟ ਹੈ। ਤੁਸੀਂ ਸੈਟਿੰਗਜ਼ ਵਿੱਚ ਜਾ ਕੇ ਕਿਸੇ ਵੀ ਵੇਲੇ ਬਦਲ ਸਕਦੇ ਹੋ।"
                MunshiLang.ENGLISH -> "${greeting}Currently your tubewell irrigation rate is set to ₹$rateStr per hour. You can update this anytime in Settings."
                else -> "${greeting}वर्तमान में आपकी सामान्य ट्यूबवेल सिंचाई दर ₹$rateStr प्रति घंटा सेट है। आप इसे सेटिंग्स में कभी भी बदल सकते हैं।"
            }
        }

        // =========================================================================
        // 14. Age of Dues (1 महीने से पुराने, 1 साल से पुराने, 2 साल से पुराने बकाया/उधार)
        // E.g. "1 साल से ज्यादा कितने लोगों का उधार है", "1 साल पुराना बकाया", "साल भर से पुराना"
        // =========================================================================
        val isOldDuesQuery = (q.contains("महीने") || q.contains("महीना") || q.contains("साल") ||
                q.contains("वर्ष") || q.contains("पुराना") || q.contains("पुराने") || q.contains("पुरानी") ||
                q.contains("लंबे समय") || q.contains("काफी दिन") || q.contains("बहुत दिन")) &&
                (q.contains("बकाया") || q.contains("बाकी") || q.contains("उधारी") || q.contains("उधार") ||
                 q.contains("लोग") || q.contains("लोगों") || q.contains("किसान") || q.contains("ग्राहक") ||
                 q.contains("किसका") || q.contains("किनका") || q.contains("कितने") || q.contains("कितनों"))

        if (isOldDuesQuery) {
            val nowMs = System.currentTimeMillis()
            val dayMillis = 24L * 60 * 60 * 1000L

            val (thresholdDays, timeLabel) = when {
                q.contains("3 साल") || q.contains("तीन साल") -> Pair(1095L, "3 साल")
                q.contains("2 साल") || q.contains("दो साल") || q.contains("2 वर्ष") -> Pair(730L, "2 साल")
                q.contains("1 साल") || q.contains("एक साल") || q.contains("1 वर्ष") || q.contains("साल भर") || q.contains("साल") -> Pair(365L, "1 साल")
                q.contains("6 महीने") || q.contains("छह महीने") || q.contains("छः महीने") || q.contains("6 महीना") -> Pair(180L, "6 महीने")
                q.contains("3 महीने") || q.contains("तीन महीने") || q.contains("3 महीना") -> Pair(90L, "3 महीने")
                q.contains("2 महीने") || q.contains("दो महीने") -> Pair(60L, "2 महीने")
                q.contains("1 महीने") || q.contains("एक महीने") || q.contains("महीने") || q.contains("महीना") -> Pair(30L, "1 महीने")
                else -> Pair(365L, "1 साल")
            }

            val thresholdMs = thresholdDays * dayMillis
            val oldDuesCusts = customersWithStats.filter { item ->
                if (item.netDue <= 0) return@filter false
                val isOldByCreated = (nowMs - item.customer.createdAt >= thresholdMs)
                val isOldBySession = item.lastSessionDate != null && (nowMs - item.lastSessionDate >= thresholdMs)
                val hasOldSessions = sessions.any { it.customerId == item.customer.id && (nowMs - it.sessionDate >= thresholdMs) }
                val hasOldOpeningBalance = item.customer.initialBalance > 0 && isOldByCreated
                isOldByCreated || isOldBySession || hasOldSessions || hasOldOpeningBalance
            }

            return if (oldDuesCusts.isEmpty()) {
                val currentDueCustsCount = customersWithStats.count { it.netDue > 0 }
                val totalCurrentDue = customersWithStats.filter { it.netDue > 0 }.sumOf { it.netDue }
                val extraNote = if (currentDueCustsCount > 0) {
                    when (lang) {
                        MunshiLang.HARYANVI -> " (वैसे हाल के $currentDueCustsCount गिराहकां पै कुल ₹${"%.0f".format(totalCurrentDue)} बाकी सै, पर $timeLabel तै पुराना कोई कोन्या।)"
                        MunshiLang.BHOJPURI -> " (बाकि हाल के $currentDueCustsCount गो किसानन पर कुल ₹${"%.0f".format(totalCurrentDue)} बाकी बा, बाकिर $timeLabel से पुरान केहू नइखे।)"
                        MunshiLang.RAJASTHANI -> " (अलबत्ता हाल रा $currentDueCustsCount किसानां माथे कुल ₹${"%.0f".format(totalCurrentDue)} बाकी छै, पण $timeLabel सूं पुराणो कोई कोनी सा।)"
                        else -> " (वैसे हाल के कुल $currentDueCustsCount किसानों पर ₹${"%.0f".format(totalCurrentDue)} बकाया है, लेकिन $timeLabel से पुराना कोई नहीं है।)"
                    }
                } else ""

                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}$timeLabel तै पुराना किसे भी गिराहक का कोई उधार या बकाया कोन्या भाई। सारा हिसाब समय पै चाल रह्या सै!$extraNote"
                    MunshiLang.BHOJPURI -> "${greeting}$timeLabel से पुरान कवनो किसान के उधार भा बकाया नइखे। सभकर हिसाब-किताब टाइम पर चल रहल बा!$extraNote"
                    MunshiLang.RAJASTHANI -> "${greeting}$timeLabel सूं पुराणो कोई भी किसान रो उधार या बकाया कोनी सा। सगळा हिसाब समय माथे चाल रह्यो छै!$extraNote"
                    MunshiLang.PUNJABI -> "${greeting}$timeLabel ਤੋਂ ਪੁਰਾਣਾ ਕਿਸੇ ਵੀ ਕਿਸਾਨ ਦਾ ਕੋਈ ਉਧਾਰ ਜਾਂ ਬਕਾਇਆ ਨਹੀਂ ਹੈ। ਸਾਰੇ ਹਿਸਾਬ ਸਮੇਂ ਸਿਰ ਹਨ!$extraNote"
                    MunshiLang.ENGLISH -> "${greeting}There are no pending dues older than $timeLabel. All accounts are up to date!$extraNote"
                    else -> "${greeting}$timeLabel से पुराना किसी भी किसान का कोई उधार या बकाया नहीं है। आपके सभी किसानों का हिसाब-किताब समय पर चल रहा है!$extraNote"
                }
            } else {
                val totalOldDue = oldDuesCusts.sumOf { it.netDue }
                val names = oldDuesCusts.joinToString(", ") {
                    val sONote = if (it.customer.sO.isNotBlank()) " (पिता: ${it.customer.sO})" else ""
                    "${it.customer.name}$sONote: ₹${"%.0f".format(it.netDue)}"
                }
                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}$timeLabel तै पुराने कुल ${oldDuesCusts.size} गिराहकां पै कुल ₹${"%.0f".format(totalOldDue)} का उधार बकाया सै भाई:\n$names।"
                    MunshiLang.BHOJPURI -> "${greeting}$timeLabel से पुरान कुल ${oldDuesCusts.size} गो किसानन पर ₹${"%.0f".format(totalOldDue)} के उधार बाकी बा:\n$names।"
                    MunshiLang.RAJASTHANI -> "${greeting}$timeLabel सूं पुराणा कुल ${oldDuesCusts.size} किसानां माथे ₹${"%.0f".format(totalOldDue)} रो उधार बाकी छै सा:\n$names।"
                    MunshiLang.PUNJABI -> "${greeting}$timeLabel ਤੋਂ ਪੁਰਾਣੇ ਕੁੱਲ ${oldDuesCusts.size} ਕਿਸਾਨਾਂ ਵੱਲ ₹${"%.0f".format(totalOldDue)} ਉਧਾਰ ਬਾਕੀ ਰਹਿੰਦਾ ਹੈ:\n$names।"
                    MunshiLang.ENGLISH -> "${greeting}Pending dues older than $timeLabel total ₹${"%.0f".format(totalOldDue)} across ${oldDuesCusts.size} farmers:\n$names."
                    else -> "${greeting}$timeLabel से पुराने कुल ${oldDuesCusts.size} किसानों पर ₹${"%.0f".format(totalOldDue)} का उधार बकाया है:\n$names।"
                }
            }
        }

        // =========================================================================
        // 15. Sessions & Monthly Earnings Breakdown: Specific Month, This Month & Today
        // (जैसे: "जनवरी में कुल कितने रु बने", "फरवरी में कितनी सिंचाई हुई", "इस महीने में कितने चले")
        // =========================================================================
        val requestedMonth = extractRequestedMonth(q)
        val isMonthRelated = requestedMonth != null || q.contains("महीने") || q.contains("महीना") || q.contains("month")
        val isEarningOrStats = q.contains("रु") || q.contains("रुपये") || q.contains("रुपए") ||
                q.contains("कमाई") || q.contains("बने") || q.contains("बना") || q.contains("आया") ||
                q.contains("बिल") || q.contains("हिसाब") || q.contains("सत्र") || q.contains("सेशन") ||
                q.contains("सिंचाई") || q.contains("घंटे") || q.contains("चला") || q.contains("चले") ||
                q.contains("ਕਿੰਨੇ") || q.contains("ਸੈਸ਼ਨ") || q.contains("ਚੱਲਿਆ")

        val isSessionStatsQuery = (isMonthRelated && isEarningOrStats) ||
                ((q.contains("सत्र") || q.contains("सेशन") || q.contains("सिंचाई") || q.contains("sechan")) &&
                (q.contains("आज") || q.contains("महीने") || q.contains("चला") || q.contains("चले") ||
                 q.contains("नाम") || q.contains("किसका") || q.contains("कितने") || q.contains("ਚੱਲਿਆ")))

        if (isSessionStatsQuery) {
            val now = System.currentTimeMillis()

            if (requestedMonth != null) {
                // Specific month query (e.g. "जनवरी में कुल कितने रु बने", "मार्च में कितनी कमाई हुई")
                val mName = requestedMonth.nativeNames[lang] ?: requestedMonth.hindiName
                val monthSessions = sessions.filter { isSessionInMonth(it.sessionDate, requestedMonth.monthIndex) }
                val monthHours = monthSessions.sumOf { it.hours }
                val monthAmt = monthSessions.sumOf { it.totalAmount }
                val monthPaid = monthSessions.sumOf { it.paidAmount }

                return if (monthSessions.isEmpty()) {
                    when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}$mName के महीने म्ह कोई सिंचाई सत्र या कमाई दर्ज कोन्या सै भाई।"
                        MunshiLang.BHOJPURI -> "${greeting}$mName महीना में कवनो सिंचाई सत्र भा कमाई दर्ज नइखे भइल।"
                        MunshiLang.RAJASTHANI -> "${greeting}$mName रे महीना मांय कोई सिंचाई सत्र या कमाई दर्ज कोनी छै सा।"
                        MunshiLang.PUNJABI -> "${greeting}$mName ਮਹੀਨੇ ਵਿੱਚ ਕੋਈ ਸਿੰਚਾਈ ਸੈਸ਼ਨ ਜਾਂ ਕਮਾਈ ਦਰਜ ਨਹੀਂ ਹੋਈ ਹੈ।"
                        MunshiLang.ENGLISH -> "${greeting}No irrigation sessions or earnings were recorded for $mName."
                        else -> "${greeting}$mName के महीने में कोई सिंचाई सत्र या कमाई दर्ज नहीं हुई है।"
                    }
                } else {
                    val hrsStr = "%.1f".format(monthHours)
                    val amtStr = "%.0f".format(monthAmt)
                    val paidStr = "%.0f".format(monthPaid)
                    when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}$mName के महीने म्ह कुल ${monthSessions.size} सत्र चाल्ये अर कुल $hrsStr घंटे ट्यूबवेल चाल्या। कुल ₹$amtStr का बिल बण्या (कमाई हुई), जिस म्ह तै ₹$paidStr भुगतान प्राप्त होया सै।"
                        MunshiLang.BHOJPURI -> "${greeting}$mName महीना में कुल ${monthSessions.size} गो सत्र चलल आ कुल $hrsStr घंटा ट्यूबवेल चलल। कुल ₹$amtStr के बिल बनल (कमाई भइल), जेह में से ₹$paidStr भुगतान प्राप्त भइल बा।"
                        MunshiLang.RAJASTHANI -> "${greeting}$mName रे महीना मांय कुल ${monthSessions.size} सत्र चाल्या अर कुल $hrsStr घंटा ट्यूबवेल चाल्यो। पूरो ₹$amtStr रो बिल बन्यो (कमाई हुई), जिण मांय सूं ₹$paidStr भुगतान मिल्यो छै सा।"
                        MunshiLang.PUNJABI -> "${greeting}$mName ਮਹੀਨੇ ਵਿੱਚ ਕੁੱਲ ${monthSessions.size} ਸਿੰਚਾਈ ਸੈਸ਼ਨ ਚੱਲੇ ਅਤੇ ਕੁੱਲ $hrsStr ਘੰਟੇ ਟਿਊਬਵੈੱਲ ਚੱਲਿਆ। ਕੁੱਲ ₹$amtStr ਦਾ ਬਿੱਲ ਬਣਿਆ (ਕਮਾਈ ਹੋਈ), ਜਿਸ ਵਿੱਚੋਂ ₹$paidStr ਭੁਗਤਾਨ ਪ੍ਰਾਪਤ ਹੋਇਆ।"
                        MunshiLang.ENGLISH -> "${greeting}In $mName, ${monthSessions.size} sessions ran for $hrsStr hours. Total billed was ₹$amtStr, with ₹$paidStr collected in payments."
                        else -> "${greeting}$mName के महीने में कुल ${monthSessions.size} सिंचाई सत्र चले और $hrsStr घंटे ट्यूबवेल चला। कुल ₹$amtStr का बिल बना (कमाई हुई), जिसमें से ₹$paidStr भुगतान प्राप्त हुआ।"
                    }
                }
            } else if (q.contains("महीने") || q.contains("महीना") || q.contains("month")) {
                val monthSessions = sessions.filter { isSameMonth(it.sessionDate, now) }
                val monthHours = monthSessions.sumOf { it.hours }
                val monthAmt = monthSessions.sumOf { it.totalAmount }
                val monthPaid = monthSessions.sumOf { it.paidAmount }

                return if (monthSessions.isEmpty()) {
                    when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}इण महीने म्ह इब ताहीं कोई सिंचाई सत्र कोन्या चाल्या सै भाई।"
                        MunshiLang.BHOJPURI -> "${greeting}एह महीना में अभी ले कवनो सिंचाई सत्र दर्ज नइखे भइल।"
                        MunshiLang.RAJASTHANI -> "${greeting}इण महीना मांय अबे तांई कोई सिंचाई सत्र कोनी चाल्यो छै सा।"
                        MunshiLang.PUNJABI -> "${greeting}ਇਸ ਮਹੀਨੇ ਵਿੱਚ ਅਜੇ ਤੱਕ ਕੋਈ ਸਿੰਚਾਈ ਸੈਸ਼ਨ ਦਰਜ ਨਹੀਂ ਹੋਇਆ ਹੈ।"
                        MunshiLang.ENGLISH -> "${greeting}No irrigation sessions have been recorded this month yet."
                        else -> "${greeting}इस महीने में अभी तक कोई सिंचाई सत्र दर्ज नहीं हुआ है।"
                    }
                } else {
                    val hrsStr = "%.1f".format(monthHours)
                    val amtStr = "%.0f".format(monthAmt)
                    val paidStr = "%.0f".format(monthPaid)
                    when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}इण महीने म्ह कुल ${monthSessions.size} सत्र चाल्ये सैं, जिण म्ह कुल $hrsStr घंटे ट्यूबवेल चाल्या सै। सारा बिल ₹$amtStr बण्या अर ₹$paidStr जमा होया सै।"
                        MunshiLang.BHOJPURI -> "${greeting}एह महीना में कुल ${monthSessions.size} गो सत्र चलल बा, जेह में कुल $hrsStr घंटा ट्यूबवेल चलल बा। कुल बिल ₹$amtStr बनल आ ₹$paidStr जमा भइल बा।"
                        MunshiLang.RAJASTHANI -> "${greeting}इण महीना मांय कुल ${monthSessions.size} सत्र चाल्या छै, जिण मांय कुल $hrsStr घंटा ट्यूबवेल चाल्यो छै। पूरो बिल ₹$amtStr बन्यो अर ₹$paidStr जमा हुयो छै सा।"
                        MunshiLang.PUNJABI -> "${greeting}ਇਸ ਮਹੀਨੇ ਕੁੱਲ ${monthSessions.size} ਸਿੰਚਾਈ ਸੈਸ਼ਨ ਚੱਲੇ ਹਨ, ਕੁੱਲ $hrsStr ਘੰਟੇ ਟਿਊਬਵੈੱਲ ਚੱਲਿਆ ਹੈ। ਕੁੱਲ ਬਿੱਲ ₹$amtStr ਬਣਿਆ ਅਤੇ ₹$paidStr ਜਮ੍ਹਾਂ ਹੋਇਆ।"
                        MunshiLang.ENGLISH -> "${greeting}This month a total of ${monthSessions.size} irrigation sessions ran for $hrsStr hours. Total billed is ₹$amtStr and ₹$paidStr payment collected."
                        else -> "${greeting}इस महीने में कुल ${monthSessions.size} सिंचाई सत्र चले हैं, जिनमें कुल $hrsStr घंटे ट्यूबवेल चला है। कुल बिल ₹$amtStr बना और ₹$paidStr भुगतान प्राप्त हुआ।"
                    }
                }
            } else {
                // Today's sessions
                val todaySessions = sessions.filter { isSameDay(it.sessionDate, now) }
                return if (todaySessions.isEmpty()) {
                    when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}आज इब ताहीं कोई नया पाणि/सत्र कोन्या चाल्या सै भाई।"
                        MunshiLang.BHOJPURI -> "${greeting}आजु अभी ले कवनो नया सिंचाई सत्र ना चलल बा।"
                        MunshiLang.RAJASTHANI -> "${greeting}आज अबे तांई कोई नयो सिंचाई सत्र कोनी चाल्यो छै सा।"
                        MunshiLang.PUNJABI -> "${greeting}ਅੱਜ ਹਾਲੇ ਤੱਕ ਕੋਈ ਨਵਾਂ ਸਿੰਚਾਈ ਸੈਸ਼ਨ ਨਹੀਂ ਚੱਲਿਆ ਹੈ।"
                        MunshiLang.ENGLISH -> "${greeting}No irrigation sessions have been recorded today yet."
                        else -> "${greeting}आज अभी तक कोई नया सिंचाई सत्र नहीं चला है।"
                    }
                } else {
                    val todayHours = todaySessions.sumOf { it.hours }
                    val hrsStr = "%.1f".format(todayHours)

                    val customerIdToName = customersWithStats.associate { it.customer.id to it.customer.name }
                    val farmerNames = todaySessions.mapNotNull { customerIdToName[it.customerId] }.distinct()
                    val namesText = if (farmerNames.isNotEmpty()) " आज सिंचाई लेने वाले किसान भाई: ${farmerNames.joinToString(", ")}।" else ""

                    when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}आज कुल ${todaySessions.size} सत्र चाल्ये सैं, जिण म्ह कुल $hrsStr घंटे ट्यूबवेल चाल्या सै।$namesText"
                        MunshiLang.BHOJPURI -> "${greeting}आजु कुल ${todaySessions.size} गो सत्र चलल बा, जेह में कुल $hrsStr घंटा ट्यूबवेल चलल बा।$namesText"
                        MunshiLang.RAJASTHANI -> "${greeting}आज कुल ${todaySessions.size} सत्र चाल्या छै, जिण मांय कुल $hrsStr घंटा ट्यूबवेल चाल्यो छै सा।$namesText"
                        MunshiLang.PUNJABI -> "${greeting}ਅੱਜ ਕੁੱਲ ${todaySessions.size} ਸੈਸ਼ਨ ਚੱਲੇ ਹਨ, ਜਿਨ੍ਹਾਂ ਵਿੱਚ ਕੁੱਲ $hrsStr ਘੰਟੇ ਟਿਊਬਵੈੱਲ ਚੱਲਿਆ ਹੈ।$namesText"
                        MunshiLang.ENGLISH -> "${greeting}Today a total of ${todaySessions.size} sessions ran for $hrsStr hours.$namesText"
                        else -> "${greeting}आज कुल ${todaySessions.size} सत्र चले हैं, जिनमें कुल $hrsStr घंटे ट्यूबवेल चला है।$namesText"
                    }
                }
            }
        }

        // =========================================================================
        // 16. Cash Collections / Jama (कितने नगद जमा हैं / भुगतान आया)
        // =========================================================================
        val isCashDepositQuery = (q.contains("नगद") || q.contains("कैश") || q.contains("भुगतान") ||
                (q.contains("जमा") && (q.contains("कितना") || q.contains("कितने") || q.contains("किसने") || q.contains("नाम")))) &&
                !q.contains("कैसे जमा")

        if (isCashDepositQuery) {
            val totalPaid = customersWithStats.sumOf { it.totalPaid }
            val paidCusts = customersWithStats.filter { it.totalPaid > 0 }

            return if (q.contains("नाम") || q.contains("किसने") || q.contains("लिस्ट")) {
                if (paidCusts.isEmpty()) {
                    when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}इब ताहीं किसे भी गिराहक तै कोई नगद जमा कोन्या मिल्या सै।"
                        MunshiLang.BHOJPURI -> "${greeting}अभी ले केहू किसान से कवनो नगद जमा नइखे मिलल।"
                        MunshiLang.RAJASTHANI -> "${greeting}अबे तांई किणी भी किसान सूं कोई रोकड़ जमा कोनी मिल्यो छै सा।"
                        MunshiLang.PUNJABI -> "${greeting}ਅਜੇ ਤੱਕ ਕਿਸੇ ਵੀ ਕਿਸਾਨ ਵੱਲੋਂ ਕੋਈ ਨਕਦ ਜਮ੍ਹਾਂ ਨਹੀਂ ਕਰਵਾਇਆ ਗਿਆ।"
                        MunshiLang.ENGLISH -> "${greeting}No cash payments or advance deposits have been recorded yet."
                        else -> "${greeting}अभी तक किसी भी किसान द्वारा कोई अग्रिम या नगद जमा नहीं कराया गया है।"
                    }
                } else {
                    val names = paidCusts.joinToString(", ") { "${it.customer.name} (₹${"%.0f".format(it.totalPaid)})" }
                    when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}इब ताहीं कुल ₹${"%.0f".format(totalPaid)} नगद जमा होया सै। जमा करण आले भाई: $names।"
                        MunshiLang.BHOJPURI -> "${greeting}अब तक कुल ₹${"%.0f".format(totalPaid)} नगद जमा मिलल बा। जमा करे वाला भाई लोग: $names।"
                        MunshiLang.RAJASTHANI -> "${greeting}अबे तांई कुल ₹${"%.0f".format(totalPaid)} रोकड़ जमा मिल्यो छै। जमा करवा वाला किसान भाई: $names सा।"
                        MunshiLang.PUNJABI -> "${greeting}ਹੁਣ ਤੱਕ ਕੁੱਲ ₹${"%.0f".format(totalPaid)} ਨਕਦ ਜਮ੍ਹਾਂ ਪ੍ਰਾਪਤ ਹੋਇਆ ਹੈ: $names।"
                        MunshiLang.ENGLISH -> "${greeting}Total cash collections stand at ₹${"%.0f".format(totalPaid)}. Paying farmers: $names."
                        else -> "${greeting}अब तक कुल ₹${"%.0f".format(totalPaid)} नगद जमा प्राप्त हुआ है। जमा करने वाले किसान भाई: $names।"
                    }
                }
            } else {
                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}इब ताहीं बही-खाते म्ह कुल ${paidCusts.size} गिराहकां तै कुल ₹${"%.0f".format(totalPaid)} नगद जमा मिल्या सै भाई।"
                    MunshiLang.BHOJPURI -> "${greeting}अब तक बही-खाता में कुल ${paidCusts.size} गो किसानन से कुल ₹${"%.0f".format(totalPaid)} नगद जमा मिलल बा।"
                    MunshiLang.RAJASTHANI -> "${greeting}अबे तांई बही-खाता मांय कुल ${paidCusts.size} किसानां सूं कुल ₹${"%.0f".format(totalPaid)} रोकड़ जमा मिल्यो छै सा।"
                    MunshiLang.PUNJABI -> "${greeting}ਹੁਣ ਤੱਕ ਬਹੀ-ਖਾਤੇ ਵਿੱਚ ਕੁੱਲ ${paidCusts.size} ਕਿਸਾਨਾਂ ਤੋਂ ਕੁੱਲ ₹${"%.0f".format(totalPaid)} ਨਕਦ ਜਮ੍ਹਾਂ ਪ੍ਰਾਪਤ ਹੋਇਆ ਹੈ।"
                    MunshiLang.ENGLISH -> "${greeting}A total of ₹${"%.0f".format(totalPaid)} in cash payments has been collected from ${paidCusts.size} farmers so far."
                    else -> "${greeting}अब तक बही-खाते में कुल ${paidCusts.size} किसानों से कुल ₹${"%.0f".format(totalPaid)} नगद जमा (भुगतान) प्राप्त हुआ है।"
                }
            }
        }

        // (Specific Customer Query is now handled with top priority in Section 4.5 at the top)

        // =========================================================================
        // 18. Dues Breakdown (When explicitly asked: "किस-किस का बकाया है", "सबके नाम बताओ", "कितने लोगों का उधार है")
        // =========================================================================
        val isExplicitNamesRequest = (q.contains("किस-किस") || q.contains("किस किस") || q.contains("किनका") ||
                q.contains("किन किन") || q.contains("नाम बताओ") || q.contains("who owes") ||
                q.contains("किहका") || q.contains("ਕਿਹਦਾ") || q.contains("ਕਿਸ ਦਾ") || q.contains("किण-किण") ||
                q.contains("किण रो") || q.contains("लिस्ट बताओ") || q.contains("कितने लोगों") ||
                q.contains("कितने किसान") || q.contains("कितने ग्राहकों") || q.contains("कितनों का") ||
                q.contains("कौन-कौन") || q.contains("कौन कौन") || q.contains("किन-किन") ||
                q.contains("किसका किसका") || q.contains("किसका-किसका"))

        if (isExplicitNamesRequest && (q.contains("बकाया") || q.contains("बाकी") || q.contains("उधार") || q.contains("उधारी") || q.contains("कर्ज") || q.contains("due") || q.contains("money") || q.contains("ਲੈਣਾ"))) {
            val dueCusts = customersWithStats.filter { it.netDue > 0 }
            return if (dueCusts.isEmpty()) {
                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}सारे गिराहकां का हिसाब बिल्कुल चुकता सै भाई! किसे का भी कोई उधार या बकाया कोन्या।"
                    MunshiLang.BHOJPURI -> "${greeting}सभई किसानन के हिसाब एकदम चुकता बा! केहू के कवनो उधार भा बकाया नइखे।"
                    MunshiLang.RAJASTHANI -> "${greeting}सगळा किसानां रो हिसाब बिल्कुल चुकता छै सा! किणी रो भी कोई उधार या बकाया कोनी।"
                    MunshiLang.PUNJABI -> "${greeting}ਸਾਰੇ ਕਿਸਾਨਾਂ ਦਾ ਹਿਸਾਬ ਬਿਲਕੁਲ ਚੁਕਤਾ ਹੈ! ਕਿਸੇ ਵੱਲ ਕੋਈ ਉਧਾਰ ਜਾਂ ਬਕਾਇਆ ਨਹੀਂ ਰਹਿੰਦਾ।"
                    MunshiLang.ENGLISH -> "${greeting}All farmers' accounts are fully settled! There are no pending dues."
                    else -> "${greeting}सभी किसानों का हिसाब बिल्कुल चुकता है! किसी का भी कोई उधार या बकाया नहीं है।"
                }
            } else {
                val listStr = dueCusts.joinToString(", ") {
                    val soStr = if (it.customer.sO.isNotBlank()) " (${it.customer.sO})" else ""
                    "${it.customer.name}$soStr: ₹${"%.0f".format(it.netDue)}"
                }
                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}कुल ${dueCusts.size} गिराहकां पै उधार/बकाया बाकी सै भाई:\n$listStr।"
                    MunshiLang.BHOJPURI -> "${greeting}कुल ${dueCusts.size} गो किसानन पर उधार/बकाया बाकी बा:\n$listStr।"
                    MunshiLang.RAJASTHANI -> "${greeting}कुल ${dueCusts.size} किसानां माथे उधार/बकाया बाकी छै सा:\n$listStr।"
                    MunshiLang.PUNJABI -> "${greeting}ਕੁੱਲ ${dueCusts.size} ਕਿਸਾਨਾਂ ਵੱਲ ਉਧਾਰ/ਬਕਾਇਆ ਰਹਿੰਦਾ ਹੈ:\n$listStr।"
                    MunshiLang.ENGLISH -> "${greeting}${dueCusts.size} farmers have pending dues:\n$listStr."
                    else -> "${greeting}कुल ${dueCusts.size} किसानों पर उधार/बकाया बाकी है:\n$listStr।"
                }
            }
        }

        // =========================================================================
        // 18.5 Cleared Accounts (चुकता लोग कितने हैं / किसका पूरा हिसाब चुकता है)
        // =========================================================================
        val isClearedAccountsQuery = (q.contains("चुकता") || q.contains("पूरा हिसाब") || q.contains("जीरो बकाया") || q.contains("शून्य बकाया") || q.contains("no dues") || q.contains("settled")) &&
                (q.contains("कितने") || q.contains("कौन") || q.contains("लोग") || q.contains("किसान") || q.contains("ग्राहक") || q.contains("लिस्ट") || q.contains("नाम"))

        if (isClearedAccountsQuery) {
            val clearedCusts = customersWithStats.filter { it.netDue <= 0 }
            return if (clearedCusts.isEmpty()) {
                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}इब ताहीं सारे गिराहकां पै कुछ न कुछ बाकी सै भाई। कोई भी खाता पूरा चुकता कोन्या।"
                    MunshiLang.BHOJPURI -> "${greeting}अभी सभई किसानन पर कुछ न कुछ बाकी बा। कवनो खाता पूरा चुकता नइखे।"
                    MunshiLang.RAJASTHANI -> "${greeting}अबे तांई सगळा किसानां माथे कुछ न कुछ बकाया छै सा। कोई भी पूरो चुकता कोनी।"
                    MunshiLang.PUNJABI -> "${greeting}ਇਸ ਵੇਲੇ ਸਾਰੇ ਕਿਸਾਨਾਂ ਵੱਲ ਕੁਝ ਨਾ ਕੁਝ ਬਕਾਇਆ ਹੈ। ਕੋਈ ਵੀ ਖਾਤਾ ਪੂਰਾ ਚੁਕਤਾ ਨਹੀਂ ਹੈ।"
                    MunshiLang.ENGLISH -> "${greeting}Currently all farmers have some pending dues. No account is fully settled at ₹0 balance."
                    else -> "${greeting}वर्तमान में आपके सभी किसानों पर कुछ न कुछ बकाया बाकी है। अभी कोई भी खाता पूर्णतः चुकता (₹0) नहीं है।"
                }
            } else {
                val names = clearedCusts.joinToString(", ") { it.customer.name }
                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}कुल ${clearedCusts.size} गिराहकां का हिसाब बिल्कुल चुकता (₹0 बकाया) सै भाई:\n$names।"
                    MunshiLang.BHOJPURI -> "${greeting}कुल ${clearedCusts.size} गो किसानन के हिसाब एकदम चुकता (₹0 बाकी) बा:\n$names।"
                    MunshiLang.RAJASTHANI -> "${greeting}कुल ${clearedCusts.size} किसानां रो हिसाब बिल्कुल चुकता (₹0 बकाया) छै सा:\n$names।"
                    MunshiLang.PUNJABI -> "${greeting}ਕੁੱਲ ${clearedCusts.size} ਕਿਸਾਨਾਂ ਦਾ ਹਿਸਾਬ ਬਿਲਕੁਲ ਚੁਕਤਾ (₹0 ਬਕਾਇਆ) ਹੈ:\n$names।"
                    MunshiLang.ENGLISH -> "${greeting}A total of ${clearedCusts.size} farmers are fully settled with ₹0 pending balance:\n$names."
                    else -> "${greeting}कुल ${clearedCusts.size} किसानों का हिसाब बिल्कुल चुकता (₹0 बकाया) है:\n$names।"
                }
            }
        }

        // =========================================================================
        // 18.6 Weekly / This Week's Ledger (इस सप्ताह का कितना बकाया है / इस हफ्ते कितना चला)
        // =========================================================================
        val isWeeklyQuery = q.contains("सप्ताह") || q.contains("हफ्ता") || q.contains("हफ्ते") || q.contains("week") || q.contains("weekly")
        if (isWeeklyQuery && (q.contains("कितना") || q.contains("घंटे") || q.contains("बकाया") || q.contains("चला") || q.contains("चले") || q.contains("कमाई") || q.contains("सत्र") || q.contains("हिसाब"))) {
            val nowMs = System.currentTimeMillis()
            val weekMs = 7L * 24 * 60 * 60 * 1000L
            val weekSessions = sessions.filter { (nowMs - it.sessionDate) <= weekMs }
            val weekHours = weekSessions.sumOf { it.hours }
            val weekBilled = weekSessions.sumOf { it.totalAmount }
            val weekPaid = weekSessions.sumOf { it.paidAmount }
            val weekDue = (weekBilled - weekPaid).coerceAtLeast(0.0)

            return if (weekSessions.isEmpty()) {
                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}इण सप्ताह (पाछले 7 दिनां म्ह) कोई नया सत्र कोन्या चाल्या सै भाई।"
                    MunshiLang.BHOJPURI -> "${greeting}एह सप्ताह (पिछिला 7 दिन में) कवनो नया सत्र नइखे चलल।"
                    MunshiLang.RAJASTHANI -> "${greeting}इण सप्ताह (पाछला 7 दिनां मांय) कोई नयो सत्र कोनी चाल्यो छै सा।"
                    MunshiLang.PUNJABI -> "${greeting}ਇਸ ਹਫ਼ਤੇ (ਪਿਛਲੇ 7 ਦਿਨਾਂ ਵਿੱਚ) ਕੋਈ ਨਵਾਂ ਸਿੰਚਾਈ ਸੈਸ਼ਨ ਨਹੀਂ ਚੱਲਿਆ ਹੈ।"
                    MunshiLang.ENGLISH -> "${greeting}No irrigation sessions have been recorded this week (in the last 7 days)."
                    else -> "${greeting}इस सप्ताह (पिछले 7 दिनों में) कोई नया सिंचाई सत्र दर्ज नहीं हुआ है।"
                }
            } else {
                when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}इण सप्ताह कुल ${weekSessions.size} सत्र चाल्ये सैं, जिण म्ह कुल ${"%.1f".format(weekHours)} घंटे ट्यूबवेल चाल्या। कुल बिल ₹${"%.0f".format(weekBilled)} बण्या, ₹${"%.0f".format(weekPaid)} जमा होया अर ₹${"%.0f".format(weekDue)} बाकी सै।"
                    MunshiLang.BHOJPURI -> "${greeting}एह हफ्ता कुल ${weekSessions.size} गो सत्र चलल बा, जेह में कुल ${"%.1f".format(weekHours)} घंटा ट्यूबवेल चलल। कुल बिल ₹${"%.0f".format(weekBilled)} बनल, ₹${"%.0f".format(weekPaid)} जमा भइल आ ₹${"%.0f".format(weekDue)} बाकी बा।"
                    MunshiLang.RAJASTHANI -> "${greeting}इण सप्ताह कुल ${weekSessions.size} सत्र चाल्या छै, जिण मांय कुल ${"%.1f".format(weekHours)} घंटा ट्यूबवेल चाल्यो। पूरो बिल ₹${"%.0f".format(weekBilled)} बन्यो, ₹${"%.0f".format(weekPaid)} जमा हुयो अर ₹${"%.0f".format(weekDue)} बाकी छै सा।"
                    MunshiLang.PUNJABI -> "${greeting}ਇਸ ਹਫ਼ਤੇ ਕੁੱਲ ${weekSessions.size} ਸੈਸ਼ਨ ਚੱਲੇ ਹਨ, ਕੁੱਲ ${"%.1f".format(weekHours)} ਘੰਟੇ ਟਿਊਬਵੈੱਲ ਚੱਲਿਆ। ਕੁੱਲ ਬਿੱਲ ₹${"%.0f".format(weekBilled)} ਬਣਿਆ, ₹${"%.0f".format(weekPaid)} ਜਮ੍ਹਾਂ ਹੋਇਆ ਅਤੇ ₹${"%.0f".format(weekDue)} ਬਾਕੀ ਹੈ।"
                    MunshiLang.ENGLISH -> "${greeting}This week a total of ${weekSessions.size} sessions ran for ${"%.1f".format(weekHours)} hours. Total billed was ₹${"%.0f".format(weekBilled)}, payments collected ₹${"%.0f".format(weekPaid)}, and ₹${"%.0f".format(weekDue)} is pending."
                    else -> "${greeting}इस सप्ताह (पिछले 7 दिनों में) कुल ${weekSessions.size} सिंचाई सत्र चले हैं, जिनमें कुल ${"%.1f".format(weekHours)} घंटे ट्यूबवेल चला है। कुल बिल ₹${"%.0f".format(weekBilled)} बना, जमा ₹${"%.0f".format(weekPaid)} प्राप्त हुआ और ₹${"%.0f".format(weekDue)} बकाया है।"
                }
            }
        }

        // =========================================================================
        // 18.7 PDF Guide (रिपोर्ट्स वाली की पीडीएफ कैसे बनाएं / मास्टर पीडीएफ)
        // =========================================================================
        val isPdfGuideQuery = q.contains("पीडीएफ") || q.contains("pdf") || (q.contains("रिपोर्ट") && (q.contains("डाउनलोड") || q.contains("निकाल") || q.contains("प्रिंट")))
        if (isPdfGuideQuery && (q.contains("कैसे") || q.contains("कहाँ") || q.contains("बनाएं") || q.contains("बनाए") || q.contains("निकालें") || q.contains("प्रिंट") || q.contains("शेयर") || q.contains("बनेगी"))) {
            return "${greeting}पीडीएफ रिपोर्ट बनाने के 2 आसान तरीके हैं:\n" +
                    "1. मास्टर रिपोर्ट पीडीएफ (सभी किसानों का पूरा हिसाब): नीचे 'रिपोर्ट्स' (Reports) टैब पर टैप करें। ऊपर '📄 मास्टर PDF रिपोर्ट' बटन दबाएं। अपनी पसंद की समय अवधि (आज, सप्ताह, महीना या सभी) चुनकर तुरंत पक्की पीडीएफ डाउनलोड व शेयर करें।\n" +
                    "2. किसी एक किसान की पीडीएफ रसीद: 'ग्राहक' (Customers) टैब में उस किसान के नाम पर टैप करें और ऊपर नीले रंग का '📄 PDF' बटन दबाएं। तुरंत पूरी पर्ची व रसीद पीडीएफ बन जाएगी।"
        }

        // =========================================================================
        // 18.8 Time Range / Duration Guide (अवधि कैसे चुनें)
        // =========================================================================
        val isTimeFilterGuide = (q.contains("अवधि") || q.contains("समय सीमा") || q.contains("टाइम फिल्टर") || q.contains("फ़िल्टर")) &&
                (q.contains("कैसे") || q.contains("चुनें") || q.contains("लगाएं") || q.contains("बदलें") || q.contains("सलेक्ट"))
        if (isTimeFilterGuide) {
            return "${greeting}रिपोर्ट्स में अवधि (Time Range) चुनने का आसान तरीका:\n" +
                    "1. नीचे मुख्य मेनू में 'रिपोर्ट्स' (Reports) वाले टैब पर टैप करें।\n" +
                    "2. स्क्रीन पर ऊपर आपको फ़िल्टर चिप्स दिखेंगी: 'सभी', 'आज', 'इस सप्ताह', 'इस महीने', 'इस वर्ष' और '2 साल'।\n" +
                    "3. जिस भी अवधि पर आप क्लिक करेंगे, नीचे के कुल घंटे, कमाई, जमा और बकाया तुरंत उसी अवधि के अनुसार बदल जाएंगे!"
        }

        // =========================================================================
        // 18.9 Person / Customer Selection for Session (व्यक्ति कैसे चुनें)
        // =========================================================================
        val isSelectPersonGuide = (q.contains("व्यक्ति") || q.contains("किसान चुन") || q.contains("ग्राहक चुन") || q.contains("सत्र शुरू")) &&
                (q.contains("कैसे") || q.contains("कहाँ") || q.contains("चुनें") || q.contains("शुरू करें"))
        if (isSelectPersonGuide) {
            return "${greeting}सत्र चालू करने के लिए व्यक्ति (किसान) चुनने का तरीका:\n" +
                    "1. होम स्क्रीन पर बड़े हरे बटन ('👤 व्यक्ति चुनें और सत्र शुरू करें') पर टैप करें।\n" +
                    "2. नीचे से किसानों की सूची खुलकर सामने आ जाएगी।\n" +
                    "3. जिस किसान के खेत में पानी देना है, उसके नाम पर टैप करें।\n" +
                    "4. अब 'लाइव टाइमर', 'समय दर्ज करें' या 'सीधे घंटे' में से कोई भी तरीका चुनकर सत्र सुरक्षित कर दें!"
        }

        // =========================================================================
        // 18.10 Add Customer / Google Voice / Indian Contacts Guide (गूगल या नया किसान कैसे जोड़ें)
        // =========================================================================
        val isAddFarmerGuideExtended = (q.contains("नया किसान") || q.contains("नया ग्राहक") || q.contains("गूगल") || q.contains("इंडियन") || q.contains("कांटेक्ट") || q.contains("फोन बुक")) &&
                (q.contains("जोड़") || q.contains("add") || q.contains("बना") || q.contains("खोल") || q.contains("कैसे"))
        if (isAddFarmerGuideExtended) {
            return "${greeting}नया किसान जोड़ने के 3 आसान तरीके उपलब्ध हैं:\n" +
                    "1. साधारण फॉर्म: नीचे 'ग्राहक' टैब में जाएं, लाल गोल बटन ('+ नया किसान जोड़ें') दबाएं और नाम, पिता का नाम व मोबाइल नंबर दर्ज करें।\n" +
                    "2. फ़ोन बुक (Contacts) से जोड़ें: फॉर्म में मोबाइल नंबर के बगल में बने 'फ़ोन बुक' आइकन पर टैप करके सीधे अपने मोबाइल संपर्कों से किसान चुन सकते हैं।\n" +
                    "3. बोलकर लिखना (Google Voice Typing): नाम के बॉक्स में कीबोर्ड का माइक दबाकर बोलें, आपका बोला हुआ नाम अपने आप सही टाइप हो जाएगा।"
        }

        // =========================================================================
        // 18.11 Settings Overview & Rate Change (सेटिंग्स की सभी जानकारी)
        // =========================================================================
        val isSettingsOverview = (q.contains("सेटिंग") || q.contains("settings")) &&
                (q.contains("जानकारी") || q.contains("फीचर") || q.contains("क्या है") || q.contains("ऑप्शन") || q.contains("विकल्प") || q.contains("सब") || q.contains("बताओ"))
        if (isSettingsOverview) {
            val curRate = profile?.ratePerHour ?: 160.0
            return "${greeting}सेटिंग्स (Settings) टैब में आपको ये सभी महत्वपूर्ण सुविधाएं मिलती हैं:\n" +
                    "1. सामान्य सिंचाई दर: प्रति घंटा सिंचाई रेट (वर्तमान: ₹${"%.0f".format(curRate)}/घंटा) बदल सकते हैं।\n" +
                    "2. प्रोफ़ाइल: अपना नाम, मोबाइल नंबर, ट्यूबवेल का नाम और ईमेल अपडेट कर सकते हैं।\n" +
                    "3. डेटा बैकअप और सिंक: सारा बही-खाता Supabase क्लाउड में सुरक्षित सिंक कर सकते हैं।\n" +
                    "4. भाषा चुनें: हिंदी, हरियाणवी, पंजाबी, राजस्थानी, भोजपुरी सहित 12 भाषाओं में ऐप चला सकते हैं।\n" +
                    "5. ऐप लॉक और पिन: सुरक्षा के लिए 4 अंकों का पिन सेट कर सकते हैं।\n" +
                    "6. डार्क थीम: रात के समय आँखों के आराम के लिए डार्क मोड चालू कर सकते हैं।\n" +
                    "7. वीआईपी सदस्यता: बिना विज्ञापन के तेज़ उपयोग के लिए वीआईपी प्लान ले सकते हैं।"
        }

        // =========================================================================
        // 18.12 Built-in General Knowledge Answers (जब क्लाउड API अनुपलब्ध हो)
        // =========================================================================
        if (q.contains("प्रधानमंत्री") || q.contains("prime minister") || q.contains("pm of india") || q.contains("मोदी")) {
            return "${greeting}भारत के वर्तमान माननीय प्रधानमंत्री श्री नरेंद्र मोदी (Narendra Modi) हैं।"
        }
        if (q.contains("राष्ट्रपति") || q.contains("president of india") || q.contains("द्रौपदी मुर्मू")) {
            return "${greeting}भारत की वर्तमान माननीय राष्ट्रपति श्रीमती द्रौपदी मुर्मू (Droupadi Murmu) हैं।"
        }
        if (q.contains("कृषि मंत्री") || q.contains("agriculture minister")) {
            return "${greeting}भारत के वर्तमान केंद्रीय कृषि एवं किसान कल्याण मंत्री श्री शिवराज सिंह चौहान हैं।"
        }
        if (q.contains("राजधानी") || q.contains("capital of india")) {
            return "${greeting}भारत की राजधानी नई दिल्ली (New Delhi) है।"
        }

        // =========================================================================
        // 19. Overall Ledger Summary (कुल बकाया, कितना है, टोटल हिसाब, कुल उधार)
        // CRITICAL: Aggregate summary first, tells user they can ask for specific names!
        // =========================================================================
        val isOverallSummary = (q.contains("कुल") || q.contains("मार्केट") || q.contains("टोटल") || q.contains("सबका") ||
                q.contains("कितना") || q.contains("कितने") || q.contains("बकाया") || q.contains("बाकी") ||
                q.contains("उधार") || q.contains("उधारी") || q.contains("कर्ज") || q.contains("रकम") ||
                q.contains("घंटे") || q.contains("ਕਿੰਨਾ") || q.contains("total") || q.contains("balance") ||
                q.contains("due") || q.contains("कितणा") || q.contains("केतना") || q.contains("किती") ||
                q.contains("किता") || q.contains("कितो")) &&
                !q.contains("ग्राहक कैसे") && !q.contains("सत्र कैसे")

        if (isOverallSummary) {
            val count = customersWithStats.size
            val dueCusts = customersWithStats.filter { it.netDue > 0 }
            val totalDue = customersWithStats.sumOf { it.netDue }
            val totalHours = customersWithStats.sumOf { it.totalHours }

            val dueStr = "%.0f".format(totalDue)
            val hrsStr = "%.1f".format(totalHours)

            return when (lang) {
                MunshiLang.HARYANVI -> "${greeting}थारे बही-खाते म्ह कुल $count गिराहक सैं, जिण म्ह तै ${dueCusts.size} गिराहकां पै कुल ₹$dueStr बाकी बकाया सै। इब ताहीं कुल $hrsStr घंटे ट्यूबवेल चाल्या सै। जै थू 'किस-किस का बाकी सै' पूछेगा या किसे का नाम लेवैगा, तो म्हैं उसका सारा हिसाब तुरन्त बता द्यूँगा!"
                MunshiLang.BHOJPURI -> "${greeting}रउआ बही-खाता में कुल $count गो किसान बाड़े, जेह में से ${dueCusts.size} किसानन पर कुल ₹$dueStr बकाया बाकी बा। अब तक कुल $hrsStr घंटा ट्यूबवेल चलल बा। अगर रउआ 'किस-किस का बाकी बा' पूछब भा कवनो किसान के नाम लेब, त हम ओकर पूरा हिसाब तुरंत बता देब!"
                MunshiLang.RAJASTHANI -> "${greeting}थांके बही-खाता मांय कुल $count किसान छै, जिणां मांय सूं ${dueCusts.size} किसानां माथे कुल ₹$dueStr बाकी बकाया छै। अबे तांई कुल $hrsStr घंटा ट्यूबवेल चाल्यो छै। जे थे 'किण-किण रो बाकी छै' पूछोला या कोई किसान रो नाम लेवोला, तो म्हूं पूरो हिसाब झटपट बता देसूं सा!"
                MunshiLang.PUNJABI -> "${greeting}ਤੁਹਾਡੇ ਬਹੀ-ਖਾਤੇ ਵਿੱਚ ਕੁੱਲ $count ਕਿਸਾਨ ਹਨ, ਜਿਨ੍ਹਾਂ ਵਿੱਚੋਂ ${dueCusts.size} ਕਿਸਾਨਾਂ ਵੱਲ ਕੁੱਲ ₹$dueStr ਬਕਾਇਆ ਰਹਿੰਦਾ ਹੈ। ਹੁਣ ਤੱਕ ਕੁੱਲ $hrsStr ਘੰਟੇ ਟਿਊਬਵੈੱਲ ਚੱਲਿਆ ਹੈ। ਜੇ ਤੁਸੀਂ 'ਕਿਹਦਾ-ਕਿਹਦਾ ਬਕਾਇਆ ਹੈ' ਪੁੱਛੋਗੇ ਜਾਂ ਕਿਸੇ ਕਿਸਾਨ ਦਾ ਨਾਮ ਲਓਗੇ, ਤਾਂ ਮੈਂ ਪੂਰਾ ਹਿਸਾਬ ਤੁਰੰਤ ਦੱਸ ਦਿਆਂਗਾ!"
                MunshiLang.ENGLISH -> "${greeting}You have a total of $count farmers in your ledger, and ${dueCusts.size} farmers have pending dues totaling ₹$dueStr. Your tubewell has run for $hrsStr hours so far. You can ask 'who owes dues' or mention any farmer's name to view their full ledger instantly."
                MunshiLang.MARATHI -> "${greeting}तुमच्या वही-खात्यात एकूण $count शेतकरी आहेत, ज्यापैकी ${dueCusts.size} शेतकऱ्यांकडे एकूण ₹$dueStr बाकी आहे. आतापर्यंत एकूण $hrsStr तास कूपनलिका चालली आहे. तुम्ही 'कोणाकोणाची बाकी आहे' विचारू शकता किंवा शेतकऱ्याचे नाव सांगू शकता."
                MunshiLang.GUJARATI -> "${greeting}તમારા બહી-ખાતામાં કુલ $count ખેડૂતો છે, જેમાંથી ${dueCusts.size} ખેડૂતો પર કુલ ₹$dueStr બાકી છે. અત્યાર સુધીમાં કુલ $hrsStr કલાક બોરવેલ ચાલ્યો છે. તમે 'કોની કોની બાકી છે' પૂછી શકો છો અથવા ખેડૂતનું નામ લઈ શકો છો."
                else -> "${greeting}आपके बही-खाते में कुल $count किसान हैं, जिनमें से ${dueCusts.size} किसानों पर कुल ₹$dueStr बकाया बाकी है। अब तक कुल $hrsStr घंटे ट्यूबवेल चला है। यदि आप 'किस-किस का बकाया है' पूछेंगे या किसी किसान का नाम लेंगे तो मैं उसका पूरा हिसाब तुरंत बता दूँगा।"
            }
        }

        // Outside local domain -> Return null to route to Gemini or learned knowledge cache
        return null
    }

    private fun isSameDay(time1: Long, time2: Long): Boolean {
        val cal1 = Calendar.getInstance().apply { timeInMillis = time1 }
        val cal2 = Calendar.getInstance().apply { timeInMillis = time2 }
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    private fun isSameMonth(time1: Long, time2: Long): Boolean {
        val cal1 = Calendar.getInstance().apply { timeInMillis = time1 }
        val cal2 = Calendar.getInstance().apply { timeInMillis = time2 }
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH)
    }

    sealed class CustomerMatchResult {
        data class Single(val customer: CustomerWithStats) : CustomerMatchResult()
        data class Ambiguous(val name: String, val matches: List<CustomerWithStats>) : CustomerMatchResult()
    }

    /**
     * Converts Devanagari script characters into standard Roman/Latin phonetic representation.
     * Handles consonants, vowels, matras, nuktas, halants, and conjuncts.
     */
    private fun devanagariToRoman(input: String): String {
        if (input.isBlank()) return ""
        var s = input.replace("क्ष", "ksh")
            .replace("त्र", "tr")
            .replace("ज्ञ", "gy")
            .replace("श्र", "shr")
            .replace("ड़", "d")
            .replace("ढ़", "dh")
            .replace("ऋ", "ri")
            .replace("ॠ", "ri")
            .replace("ॄ", "ri")

        val sb = StringBuilder()
        for (ch in s) {
            when (ch) {
                'अ' -> sb.append("a")
                'आ' -> sb.append("aa")
                'इ', 'ई' -> sb.append("i")
                'उ', 'ऊ' -> sb.append("u")
                'ए', 'ऐ' -> sb.append("e")
                'ओ', 'औ' -> sb.append("o")
                'क' -> sb.append("k")
                'ख' -> sb.append("kh")
                'ग' -> sb.append("g")
                'घ' -> sb.append("gh")
                'ङ' -> sb.append("ng")
                'च' -> sb.append("ch")
                'छ' -> sb.append("chh")
                'ज' -> sb.append("j")
                'झ' -> sb.append("jh")
                'ञ' -> sb.append("ny")
                'ट', 'त' -> sb.append("t")
                'ठ', 'थ' -> sb.append("th")
                'ड', 'द' -> sb.append("d")
                'ढ', 'ध' -> sb.append("dh")
                'ण', 'न' -> sb.append("n")
                'प' -> sb.append("p")
                'फ' -> sb.append("f")
                'ब' -> sb.append("b")
                'भ' -> sb.append("bh")
                'म' -> sb.append("m")
                'य' -> sb.append("y")
                'र' -> sb.append("r")
                'ल' -> sb.append("l")
                'व' -> sb.append("v")
                'श', 'ष', 'स' -> sb.append("s")
                'ह' -> sb.append("h")
                'ा' -> sb.append("a")
                'ि', 'ी' -> sb.append("i")
                'ु', 'ू' -> sb.append("u")
                'ृ' -> sb.append("ri")
                'े', 'ै' -> sb.append("e")
                'ो', 'ौ' -> sb.append("o")
                'ं', 'ँ' -> sb.append("n")
                '्', '़' -> {} // halant / nukta
                ' ', '-', '_' -> sb.append(" ")
                in 'a'..'z', in 'A'..'Z', in '0'..'9' -> sb.append(ch.lowercaseChar())
                else -> {}
            }
        }
        return sb.toString()
    }

    /**
     * Phonetically normalizes names across Devanagari, English, and Indic regional variations.
     * Maps Devanagari to Latin and normalizes phonetic equivalences:
     * - व/ब/v/w/b equivalence
     * - श/ष/स/sh/s equivalence
     * - ph/f, ee/ea/i, oo/u equivalence
     * - Duplicate character compression
     */
    private fun phoneticNormalize(text: String): String {
        if (text.isBlank()) return ""
        // First transliterate Devanagari if present
        var s = devanagariToRoman(text).lowercase(Locale.ROOT)

        // Remove non-alphanumeric except basic letters
        s = s.replace(Regex("[^a-z0-9]"), "")

        // Latin / Indic phonetic simplification
        s = s.replace("ph", "f")
            .replace("bh", "b")
            .replace("dh", "d")
            .replace("th", "t")
            .replace("kh", "k")
            .replace("gh", "g")
            .replace("sh", "s")
            .replace("ch", "c")
            .replace("ee", "i")
            .replace("ea", "i")
            .replace("oo", "u")
            .replace("ou", "u")
            .replace("aa", "a")
            .replace("v", "w")
            .replace("b", "w") // v/b/w equivalence across Indic dialects

        // Collapse consecutive identical characters (e.g. ss -> s, mm -> m, nn -> n, tt -> t)
        val sb = StringBuilder()
        var prevChar = ' '
        for (ch in s) {
            if (ch != prevChar) {
                sb.append(ch)
                prevChar = ch
            }
        }
        return sb.toString()
    }

    /**
     * Standard Levenshtein Distance for fuzzy comparison
     */
    private fun levenshteinDistance(s1: String, s2: String): Int {
        if (s1 == s2) return 0
        if (s1.isEmpty()) return s2.length
        if (s2.isEmpty()) return s1.length

        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j

        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,      // deletion
                    dp[i][j - 1] + 1,      // insertion
                    dp[i - 1][j - 1] + cost // substitution
                )
            }
        }
        return dp[s1.length][s2.length]
    }

    /**
     * Checks if a target customer name phonetically matches the query or any word/token in the query.
     */
    private fun isNameMatch(cName: String, query: String, cleanQuery: String): Boolean {
        if (cName.isBlank()) return false
        val lowerC = cName.lowercase(Locale.ROOT).trim()
        val cleanC = lowerC.replace(" ", "")

        // 1. Direct raw substring match
        if (query.contains(lowerC) || cleanQuery.contains(cleanC)) return true

        val cTokens = lowerC.split(Regex("[\\s,]+")).map { it.trim() }.filter { it.length >= 2 }
        for (t in cTokens) {
            if (t.length >= 2 && (query.contains(t) || cleanQuery.contains(t))) return true
        }

        // 2. Phonetic normalized matching (Devanagari <-> Latin)
        val normC = phoneticNormalize(cleanC)
        val normQ = phoneticNormalize(cleanQuery)
        if (normC.length >= 2 && normQ.contains(normC)) return true

        for (t in cTokens) {
            val normT = phoneticNormalize(t)
            if (normT.length >= 2 && normQ.contains(normT)) return true
        }

        // 3. Query token-level matching against customer name tokens
        val qTokens = query.split(Regex("[\\s,।?!()/-]+")).map { it.trim() }.filter { it.length >= 2 }
        for (qTok in qTokens) {
            val normQTok = phoneticNormalize(qTok)
            if (normQTok.length < 2) continue

            // Compare against full name or individual tokens
            val targetTokens = if (cTokens.isNotEmpty()) cTokens else listOf(lowerC)
            for (t in targetTokens) {
                val normT = phoneticNormalize(t)
                if (normT.length < 2) continue

                // Exact phonetic match or substring
                if (normQTok == normT || (normT.length >= 3 && normQTok.contains(normT)) || (normQTok.length >= 3 && normT.contains(normQTok))) {
                    return true
                }

                // Levenshtein fuzzy match
                val lenDiff = Math.abs(normQTok.length - normT.length)
                if (lenDiff <= 2 && normT.length >= 3) {
                    val dist = levenshteinDistance(normQTok, normT)
                    val maxAllowed = if (normT.length <= 4) 1 else 2
                    if (dist <= maxAllowed) return true
                }
            }
        }

        return false
    }

    private fun findMatchingCustomerResult(q: String, customers: List<CustomerWithStats>): CustomerMatchResult? {
        if (customers.isEmpty()) return null
        val cleanQ = q.replace(" ", "")

        // 1. First, check if any customer matches BOTH name and father's name (S/O)
        for (item in customers) {
            val cName = item.customer.name.trim()
            val sOName = item.customer.sO.trim()

            if (isNameMatch(cName, q, cleanQ) && sOName.isNotBlank() && isNameMatch(sOName, q, cleanQ)) {
                return CustomerMatchResult.Single(item)
            }
        }

        // 2. Find all customers whose name, phone, or alias matches
        val matches = customers.filter { item ->
            val cName = item.customer.name.trim()
            val cPhone = item.customer.phone.trim()

            // Phone exact substring (4+ digits)
            (cPhone.length >= 4 && q.contains(cPhone)) ||
            // Advanced phonetic / fuzzy name matching
            isNameMatch(cName, q, cleanQ) ||
            // Common cross-script alias shortcuts
            (cName.equals("aneeta", ignoreCase = true) && (q.contains("अनीता") || q.contains("अनिता") || q.contains("anita"))) ||
            (cName.equals("anita", ignoreCase = true) && (q.contains("अनीता") || q.contains("अनिता") || q.contains("aneeta"))) ||
            (cName.equals("ramesh", ignoreCase = true) && (q.contains("रमेश") || q.contains("रमेस"))) ||
            (cName.equals("suresh", ignoreCase = true) && (q.contains("सुरेश") || q.contains("सुरेस"))) ||
            (cName.equals("sonu", ignoreCase = true) && (q.contains("सोनू") || q.contains("सोनु"))) ||
            (cName.equals("mukesh", ignoreCase = true) && (q.contains("मुकेश") || q.contains("मुकेस"))) ||
            (cName.equals("dinesh", ignoreCase = true) && (q.contains("दिनेश") || q.contains("दिनेस"))) ||
            (cName.equals("mahesh", ignoreCase = true) && (q.contains("महेश") || q.contains("महेस"))) ||
            (cName.equals("rajesh", ignoreCase = true) && (q.contains("राजेश") || q.contains("राजेस"))) ||
            (cName.equals("vijay", ignoreCase = true) && (q.contains("विजय") || q.contains("बिजय"))) ||
            (cName.equals("vikas", ignoreCase = true) && (q.contains("विकास") || q.contains("बिकास")))
        }

        if (matches.isEmpty()) return null
        if (matches.size == 1) return CustomerMatchResult.Single(matches.first())

        // If multiple matches share identical or similar first name, return Ambiguous to prompt for father's name
        val firstMatchName = matches.first().customer.name
        return CustomerMatchResult.Ambiguous(firstMatchName, matches)
    }

    /**
     * Builds a detailed, context-aware, dialect-specific response for a matched customer query.
     */
    private fun buildCustomerSpecificResponse(
        matchedCustomerResult: CustomerMatchResult,
        q: String,
        lang: MunshiLang,
        greeting: String
    ): String {
        when (matchedCustomerResult) {
            is CustomerMatchResult.Ambiguous -> {
                val list = matchedCustomerResult.matches.mapIndexed { idx, item ->
                    val soPart = if (item.customer.sO.isNotBlank()) " (पिता: ${item.customer.sO})" else ""
                    "${idx + 1}. ${item.customer.name}$soPart"
                }.joinToString(", ")
                return when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}थारे बही-खाते म्ह '${matchedCustomerResult.name}' नाम के ${matchedCustomerResult.matches.size} गिराहक सैं: $list। भाई बाबू (पिता) का नाम गेलै बोल दे (जिसा '${matchedCustomerResult.matches.first().customer.name} बेटा ${matchedCustomerResult.matches.first().customer.sO.ifBlank { "..." }}')।"
                    MunshiLang.BHOJPURI -> "${greeting}रउआ बही-खाता में '${matchedCustomerResult.name}' नाम के ${matchedCustomerResult.matches.size} गो किसान बाड़े: $list। कृपा करके बाबूजी के नाम संगे बोलीं (जइसे '${matchedCustomerResult.matches.first().customer.name} बेटा ${matchedCustomerResult.matches.first().customer.sO.ifBlank { "..." }}')।"
                    MunshiLang.RAJASTHANI -> "${greeting}थांके बही-खाता मांय '${matchedCustomerResult.name}' नाम रा ${matchedCustomerResult.matches.size} किसान छै: $list। कृपा कर'र पिता रो नाम सागे बोलो सा (जियां '${matchedCustomerResult.matches.first().customer.name} बेटा ${matchedCustomerResult.matches.first().customer.sO.ifBlank { "..." }}')।"
                    MunshiLang.PUNJABI -> "${greeting}ਤੁਹਾਡੇ ਬਹੀ-ਖਾਤੇ ਵਿੱਚ '${matchedCustomerResult.name}' ਨਾਮ ਦੇ ${matchedCustomerResult.matches.size} ਕਿਸਾਨ ਹਨ: $list। ਕਿਰਪਾ ਕਰਕੇ ਪਿਤਾ ਦਾ ਨਾਮ ਨਾਲ ਦੱਸੋ (ਜਿਵੇਂ '${matchedCustomerResult.matches.first().customer.name} ਪੁੱਤਰ ${matchedCustomerResult.matches.first().customer.sO.ifBlank { "..." }}')।"
                    MunshiLang.ENGLISH -> "${greeting}You have ${matchedCustomerResult.matches.size} farmers named '${matchedCustomerResult.name}' in your ledger: $list. Please specify the father's name (e.g., '${matchedCustomerResult.matches.first().customer.name} son of ${matchedCustomerResult.matches.first().customer.sO.ifBlank { "..." }}')."
                    else -> "${greeting}आपके बही-खाते में '${matchedCustomerResult.name}' नाम के ${matchedCustomerResult.matches.size} किसान हैं: $list। कृपया पिता का नाम साथ में बोलें (जैसे '${matchedCustomerResult.matches.first().customer.name} पुत्र ${matchedCustomerResult.matches.first().customer.sO.ifBlank { "..." }}')।"
                }
            }
            is CustomerMatchResult.Single -> {
                val matchedCustomer = matchedCustomerResult.customer
                val name = matchedCustomer.customer.name
                val soInfo = if (matchedCustomer.customer.sO.isNotBlank()) " (पिता: ${matchedCustomer.customer.sO})" else ""
                val phoneInfo = if (matchedCustomer.customer.phone.isNotBlank()) matchedCustomer.customer.phone else "दर्ज नहीं है"
                val due = matchedCustomer.netDue
                val advance = matchedCustomer.advanceAmount
                val hrs = matchedCustomer.totalHours
                val paid = matchedCustomer.totalPaid
                val bill = matchedCustomer.totalAmount
                val sessionCount = matchedCustomer.sessionCount

                val hrsStr = "%.1f".format(hrs)
                val billStr = "%.0f".format(bill)
                val paidStr = "%.0f".format(paid)
                val dueStr = "%.0f".format(due)
                val advStr = "%.0f".format(advance)

                // 1. Phone number query
                val isPhoneQuery = q.contains("नंबर") || q.contains("मोबाइल") || q.contains("फोन") ||
                        q.contains("phone") || q.contains("number") || q.contains("contact") || q.contains("mobile")
                if (isPhoneQuery) {
                    return when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}${name}$soInfo का मोबाइल नंबर: $phoneInfo सै भाई।"
                        MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo के मोबाइल नंबर: $phoneInfo बाटे।"
                        MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo रो मोबाइल नंबर: $phoneInfo छै सा।"
                        MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਦਾ ਮੋਬਾਈਲ ਨੰਬਰ: $phoneInfo ਹੈ ਜੀ।"
                        MunshiLang.ENGLISH -> "${greeting}${name}$soInfo's registered phone number is $phoneInfo."
                        else -> "${greeting}${name}$soInfo का मोबाइल नंबर $phoneInfo दर्ज है।"
                    }
                }

                // 2. Pure Hours / Sessions query
                val isHoursQuery = (q.contains("घंटे") || q.contains("घंटा") || q.contains("पानी") ||
                        q.contains("सत्र") || q.contains("सेशन") || q.contains("hours") || q.contains("time")) &&
                        !q.contains("रुपये") && !q.contains("बिल") && !q.contains("बकाया") && !q.contains("उधार") &&
                        !q.contains("बाकी") && !q.contains("जमा") && !q.contains("पैसा") && !q.contains("पैसे")
                if (isHoursQuery) {
                    return when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}${name}$soInfo के कुल $hrsStr घंटे पाणि चाल्या सै ($sessionCount सत्र म्ह)।"
                        MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo के कुल $hrsStr घंटा पानी चलल बा ($sessionCount गो सत्र में)।"
                        MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo रे कुल $hrsStr घंटा पाणी चाल्यो छै ($sessionCount सत्र मांय) सा।"
                        MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਦੇ ਕੁੱਲ $hrsStr ਘੰਟੇ ਸਿੰਚਾਈ ਚੱਲੀ ਹੈ ($sessionCount ਸੈਸ਼ਨਾਂ ਵਿੱਚ)।"
                        MunshiLang.ENGLISH -> "${greeting}${name}$soInfo has run for $hrsStr total hours across $sessionCount sessions."
                        else -> "${greeting}${name}$soInfo के कुल $hrsStr घंटे सिंचाई चली है ($sessionCount सत्रों में)।"
                    }
                }

                // 3. Pure Payment / Deposit query
                val isPaidQuery = (q.contains("जमा") || q.contains("भुगतान") || q.contains("paid") ||
                        q.contains("payment") || q.contains("कितने दिए")) &&
                        !q.contains("बकाया") && !q.contains("उधार") && !q.contains("बाकी") && !q.contains("देने")
                if (isPaidQuery) {
                    return when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}${name}$soInfo नै इब ताहीं कुल ₹$paidStr जमा करे सैं।" +
                                when {
                                    due > 0 -> " बाकी ₹$dueStr बकाया सै।"
                                    advance > 0 -> " ₹$advStr एडवांस जमा सैं (बकाया ₹0)।"
                                    else -> " सारा हिसाब चुकता सै!"
                                }
                        MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo अब ले कुल ₹$paidStr जमा कइले बाड़े।" +
                                when {
                                    due > 0 -> " बाकी ₹$dueStr बकाया बा।"
                                    advance > 0 -> " ₹$advStr एडवांस जमा बा (बकाया ₹0)।"
                                    else -> " पूरा हिसाब चुकता बा!"
                                }
                        MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo अब तांई कुल ₹$paidStr जमा कराया छै।" +
                                when {
                                    due > 0 -> " बाकी ₹$dueStr बकाया छै सा।"
                                    advance > 0 -> " ₹$advStr एडवांस जमा छै सा (बकाया ₹0)।"
                                    else -> " पूरो हिसाब चुकता छै सा!"
                                }
                        MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਨੇ ਹੁਣ ਤੱਕ ਕੁੱਲ ₹$paidStr ਜਮ੍ਹਾਂ ਕਰਵਾਏ ਹਨ।" +
                                when {
                                    due > 0 -> " ਬਾਕੀ ₹$dueStr ਬਕਾਇਆ ਰਹਿੰਦਾ ਹੈ।"
                                    advance > 0 -> " ₹$advStr ਐਡਵਾਂਸ ਜਮ੍ਹਾਂ ਹਨ (ਬਕਾਇਆ ₹0)।"
                                    else -> " ਸਾਰਾ ਹਿਸਾਬ ਚੁਕਤਾ ਹੈ!"
                                }
                        MunshiLang.ENGLISH -> "${greeting}${name}$soInfo has paid ₹$paidStr so far." +
                                when {
                                    due > 0 -> " Remaining balance is ₹$dueStr."
                                    advance > 0 -> " ₹$advStr is deposited in advance (₹0 due)."
                                    else -> " Account is fully settled!"
                                }
                        else -> "${greeting}${name}$soInfo ने अब तक कुल ₹$paidStr जमा (भुगतान) किए हैं।" +
                                when {
                                    due > 0 -> " अभी ₹$dueStr बकाया बाकी है।"
                                    advance > 0 -> " खाते में ₹$advStr एडवांस जमा हैं (बकाया ₹0)।"
                                    else -> " पूरा हिसाब चुकता है!"
                                }
                    }
                }

                // 4. Pure Dues / Udhar / Baki / Advance query
                val isDuesOnlyQuery = (q.contains("बकाया") || q.contains("बाकी") || q.contains("उधार") ||
                        q.contains("उधारी") || q.contains("एडवांस") || q.contains("advance") ||
                        q.contains("due") || q.contains("balance") || q.contains("pending") ||
                        q.contains("देने") || q.contains("लेने") || q.contains("लेना")) &&
                        !q.contains("बारे में") && !q.contains("हिसाब") && !q.contains("डिटेल")
                if (isDuesOnlyQuery) {
                    return when {
                        due > 0 -> when (lang) {
                            MunshiLang.HARYANVI -> "${greeting}${name}$soInfo के ₹$dueStr बकाया बाकी सैं (कुल बिल ₹$billStr म्ह तै ₹$paidStr जमा सै)।"
                            MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo के ₹$dueStr बकाया बाटे (कुल बिल ₹$billStr में से ₹$paidStr जमा बा)।"
                            MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo रा ₹$dueStr बकाया छै सा (कुल बिल ₹$billStr मांय सूं ₹$paidStr जमा छै)।"
                            MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਦੇ ₹$dueStr ਬਕਾਇਆ ਰਹਿੰਦੇ ਹਨ (ਕੁੱਲ ਬਿੱਲ ₹$billStr ਵਿੱਚੋਂ ₹$paidStr ਜਮ੍ਹਾਂ ਹਨ)।"
                            MunshiLang.ENGLISH -> "${greeting}${name}$soInfo has a remaining balance of ₹$dueStr (Total bill: ₹$billStr, Paid: ₹$paidStr)."
                            else -> "${greeting}${name}$soInfo के खाते में ₹$dueStr बकाया बाकी हैं (कुल बिल ₹$billStr में से ₹$paidStr जमा हैं)।"
                        }
                        advance > 0 -> when (lang) {
                            MunshiLang.HARYANVI -> "${greeting}${name}$soInfo का कोई बकाया कोन्या, बल्कि ₹$advStr एडवांस जमा सैं (कुल बिल ₹$billStr, जमा ₹$paidStr)।"
                            MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo के कवनो बकाया नइखे, बल्कि ₹$advStr एडवांस जमा बा (कुल बिल ₹$billStr, जमा ₹$paidStr)।"
                            MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo रो कोई बकाया कोनी सा, बल्कि ₹$advStr एडवांस जमा छै (कुल बिल ₹$billStr, जमा ₹$paidStr)।"
                            MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਦਾ ਕੋਈ ਬਕਾਇਆ ਨਹੀਂ ਹੈ, ਸਗੋਂ ₹$advStr ਐਡਵਾਂਸ ਜਮ੍ਹਾਂ ਹਨ (ਕੁੱਲ ਬਿੱਲ ₹$billStr, ਜਮ੍ਹਾਂ ₹$paidStr)।"
                            MunshiLang.ENGLISH -> "${greeting}${name}$soInfo has ₹0 due and ₹$advStr advance paid (Total bill: ₹$billStr, Paid: ₹$paidStr)."
                            else -> "${greeting}${name}$soInfo का कोई बकाया नहीं है, बल्कि खाते में ₹$advStr एडवांस जमा हैं (कुल बिल ₹$billStr, कुल जमा ₹$paidStr)।"
                        }
                        else -> when (lang) {
                            MunshiLang.HARYANVI -> "${greeting}${name}$soInfo का सारा हिसाब चुकता सै भाई! कोई बकाया कोन्या बाकी।"
                            MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo के पूरा हिसाब चुकता बा भाई जी! कवनो बाकी नइखे।"
                            MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo रो पूरो हिसाब चुकता छै सा! कोई बकाया कोनी।"
                            MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਦਾ ਸਾਰਾ ਹਿਸਾਬ ਚੁਕਤਾ ਹੈ ਵੀਰ ਜੀ! ਕੋਈ ਬਕਾਇਆ ਨਹੀਂ ਰਹਿੰਦਾ।"
                            MunshiLang.ENGLISH -> "${greeting}${name}$soInfo's account is completely settled with zero balance due."
                            else -> "${greeting}${name}$soInfo का पूरा हिसाब चुकता है। कोई बकाया बाकी नहीं है।"
                        }
                    }
                }

                // 5. Complete Comprehensive Ledger Breakdown (General Hisab / About him / Details / Status)
                return when {
                    due > 0 -> when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}${name}$soInfo का पूरा हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटे ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• बाकी बकाया: ₹$dueStr\n" +
                                "• फोन: $phoneInfo"
                        MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo के पूरा हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटा ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• बाकी बकाया: ₹$dueStr\n" +
                                "• फोन: $phoneInfo"
                        MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo रो पूरो हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटा ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• बाकी बकाया: ₹$dueStr\n" +
                                "• फोन: $phoneInfo सा"
                        MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਦਾ ਪੂਰਾ ਹਿਸਾਬ-ਕਿਤਾਬ:\n" +
                                "• ਕੁੱਲ ਸਿੰਚਾਈ: $hrsStr ਘੰਟੇ ($sessionCount ਵਾਰ)\n" +
                                "• ਕੁੱਲ ਬਿੱਲ: ₹$billStr\n" +
                                "• ਜਮ੍ਹਾਂ: ₹$paidStr\n" +
                                "• ਬਾਕੀ ਬਕਾਇਆ: ₹$dueStr\n" +
                                "• ਫ਼ੋਨ: $phoneInfo"
                        MunshiLang.ENGLISH -> "${greeting}Account details for ${name}$soInfo:\n" +
                                "• Total Irrigation: $hrsStr hours ($sessionCount sessions)\n" +
                                "• Total Bill: ₹$billStr\n" +
                                "• Total Paid: ₹$paidStr\n" +
                                "• Outstanding Due: ₹$dueStr\n" +
                                "• Phone: $phoneInfo"
                        else -> "${greeting}${name}$soInfo के खाते का पूरा विवरण:\n" +
                                "• कुल सिंचाई: $hrsStr घंटे ($sessionCount सत्र)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा राशि: ₹$paidStr\n" +
                                "• शेष बकाया: ₹$dueStr\n" +
                                "• मोबाइल नंबर: $phoneInfo"
                    }
                    advance > 0 -> when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}${name}$soInfo का हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटे ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• एडवांस जमा: ₹$advStr (बकाया ₹0)\n" +
                                "• फोन: $phoneInfo"
                        MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo के हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटा ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• एडवांस जमा: ₹$advStr (बकाया ₹0)\n" +
                                "• फोन: $phoneInfo"
                        MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo रो हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटा ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• एडवांस जमा: ₹$advStr (बकाया ₹0)\n" +
                                "• फोन: $phoneInfo सा"
                        MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਦਾ ਹਿਸਾਬ-ਕਿਤਾਬ:\n" +
                                "• ਕੁੱਲ ਸਿੰਚਾਈ: $hrsStr ਘੰਟੇ ($sessionCount ਵਾਰ)\n" +
                                "• ਕੁੱਲ ਬਿੱਲ: ₹$billStr\n" +
                                "• ਜਮ੍ਹਾਂ: ₹$paidStr\n" +
                                "• ਐਡਵਾਂਸ ਜਮ੍ਹਾਂ: ₹$advStr (ਬਕਾਇਆ ₹0)\n" +
                                "• ਫ਼ੋਨ: $phoneInfo"
                        MunshiLang.ENGLISH -> "${greeting}Account details for ${name}$soInfo:\n" +
                                "• Total Irrigation: $hrsStr hours ($sessionCount sessions)\n" +
                                "• Total Bill: ₹$billStr\n" +
                                "• Total Paid: ₹$paidStr\n" +
                                "• Advance Paid: ₹$advStr (₹0 Due)\n" +
                                "• Phone: $phoneInfo"
                        else -> "${greeting}${name}$soInfo के खाते का पूरा विवरण:\n" +
                                "• कुल सिंचाई: $hrsStr घंटे ($sessionCount सत्र)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा राशि: ₹$paidStr\n" +
                                "• एडवांस जमा: ₹$advStr (बकाया ₹0)\n" +
                                "• मोबाइल नंबर: $phoneInfo"
                    }
                    else -> when (lang) {
                        MunshiLang.HARYANVI -> "${greeting}${name}$soInfo का हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटे ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• स्थिति: सारा हिसाब चुकता सै (₹0 बकाया)\n" +
                                "• फोन: $phoneInfo"
                        MunshiLang.BHOJPURI -> "${greeting}${name}$soInfo के हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटा ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• स्थिति: पूरा हिसाब चुकता बा (₹0 बाकी)\n" +
                                "• फोन: $phoneInfo"
                        MunshiLang.RAJASTHANI -> "${greeting}${name}$soInfo रो हिसाब-किताब:\n" +
                                "• कुल सिंचाई: $hrsStr घंटा ($sessionCount बार)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा: ₹$paidStr\n" +
                                "• स्थिति: पूरो हिसाब चुकता छै (₹0 बकाया)\n" +
                                "• फोन: $phoneInfo सा"
                        MunshiLang.PUNJABI -> "${greeting}${name}$soInfo ਦਾ ਹਿਸਾਬ-ਕਿਤਾਬ:\n" +
                                "• ਕੁੱਲ ਸਿੰਚਾਈ: $hrsStr ਘੰਟੇ ($sessionCount ਵਾਰ)\n" +
                                "• ਕੁੱਲ ਬਿੱਲ: ₹$billStr\n" +
                                "• ਜਮ੍ਹਾਂ: ₹$paidStr\n" +
                                "• ਸਥਿਤੀ: ਸਾਰਾ ਹਿਸਾਬ ਚੁਕਤਾ ਹੈ (₹0 ਬਕਾਇਆ)\n" +
                                "• ਫ਼ੋਨ: $phoneInfo"
                        MunshiLang.ENGLISH -> "${greeting}Account details for ${name}$soInfo:\n" +
                                "• Total Irrigation: $hrsStr hours ($sessionCount sessions)\n" +
                                "• Total Bill: ₹$billStr\n" +
                                "• Total Paid: ₹$paidStr\n" +
                                "• Status: Fully Settled (₹0 Due)\n" +
                                "• Phone: $phoneInfo"
                        else -> "${greeting}${name}$soInfo के खाते का पूरा विवरण:\n" +
                                "• कुल सिंचाई: $hrsStr घंटे ($sessionCount सत्र)\n" +
                                "• कुल बिल: ₹$billStr\n" +
                                "• जमा राशि: ₹$paidStr\n" +
                                "• स्थिति: पूरा हिसाब चुकता है (₹0 बकाया)\n" +
                                "• मोबाइल नंबर: $phoneInfo"
                    }
                }
            }
        }
    }

    /**
     * Polite, contextual fallback response in the selected language when a query is not understood.
     * NEVER recites customer names or dumps the ledger!
     */
    fun generateFallbackSummary(
        query: String,
        customersWithStats: List<CustomerWithStats>,
        hasPriorChat: Boolean = false,
        activeLang: MunshiLang = MunshiLang.HINDI
    ): String {
        val q = query.trim().lowercase(Locale.ROOT)
        val lang = detectDialectFromQuery(q, activeLang)

        return when (lang) {
            MunshiLang.HARYANVI -> "भाई, थारे बहीखाते, ट्यूबवेल के घंटे, किसानों के बकाया अर खेती-बाड़ी का सारा हिसाब म्हारै याद सै। किसे गिराहक का नाम लेकै हिसाब पूछ ले या फसल की सलाह ले ले।"
            MunshiLang.BHOJPURI -> "भाई जी, रउआ बहीखाता, ट्यूबवेल के घंटा, बाकी पईसा आ खेती-बारी के कुल हिसाब हम याद रखेनी। कवनो किसान के नाम लेके हिसाब भा खेती के सलाह पूछीं।"
            MunshiLang.RAJASTHANI -> "भाई सा, आपरे बहीखाते, ट्यूबवेल रा घंटा, बकाया अर खेती-बाड़ी रो पूरो हिसाब म्हारे याद छै। आप कोई भी किसान रो हिसाब या फसल री सलाह पूछ सको छा सा."
            MunshiLang.PUNJABI -> "ਵੀਰ ਜੀ, ਵਹੀ-ਖਾਤੇ, ਟਿਊਬਵੈੱਲ ਦੇ ਘੰਟੇ, ਬਕਾਏ ਅਤੇ ਖੇਤੀਬਾੜੀ ਦਾ ਪੂਰਾ ਹਿਸਾਬ ਮੇਰੇ ਕੋਲ ਹੈ। ਤੁਸੀਂ ਕਿਸੇ ਗਾਹਕ ਦਾ ਹਿਸਾਬ ਜਾਂ ਫਸਲ ਦੀ ਸਲਾਹ ਪੁੱਛ ਸਕਦੇ ਹੋ।"
            MunshiLang.ENGLISH -> "I am ready with your tubewell running hours, billing, farmer dues, and agricultural advice. Ask for any farmer or crop guidance."
            MunshiLang.MARATHI -> "शेतकरी बंधू, वहिवाट, कूपनलिकेचा हिशोब आणि शेतीविषयक सर्व माहिती उपलब्ध आहे. तुम्ही कोणतीही माहिती विचारू शकता."
            MunshiLang.GUJARATI -> "ખેડૂત ભાઈ, વહીખાતું, બોરવેલના કલાકો અને ખેતીની તમામ માહિતી તૈયાર છે. તમે કોઈ પણ હિસાબ કે પાકની સલાહ પૂછી શકો છો."
            MunshiLang.BENGALI -> "কৃষক ভাই, আপনার খাতা, টিউবওয়েলের সময় ও কৃষি পরামর্শ প্রস্তুত আছে। আপনি যেকোনো হিসাব জানতে পারেন।"
            MunshiLang.TELUGU -> "రైతు సోదరా, మీ ఖాతా పుస్తకం, బోరుబావి గంటలు, బకాయిలు మరియు పంటల సలహాలు సిద్ధంగా ఉన్నాయి."
            MunshiLang.TAMIL -> "விவசாயி சகோதரரே, கணக்கு புத்தகம், பம்ப் செட் நேரம் மற்றும் பயிர் ஆலோசனைகள் தயாராக உள்ளன."
            MunshiLang.KANNADA -> "ರೈತ ಬಾಂಧವರೇ, ನಿಮ್ಮ ಖಾತೆ ಪುಸ್ತಕ, ಕೊಳವೆಬಾವಿಯ ಸಮಯ ಮತ್ತು ಕೃಷಿ ಸಲಹೆಗಳು ಸಿದ್ಧವಾಗಿವೆ."
            MunshiLang.URDU -> "کسان بھائی، آپ کا بہی کھاتہ، ٹیوب ویل کا وقت، بقایا جات اور فصلوں کی رہنمائی بالکل تیار ہے۔"
            else -> "किसान भाई, मुंशी जी आपके बही-खाते, ट्यूबवेल के घंटे, किसानों के बकाया और खेती-बाड़ी के सारे हिसाब के लिए तैयार हैं। आप किसी किसान का नाम या किसी भी फसल की जानकारी पूछ सकते हैं।"
        }
    }

    private fun handleChitchat(q: String, lang: MunshiLang): String? {
        // A. Greetings / How are you
        val isGreeting = q.contains("हाउ आर यू") || q.contains("how are you") || q.contains("how r u") ||
                q.contains("कैसे हो") || q.contains("के हाल सै") || q.contains("का हाल बा") ||
                q.contains("ਕਿਵੇਂ ਹੋ") || q.contains("कसे आहात") || q.contains("કેમ છો") ||
                q.contains("কেমন আছেন") || q.contains("हेलो") || q.contains("hello") || q.contains("hi") ||
                q.contains("नमस्ते") || q.contains("राम-राम") || q.contains("सत श्री अकाल") ||
                q.contains("घणी खम्मा")

        if (isGreeting && (q.contains("हो") || q.contains("हाल") || q.contains("you") || q.contains("कसे") || q.contains("કેમ") || q.contains("खम्मा") || q.split(" ").size <= 4)) {
            return when (lang) {
                MunshiLang.HARYANVI -> "राम-राम भाई! म्हैं बिल्कुल बढ़िया सूं। थू बता भाई—आज ट्यूबवेल का के हिसाब देखना सै?"
                MunshiLang.BHOJPURI -> "प्रणाम भाई जी! हम एकदम ठीक बानी। रउआ बताईं—आज ट्यूबवेल के का हिसाब देखे के बा?"
                MunshiLang.RAJASTHANI -> "राम-राम सा! म्हूं बिल्कुल आनंद मांय छूं। आप फरमाओ सा—आज ट्यूबवेल रो काईं हिसाब देखणो छै?"
                MunshiLang.PUNJABI -> "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ਵੀਰ ਜੀ! ਮੈਂ ਬਿਲਕੁਲ ਠੀਕ ਹਾਂ। ਤੁਸੀਂ ਦੱਸੋ—ਅੱਜ ਟਿਊਬਵੈੱਲ ਦਾ ਕੀ ਹਿਸਾਬ ਵੇਖਣਾ ਹੈ?"
                MunshiLang.ENGLISH -> "Hello! I am doing well, thank you. How can I help you with your tubewell ledger today?"
                MunshiLang.MARATHI -> "नमस्कार! मी अगदी मजेत आहे. तुम्ही सांगा—आज कूपनलिकेचा काय हिशोब पाहायचा आहे?"
                MunshiLang.GUJARATI -> "નમસ્તે! હું એકદમ મજામાં છું. તમે કહો—આજે બોરવેલનો શું હિસાબ જોવો છે?"
                MunshiLang.BENGALI -> "নমস্কার! আমি ভালো আছি। আপনি বলুন—আজ টিউবওয়েলের কী হিসাব দেখতে চান?"
                MunshiLang.TELUGU -> "నమస్కారం! నేను బాగున్నాను. చెప్పండి—ఈరోజు బోరుబావి లెక్కలు ఏమి చూడాలి?"
                MunshiLang.TAMIL -> "வணக்கம்! நான் நலமாக உள்ளேன். சொல்லுங்கள்—இன்று கணக்கு விவரங்களை என்ன பார்க்க வேண்டும்?"
                MunshiLang.KANNADA -> "ನಮಸ್ಕಾರ! ನಾನು ಆರಾಮಾಗಿದ್ದೇನೆ. ನೀವು ಹೇಳಿ—ಇಂದು ಕೊಳವೆಬಾವಿಯ ಯಾವ ಲೆಕ್ಕ ನೋಡಬೇಕು?"
                MunshiLang.URDU -> "السلام علیکم! میں بالکل ٹھیک ہوں۔ آپ بتائیے—آج ٹیوب ویل کا کیا हिसाब کتاب دیکھنا ہے؟"
                else -> "नमस्ते भाई जी! मैं बिल्कुल ठीक हूँ। आप बताइए—आज ट्यूबवेल का क्या हिसाब देखना है?"
            }
        }

        // B. Who are you & What is your work
        if (q.contains("तुम कौन हो") || q.contains("who are you") || q.contains("तुम्हारा नाम क्या") ||
            q.contains("तू कौण सै") || q.contains("रउआ के हईं") || q.contains("ਤੁਸੀਂ ਕੌਣ ਹੋ") ||
            q.contains("थे कुण छो") || q.contains("काम क्या") || q.contains("क्या काम") ||
            q.contains("क्या करते हो") || q.contains("क्या कर सकते हो") || q.contains("काम बताओ") ||
            q.contains("काम क्या है") || q.contains("तुम्हारा काम")
        ) {
            return when (lang) {
                MunshiLang.HARYANVI -> "म्हैं थारा डिजिटल मुंशी सूं भाई! थारे ट्यूबवेल के घंटे, बिल, नकद वसूली अर किसानों के बकाया का सारा हिसाब म्हारै याद रहवै सै, अर साथै म्हैं थारी खेती-बाड़ी की पूरी सलाह भी देऊँ सूं।"
                MunshiLang.BHOJPURI -> "हम रउआ डिजिटल मुंशी हईं। ट्यूबवेल के घंटा, बिल, वसूली, बकाया आ खेती-बारी के कुल हिसाब हम याद रखेनी।"
                MunshiLang.RAJASTHANI -> "म्हूं आपरो डिजिटल मुंशी छूं सा! आपरे ट्यूबवेल रा घंटा, बिल, नकद वसूली, बकाया अर खेती-बाड़ी रो पूरो हिसाब म्हारे याद रहवे छै।"
                MunshiLang.PUNJABI -> "ਮੈਂ ਤੁਹਾਡਾ ਡਿਜੀਟਲ ਮੁਨਸ਼ੀ ਹਾਂ। ਟਿਊਬਵੈੱਲ ਦੇ ਘੰਟੇ, ਬਿੱਲ, ਬਕਾਏ ਅਤੇ ਖੇਤੀਬਾੜੀ ਦੀ ਪੂਰੀ ਜਾਣਕਾਰੀ ਮੈਂ ਰੱਖਦਾ ਹਾਂ।"
                MunshiLang.ENGLISH -> "I am your Digital Munshi. I manage your tubewell running hours, billing, collections, farmer dues, and provide agronomy guidance."
                else -> "मैं आपका डिजिटल मुंशी हूँ। मेरा मुख्य काम आपके ट्यूबवेल का हिसाब, घंटे, बिल, नकद वसूली और बकाया याद रखना है, साथ ही खेती-बाड़ी और फसलों की सही सलाह देना है।"
            }
        }

        // C. Thank you
        if (q.contains("धन्यवाद") || q.contains("शुक्रिया") || q.contains("thank you") || q.contains("thanks") || q.contains("मेहरबानी")) {
            return when (lang) {
                MunshiLang.HARYANVI -> "घणा-घणा धन्यवाद भाई! जब्बे भी हिसाब देखना हो, बस आवाज दे दिये।"
                MunshiLang.BHOJPURI -> "बहुत-बहुत धन्यवाद भाई जी! जब भी हिसाब देखे के होखे, बस बोल दीहीं।"
                MunshiLang.RAJASTHANI -> "घणो-घणो धन्यवाद सा! जद भी हिसाब देखणो व्हे, बस आवाज देय दीज्यो।"
                MunshiLang.PUNJABI -> "ਤੁਹਾਡਾ ਬਹੁਤ ਧੰਨਵਾਦ ਵੀਰ ਜੀ! ਜਦੋਂ ਵੀ ਹਿਸਾਬ ਵੇਖਣਾ ਹੋਵੇ, ਬਸ ਪੁੱਛ ਲਿਓ।"
                MunshiLang.ENGLISH -> "You're most welcome! Whenever you need to check accounts, just ask."
                else -> "आपका बहुत धन्यवाद भाई जी! जब भी हिसाब देखना हो, बस माइक दबाकर पूछ लीजिएगा।"
            }
        }

        // D. Prominent National Leaders & General Knowledge (Instant 0-API Answers)
        if (q.contains("प्रधानमंत्री") || q.contains("prime minister") || (q.contains("pm") && q.contains("भारत"))) {
            return "वर्तमान में भारत के प्रधानमंत्री श्री नरेंद्र मोदी हैं।"
        }
        if (q.contains("राष्ट्रपति") || q.contains("president of india")) {
            return "वर्तमान में भारत की राष्ट्रपति श्रीमती द्रौपदी मुर्मू हैं।"
        }
        if (q.contains("राजधानी") || q.contains("capital of india")) {
            return "भारत की राजधानी नई दिल्ली है।"
        }
        if (q.contains("कृषि मंत्री") || q.contains("agriculture minister")) {
            return "वर्तमान में भारत के केंद्रीय कृषि मंत्री श्री शिवराज सिंह चौहान हैं।"
        }

        return null
    }

    private fun buildLanguageSwitchConfirmation(target: MunshiLang): String {
        return when (target) {
            MunshiLang.HARYANVI -> "ले भाई, इब तै थारे गेलै ठेठ हरियाणवी म्ह बात करांगे! बता भाई, ट्यूबवेल का के हिसाब देखना सै?"
            MunshiLang.BHOJPURI -> "ठीक बा भाई जी! अब रउआ से हम भोजपुरी में बात करब। बताईं, आज बही-खाता के का हाल-चाल बा?"
            MunshiLang.RAJASTHANI -> "घणी खम्मा सा! अबे आपां राजस्थानी मांय बात करांला। फरमाओ सा, आज ट्यूबवेल रो काईं हिसाब देखणो छै?"
            MunshiLang.PUNJABI -> "ਹਾਂਜੀ ਵੀਰ ਜੀ, ਹੁਣ ਅਸੀਂ ਪੰਜਾਬੀ ਵਿੱਚ ਗੱਲ ਕਰਾਂਗੇ! ਦੱਸੋ, ਟਿਊਬਵੈੱਲ ਦਾ ਕੀ ਹਿਸਾਬ-ਕਿਤਾਬ ਵੇਖਣਾ ਹੈ?"
            MunshiLang.ENGLISH -> "Sure! I have switched to English. How can I help you with your tubewell ledger today?"
            MunshiLang.MARATHI -> "हो नक्कीच! आता आपण मराठीत बोलूया. सांगा, आज कूपनलिकेचा काय हिशोब बघायचा आहे?"
            MunshiLang.GUJARATI -> "ચોક્કસ! હવે આપણે ગુજરાતીમાં વાત કરીશું. કહો, આજે બોરવેલનો શું હિસાબ જોવો છે?"
            MunshiLang.BENGALI -> "অবশ্যই! এখন থেকে আমরা বাংলায় কথা বলব। বলুন, টিউবওয়েলের কী হিসাব দেখতে চান?"
            MunshiLang.TELUGU -> "తప్పకుండా! ఇకపై మనం తెలుగులో మాట్లాడదాం. చెప్పండి, బోరుబావి లెక్కలు ఏమి చూడాలి?"
            MunshiLang.TAMIL -> "நிச்சயமாக! இனி நாம் தமிழில் பேசுவோம். சொல்லுங்கள், கணக்கு விவரங்களை என்ன பார்க்க வேண்டும்?"
            MunshiLang.KANNADA -> "ಖಂಡಿತ! ಇನ್ನು ಮುಂದೆ ನಾವು ಕನ್ನಡದಲ್ಲಿ ಮಾತನಾಡೋಣ. ಹೇಳಿ, ಕೊಳವೆಬಾವಿಯ ಯಾವ ಲೆಕ್ಕ ನೋಡಬೇಕು?"
            MunshiLang.URDU -> "جی بالکل! اب ہم اردو میں بات کریں گے۔ فرمائیے، ٹیوب ویل کا کیا حساب کتاب دیکھنا ہے؟"
            MunshiLang.HINDI -> "जी बिल्कुल! अब हम हिंदी में बात करेंगे। बताइए, आज ट्यूबवेल का क्या हिसाब देखना है?"
        }
    }

    private fun getInitialGreeting(lang: MunshiLang): String {
        return when (lang) {
            MunshiLang.HARYANVI -> "राम-राम भाई! "
            MunshiLang.BHOJPURI -> "प्रणाम भाई जी, "
            MunshiLang.RAJASTHANI -> "राम-राम सा! "
            MunshiLang.PUNJABI -> "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ਜੀ! "
            MunshiLang.ENGLISH -> "Hello! "
            MunshiLang.MARATHI -> "नमस्कार, "
            MunshiLang.GUJARATI -> "નમસ્તે, "
            MunshiLang.BENGALI -> "নমস্কার, "
            MunshiLang.TELUGU -> "నమస్కారం, "
            MunshiLang.TAMIL -> "வணக்கம், "
            MunshiLang.KANNADA -> "ನಮಸ್ಕಾರ, "
            MunshiLang.URDU -> "السلام علیکم، "
            else -> "नमस्ते किसान भाई, "
        }
    }

    /**
     * Prominent agricultural knowledge base: answers common farmer queries locally and instantly.
     * If the query is not matched by these prominent patterns, returns null so Gemini AI provides full scientific advice.
     */
    private fun tryAnswerFarmingQuery(q: String, lang: MunshiLang, greeting: String): String? {
        val isWheat = q.contains("गेहूं") || q.contains("गेंहू") || q.contains("कनक") || q.contains("wheat") || q.contains("गहु")
        val isMustard = q.contains("सरसों") || q.contains("सरसो") || q.contains("राया") || q.contains("तोरी") || q.contains("mustard") || q.contains("मोहरी")
        val isPaddy = q.contains("धान") || q.contains("जीरी") || q.contains("चावल") || q.contains("झोना") || q.contains("paddy") || q.contains("rice") || q.contains("भात")
        val isCane = q.contains("गन्ना") || q.contains("कमंद") || q.contains("sugarcane") || q.contains("ऊस")
        val isFertilizer = q.contains("खाद") || q.contains("यूरिया") || q.contains("dap") || q.contains("डीएपी") || q.contains("पोटाश") || q.contains("जिंक") || q.contains("सल्फर") || q.contains("fertilizer")
        val isPestOrDisease = q.contains("कीड़ा") || q.contains("कीट") || q.contains("सुंडी") || q.contains("माहू") || q.contains("चेपा") || q.contains("दीमक") || q.contains("फफूंद") || q.contains("बीमारी") || q.contains("स्प्रे") || q.contains("दवा") || q.contains("रतुआ")
        val isMotorOrIrrigation = q.contains("मोटर") || q.contains("बोरवेल") || q.contains("पानी कम") || q.contains("गर्म हो") || q.contains("ट्रिप") || q.contains("ड्रिप") || q.contains("फव्वारा")
        val isBanana = q.contains("केला") || q.contains("केले") || q.contains("banana")
        val isPotato = q.contains("आलू") || q.contains("potato") || q.contains("बटाटा")
        val isCotton = q.contains("कपास") || q.contains("नरमा") || q.contains("cotton")
        val isVegetables = q.contains("टमाटर") || q.contains("मिर्च") || q.contains("प्याज") || q.contains("सब्जी")

        if (!isWheat && !isMustard && !isPaddy && !isCane && !isFertilizer && !isPestOrDisease && !isMotorOrIrrigation &&
            !isBanana && !isPotato && !isCotton && !isVegetables) {
            return null
        }

        // 1. WHEAT (गेहूं / कनक)
        if (isWheat) {
            // Sowing time
            if (q.contains("बुवाई") || q.contains("बोने") || q.contains("बिजाई") || q.contains("कब बो") || q.contains("समय")) {
                return when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}गेहूं की बिजाई का सबसे सही टेम 25 अक्टूबर तै 20 नवंबर तक सै भाई। पछेती बिजाई दिसंबर के पहले हफ्ते तक कर सकै सै। प्रति एकड़ 40 तै 45 किलो बीज राखियो।"
                    MunshiLang.RAJASTHANI -> "${greeting}गेहूं री बुवाई रो सबसूं बढ़िया टेम 25 अक्टूबर सूं 20 नवंबर तांई छै सा। प्रति एकड़ 40 सूं 45 किलो बीज राखजो।"
                    MunshiLang.PUNJABI -> "${greeting}ਕਣਕ ਦੀ ਬਿਜਾਈ ਦਾ ਸਭ ਤੋਂ ਵਧੀਆ ਸਮਾਂ 25 ਅਕਤੂਬਰ ਤੋਂ 20 ਨਵੰਬਰ ਹੈ ਜੀ। ਪ੍ਰਤੀ ਏਕੜ 40-45 ਕਿਲੋ ਬੀਜ ਵਰਤੋ।"
                    MunshiLang.BHOJPURI -> "${greeting}गेहूं के बोआई के सही समय 25 अक्टूबर से 20 नवंबर तक बा भाई जी। प्रति एकड़ 40 से 45 किलो बीज के इस्तेमाल करीं।"
                    MunshiLang.ENGLISH -> "${greeting}The ideal sowing time for wheat is between October 25 and November 20. Use 40 to 45 kg of certified seeds per acre."
                    else -> "${greeting}गेहूं की बुवाई का सबसे उपयुक्त समय 25 अक्टूबर से 20 नवंबर तक है। पछेती बुवाई दिसंबर प्रथम सप्ताह तक की जा सकती है। प्रति एकड़ 40 से 45 किलोग्राम बीज का प्रयोग करें।"
                }
            }
            // Irrigation / Water
            if (q.contains("पानी") || q.contains("सिंचाई") || q.contains("पहला पानी") || q.contains("कोर")) {
                return when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}गेहूं म्ह कुल 4 तै 6 पानी लागैं भाई। पहला पानी (कोर पानी) बिजाई के 21 दिन पाछै (सीआरआई स्टेज पै) जरूर दियो, अर साथ म्ह 1 बोरी यूरिया अर जिंक घालियो।"
                    MunshiLang.RAJASTHANI -> "${greeting}गेहूं मांय 4 सूं 6 पानी लागी सा। पहलो पानी बिजाई रा 21 दिन पाछै जड़ फूटते टेम देवणो छै, साथे 1 बोरी यूरिया देवो सा।"
                    MunshiLang.PUNJABI -> "${greeting}ਕਣਕ ਨੂੰ 4 ਤੋਂ 6 ਪਾਣੀ ਲੱਗਦੇ ਹਨ। ਪਹਿਲਾ ਪਾਣੀ ਬਿਜਾਈ ਦੇ 21ਵੇਂ ਦਿਨ (CRI ਸਟੇਜ) 'ਤੇ ਜ਼ਰੂਰ ਲਾਓ ਅਤੇ ਨਾਲ 1 ਬੋਰੀ ਯੂਰੀਆ ਪਾਓ।"
                    MunshiLang.BHOJPURI -> "${greeting}गेहूं में 4 से 6 पानी के जरूरत पड़ेला। पहिला पानी बोआई के 21 दिन बाद (शिखर जड़ निकलते समय) जरूर दीहीं, संगे 1 बोरी यूरिया डालीं।"
                    MunshiLang.ENGLISH -> "${greeting}Wheat requires 4 to 6 irrigations. The crucial first irrigation (Crown Root Initiation) must be given 20-22 days after sowing along with urea."
                    else -> "${greeting}गेहूं में कुल 4 से 6 सिंचाइयों की आवश्यकता होती है। पहला पानी (कोर पानी) बुवाई के 21 दिन बाद 'ताज जड़' (CRI) अवस्था पर अवश्य दें। साथ में 1 बोरी यूरिया व 5 किलो 33% जिंक दें।"
                }
            }
            // Weeds (गुल्ली डंडा / मंडूसी / बथुआ)
            if (q.contains("खरपतवार") || q.contains("गुल्ली डंडा") || q.contains("मंडूसी") || q.contains("बथुआ") || q.contains("घास")) {
                return when (lang) {
                    MunshiLang.HARYANVI -> "${greeting}गुल्ली डंडा (मंडूसी) खातर क्लोडिनाफॉप 15% WP (160 ग्राम) या सल्फोसल्फ्यूरॉन 75% (13.5 ग्राम) बिजाई के 30-35 दिन पाछै 150 लीटर पानी म्ह स्प्रे करियो भाई।"
                    MunshiLang.PUNJABI -> "${greeting}ਗੁੱਲੀ ਡੰਡੇ ਲਈ ਕਲੋਡੀਨਾਫੌਪ (160 ਗ੍ਰਾਮ) ਜਾਂ ਸਲਫੋਸਲਫਿਊਰਾਨ 30-35 ਦਿਨਾਂ 'ਤੇ 150 ਲੀਟਰ ਪਾਣੀ ਵਿੱਚ ਮਿਲਾ ਕੇ ਸਪਰੇਅ ਕਰੋ ਜੀ।"
                    else -> "${greeting}गेहूं में गुल्ली डंडा (मंडूसी) के नियंत्रण के लिए क्लोडिनाफॉप 15% WP (160 ग्राम) या सल्फोसल्फ्यूरॉन 75% WG (13.5 ग्राम) प्रति एकड़ 150 लीटर पानी में 30-35 दिन पर स्प्रे करें।"
                }
            }
            // Yellow rust (पीला रतुआ)
            if (q.contains("रतुआ") || q.contains("पीला") || q.contains("हल्दी") || q.contains("फफूंद")) {
                return "${greeting}गेहूं में पीला रतुआ (पत्तियों पर हल्दी जैसा पीला पाउडर) दिखे तो प्रोपिकोनाजोल 25% EC (टिल्ट) 200 मिली प्रति एकड़ 200 लीटर पानी में तुरंत छिड़कें।"
            }
        }

        // 2. MUSTARD (सरसों / राया)
        if (isMustard) {
            // Sowing time
            if (q.contains("बुवाई") || q.contains("बोने") || q.contains("बिजाई") || q.contains("समय") || q.contains("कब")) {
                return "${greeting}सरसों की बुवाई का सबसे उत्तम समय 25 सितंबर से 15 अक्टूबर है। प्रति एकड़ 1.5 से 2 किलोग्राम प्रमाणित बीज पर्याप्त रहता है।"
            }
            // Irrigation
            if (q.contains("पानी") || q.contains("सिंचाई")) {
                return "${greeting}सरसों में मुख्य रूप से 2 पानी की आवश्यकता होती है: पहला पानी फूल आने से पहले (25-30 दिन पर) और दूसरा फलियां बनते समय (50-60 दिन पर)। फूल खिलने के समय भारी पानी न दें।"
            }
            // Aphids / Mahu / Chepa
            if (q.contains("माहू") || q.contains("चेपा") || q.contains("कीड़ा") || q.contains("तेला") || q.contains("दवा")) {
                return "${greeting}सरसों में माहू (चेपा) कीट के नियंत्रण के लिए इमिडाक्लोप्रिड 17.8% SL (50-60 मिली) या थायमेथोक्सम 25% WG (80 ग्राम) प्रति एकड़ 150 लीटर पानी में मिलाकर छिड़काव करें।"
            }
            // Sulfur / Fertilizer
            if (q.contains("खाद") || q.contains("सल्फर") || q.contains("उर्वरक")) {
                return "${greeting}सरसों में बिजाई के समय 1 बोरी DAP के साथ 10-15 किलो बेंटोनाइट सल्फर अवश्य डालें। सल्फर से दानों में तेल की मात्रा और चमक बहुत बढ़ती है।"
            }
        }

        // 3. PADDY / RICE (धान / जीरी)
        if (isPaddy) {
            // Water management
            if (q.contains("पानी") || q.contains("सिंचाई")) {
                return "${greeting}धान की रोपाई के शुरुआती 15-20 दिनों तक खेत में 2 से 3 इंच पानी खड़ा रखें ताकि खरपतवार न उगे और कल्ले तेजी से फूटें।"
            }
            // Fertilizers
            if (q.contains("खाद") || q.contains("यूरिया") || q.contains("dap") || q.contains("जिंक")) {
                return "${greeting}धान में रोपाई के समय 1 बोरी DAP + 10 किलो 21% जिंक डालें। यूरिया को 3 बराबर किश्तों में दें: पहली 20 दिन पर, दूसरी 40 दिन पर और तीसरी कल्ले फूटने पर।"
            }
            // Stem borer / pests
            if (q.contains("सुंडी") || q.contains("कीड़ा") || q.contains("तना छेदक") || q.contains("पत्ता लपेट")) {
                return "${greeting}धान में तना छेदक या पत्ता लपेट सुंडी के लिए कारटैप हाइड्रोक्लोराइड 4G (7.5 किलो प्रति एकड़) या कोराजन 60 मिली प्रति एकड़ का प्रयोग करें।"
            }
        }

        // 4. SUGARCANE (गन्ना)
        if (isCane) {
            if (q.contains("खाद") || q.contains("उर्वरक")) {
                return "${greeting}गन्ने में बुवाई के समय 2 बोरी DAP और 1 बोरी पोटाश डालें। बाद में गर्मियों में 3 से 4 बोरी यूरिया सिंचाई के साथ किश्तों में दें।"
            }
            if (q.contains("कीड़ा") || q.contains("सुंडी") || q.contains("कंसुआ") || q.contains("टॉप बोरर")) {
                return "${greeting}गन्ने में कंसुआ और टॉप बोरर की रोकथाम के लिए कोराजन 150 मिली प्रति एकड़ 400 लीटर पानी में घोलकर जड़ों के पास ड्रेन्चिंग करें।"
            }
        }

        // 5. GENERAL FERTILIZERS (यूरिया, DAP, जिंक, नैनो यूरिया)
        if (isFertilizer) {
            if (q.contains("नैनो") || q.contains("nano")) {
                return "${greeting}नैनो यूरिया का प्रयोग 4 मिली प्रति लीटर पानी (प्रति एकड़ 500 मिली बोतल 125-150 लीटर पानी में) फसल के कल्ले फूटते समय पत्तियों पर स्प्रे करें। यह जमीन और पैसे दोनों बचाती है।"
            }
            if ((q.contains("जिंक") && q.contains("dap")) || q.contains("मिला")) {
                return "${greeting}सावधानी: जिंक सल्फेट और DAP को कभी भी एक साथ मिलाकर न डालें! दोनों मिलकर जिंक फॉस्फेट बना लेते हैं जो पौधे नहीं ले पाते। जिंक को यूरिया के साथ या अलग से डालें।"
            }
            if (q.contains("यूरिया") && (q.contains("कब") || q.contains("तरीका") || q.contains("नियम"))) {
                return "${greeting}यूरिया हमेशा 2 से 3 किश्तों में दें। एक साथ पूरी बोरी न डालें। यूरिया हमेशा शाम के समय या हल्की सिंचाई के बाद नमी वाले खेत में डालें ताकि गैस बनकर उड़े नहीं।"
            }
        }

        // 6. PESTS & DISEASES (दीमक, फफूंद, साफ पाउडर)
        if (isPestOrDisease) {
            if (q.contains("दीमक")) {
                return "${greeting}खेत में दीमक की रोकथाम के लिए क्लोरपायरीफॉस 20% EC (1.5 से 2 लीटर प्रति एकड़) सिंचाई के पानी के साथ चलाएं या रेत में मिलाकर खेत में बिखेरें।"
            }
            if (q.contains("फफूंद") || q.contains("उकठा") || q.contains("धब्बा") || q.contains("गलन")) {
                return "${greeting}फफूंद जनित रोगों के लिए साफ (Saaf) पाउडर (कार्बेन्डाजिम 12% + मैनकोजेब 63% WP) 2 ग्राम प्रति लीटर पानी में मिलाकर छिड़काव करें।"
            }
        }

        // 7. TUBEWELL MOTOR & IRRIGATION
        if (isMotorOrIrrigation) {
            if (q.contains("गर्म") || q.contains("ट्रिप") || q.contains("धुआं")) {
                return "${greeting}ट्यूबवेल मोटर गर्म होने या बार-बार ट्रिप होने के मुख्य कारण: कम वोल्टेज, कैपेसिटर वीक होना, या बोरवेल से बालू/रेत आना है। स्टार्टर की रिले सेटिंग और वोल्टेज जरूर चेक कराएं।"
            }
            if (q.contains("पानी कम") || q.contains("प्रेशर")) {
                return "${greeting}ट्यूबवेल से पानी कम आने पर: डिलीवरी पाइप में लीकेज, फुटवाल्व में कचरा फंसना, या वाटर लेवल नीचे जाना मुख्य वजह होती है। पाइप और फुटवाल्व की जांच करें।"
            }
        }

        // 8. BANANA (केला / केले की फसल)
        if (isBanana) {
            return "${greeting}केले की फसल लगाने का सबसे उत्तम समय जून से जुलाई (मानसून की शुरुआत) या मध्य/दक्षिण भारत में सितंबर से अक्टूबर है। रोपाई के लिए 'जी-9' (ग्रैंड नैने) किस्म सबसे बढ़िया मानी जाती है। गड्ढे में 20 किलो सड़ी गोबर खाद, 200 ग्राम डीएपी व 50 ग्राम नीम की खली डालकर 6x6 फीट की दूरी पर पौधे लगाएं और नियमित ड्रिप या नालियों से नमी बनाए रखें।"
        }

        // 9. POTATO (आलू की बुवाई)
        if (isPotato) {
            return "${greeting}आलू की बुवाई का सर्वोत्तम समय 15 से 25 अक्टूबर (अगेती) और नवंबर के प्रथम सप्ताह (मुख्य फसल) तक है। कुफरी पुखराज, कुफरी ज्योति और कुफरी बहार लोकप्रिय किस्में हैं। प्रति एकड़ 12 से 15 क्विंटल बीज का प्रयोग करें और कतार से कतार 50 सेमी व पौधे से पौधा 20 सेमी रखें।"
        }

        // 10. COTTON (कपास / नरमा)
        if (isCotton) {
            return "${greeting}कपास (नरमा) की बिजाई का सबसे सही समय 15 अप्रैल से 15 मई तक है। प्रति एकड़ 2 पैकेट बीटी कॉटन बीज का प्रयोग करें। गुलाबी सुंडी से बचाव के लिए फेरोमोन ट्रैप लगाएं और संतुलित पोटाश व जिंक दें।"
        }

        // 11. VEGETABLES (टमाटर, मिर्च, प्याज, सब्जियां)
        if (isVegetables) {
            return "${greeting}सब्जियों (टमाटर, मिर्च, प्याज) की रोपाई मेड़ों पर करें ताकि जड़ों में पानी न भरे। रोपाई से पहले खेत में ट्राइकोडर्मा और गोबर की खाद मिलाकर डालें जिससे उकठा और फफूंद रोग न फैले।"
        }

        return null
    }

    data class MonthInfo(
        val monthIndex: Int, // 0-indexed (0 = Jan, 11 = Dec)
        val hindiName: String,
        val nativeNames: Map<MunshiLang, String>
    )

    fun extractRequestedMonth(q: String): MonthInfo? {
        val lower = q.lowercase(Locale.ROOT)
        return when {
            lower.contains("जनवरी") || lower.contains("january") || lower.contains("jan") ->
                MonthInfo(0, "जनवरी", mapOf(
                    MunshiLang.HARYANVI to "जनवरी",
                    MunshiLang.BHOJPURI to "जनवरी",
                    MunshiLang.RAJASTHANI to "जनवरी",
                    MunshiLang.PUNJABI to "ਜਨਵਰੀ",
                    MunshiLang.ENGLISH to "January"
                ))
            lower.contains("फरवरी") || lower.contains("february") || lower.contains("feb") ->
                MonthInfo(1, "फरवरी", mapOf(
                    MunshiLang.HARYANVI to "फरवरी",
                    MunshiLang.BHOJPURI to "फरवरी",
                    MunshiLang.RAJASTHANI to "फरवरी",
                    MunshiLang.PUNJABI to "ਫ਼ਰਵਰੀ",
                    MunshiLang.ENGLISH to "February"
                ))
            lower.contains("मार्च") || lower.contains("march") || lower.contains("mar") ->
                MonthInfo(2, "मार्च", mapOf(
                    MunshiLang.HARYANVI to "मार्च",
                    MunshiLang.BHOJPURI to "मार्च",
                    MunshiLang.RAJASTHANI to "मार्च",
                    MunshiLang.PUNJABI to "ਮਾਰਚ",
                    MunshiLang.ENGLISH to "March"
                ))
            lower.contains("अप्रैल") || lower.contains("april") || lower.contains("apr") ->
                MonthInfo(3, "अप्रैल", mapOf(
                    MunshiLang.HARYANVI to "अप्रैल",
                    MunshiLang.BHOJPURI to "अप्रैल",
                    MunshiLang.RAJASTHANI to "अप्रैल",
                    MunshiLang.PUNJABI to "ਅਪ੍ਰੈਲ",
                    MunshiLang.ENGLISH to "April"
                ))
            lower.contains("मई") || lower.contains("may") ->
                MonthInfo(4, "मई", mapOf(
                    MunshiLang.HARYANVI to "मई",
                    MunshiLang.BHOJPURI to "मई",
                    MunshiLang.RAJASTHANI to "मई",
                    MunshiLang.PUNJABI to "ਮਈ",
                    MunshiLang.ENGLISH to "May"
                ))
            lower.contains("जून") || lower.contains("june") || lower.contains("jun") ->
                MonthInfo(5, "जून", mapOf(
                    MunshiLang.HARYANVI to "जून",
                    MunshiLang.BHOJPURI to "जून",
                    MunshiLang.RAJASTHANI to "जून",
                    MunshiLang.PUNJABI to "ਜੂਨ",
                    MunshiLang.ENGLISH to "June"
                ))
            lower.contains("जुलाई") || lower.contains("july") || lower.contains("jul") ->
                MonthInfo(6, "जुलाई", mapOf(
                    MunshiLang.HARYANVI to "जुलाई",
                    MunshiLang.BHOJPURI to "जुलाई",
                    MunshiLang.RAJASTHANI to "जुलाई",
                    MunshiLang.PUNJABI to "ਜੁਲਾਈ",
                    MunshiLang.ENGLISH to "July"
                ))
            lower.contains("अगस्त") || lower.contains("august") || lower.contains("aug") ->
                MonthInfo(7, "अगस्त", mapOf(
                    MunshiLang.HARYANVI to "अगस्त",
                    MunshiLang.BHOJPURI to "अगस्त",
                    MunshiLang.RAJASTHANI to "अगस्त",
                    MunshiLang.PUNJABI to "ਅਗਸਤ",
                    MunshiLang.ENGLISH to "August"
                ))
            lower.contains("सितंबर") || lower.contains("september") || lower.contains("sep") ->
                MonthInfo(8, "सितंबर", mapOf(
                    MunshiLang.HARYANVI to "सितंबर",
                    MunshiLang.BHOJPURI to "सितंबर",
                    MunshiLang.RAJASTHANI to "सितंबर",
                    MunshiLang.PUNJABI to "ਸਤੰਬਰ",
                    MunshiLang.ENGLISH to "September"
                ))
            lower.contains("अक्टूबर") || lower.contains("october") || lower.contains("oct") ->
                MonthInfo(9, "अक्टूबर", mapOf(
                    MunshiLang.HARYANVI to "अक्टूबर",
                    MunshiLang.BHOJPURI to "अक्टूबर",
                    MunshiLang.RAJASTHANI to "अक्टूबर",
                    MunshiLang.PUNJABI to "ਅਕਤੂਬਰ",
                    MunshiLang.ENGLISH to "October"
                ))
            lower.contains("नवंबर") || lower.contains("november") || lower.contains("nov") ->
                MonthInfo(10, "नवंबर", mapOf(
                    MunshiLang.HARYANVI to "नवंबर",
                    MunshiLang.BHOJPURI to "नवंबर",
                    MunshiLang.RAJASTHANI to "नवंबर",
                    MunshiLang.PUNJABI to "ਨਵੰਬਰ",
                    MunshiLang.ENGLISH to "November"
                ))
            lower.contains("दिसंबर") || lower.contains("december") || lower.contains("dec") ->
                MonthInfo(11, "दिसंबर", mapOf(
                    MunshiLang.HARYANVI to "दिसंबर",
                    MunshiLang.BHOJPURI to "दिसंबर",
                    MunshiLang.RAJASTHANI to "दिसंबर",
                    MunshiLang.PUNJABI to "ਦਸੰਬਰ",
                    MunshiLang.ENGLISH to "December"
                ))
            else -> null
        }
    }

    private fun isSessionInMonth(sessionTime: Long, targetMonthIndex: Int): Boolean {
        val cal = Calendar.getInstance().apply { timeInMillis = sessionTime }
        return cal.get(Calendar.MONTH) == targetMonthIndex
    }

    private fun findMatchingCustomer(q: String, customers: List<CustomerWithStats>): CustomerWithStats? {
        val res = findMatchingCustomerResult(q, customers)
        return when (res) {
            is CustomerMatchResult.Single -> res.customer
            is CustomerMatchResult.Ambiguous -> res.matches.firstOrNull()
            null -> null
        }
    }
}
