package com.example.data.payment

import android.app.Activity
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.android.billingclient.api.*
import com.android.billingclient.api.ProductDetails
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.supabase.SupabaseAuthService
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Result of a Google Play Billing Payment.
 */
sealed class PaymentEvent {
    data class Success(val paymentId: String, val planType: String, val amount: Double) : PaymentEvent()
    data class Error(val code: Int, val message: String) : PaymentEvent()
}

/**
 * Google Play Billing Manager.
 * Handles official Google Play In-App Billing / Subscriptions securely.
 * Automatically syncs verified purchases with Supabase backend (`profiles` & `app_subscriptions`).
 */
object GooglePlayBillingManager : PurchasesUpdatedListener {
    private const val TAG = "GooglePlayBillingManager"

    // Google Play Console Product IDs for Subscriptions
    const val PRODUCT_ID_MONTHLY = "vip_monthly_subscription"
    const val PRODUCT_ID_YEARLY = "vip_yearly_subscription"

    private val _paymentEvents = MutableSharedFlow<PaymentEvent>(replay = 0)
    val paymentEvents = _paymentEvents.asSharedFlow()

    private val mainScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate + CoroutineExceptionHandler { _, t ->
            Log.w(TAG, "Billing main coroutine error: ${t.message}")
        }
    )
    private val ioScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, t ->
            Log.w(TAG, "Billing IO coroutine error: ${t.message}")
        }
    )

    private var billingClient: BillingClient? = null
    private var activeAppContext: Context? = null
    private var pendingPlanType: String = "MONTHLY"
    private var pendingAmount: Double = 49.0
    private var lastUserPhone: String = ""

    private fun isPlayStoreAvailable(context: Context): Boolean {
        return try {
            val info = context.applicationContext.packageManager.getApplicationInfo("com.android.vending", 0)
            info.enabled
        } catch (_: Throwable) {
            false
        }
    }

    fun init(context: Context) {
        if (billingClient != null) return
        if (!isPlayStoreAvailable(context)) {
            Log.d(TAG, "Google Play Store not available — skipping background BillingClient init.")
            return
        }
        try {
            activeAppContext = context.applicationContext
            billingClient = BillingClient.newBuilder(context.applicationContext)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build()

            connectToPlayStore()
        } catch (t: Throwable) {
            Log.w(TAG, "Google Play Billing init failed safely: ${t.message}")
            billingClient = null
        }
    }

    private fun connectToPlayStore() {
        try {
            billingClient?.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(billingResult: BillingResult) {
                    if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        Log.d(TAG, "Google Play Billing setup successful.")
                    } else {
                        Log.w(TAG, "Google Play Billing setup failed: ${billingResult.debugMessage}")
                    }
                }

                override fun onBillingServiceDisconnected() {
                    Log.w(TAG, "Google Play Billing service disconnected. Retrying...")
                }
            })
        } catch (t: Throwable) {
            Log.w(TAG, "Google Play Billing startConnection failed safely: ${t.message}")
        }
    }

    /**
     * Launch Google Play Billing purchase flow for Monthly or Yearly VIP subscription.
     */
    fun startPurchase(
        activity: Activity,
        planType: String,
        amountRupees: Double,
        userPhone: String = "",
        userEmail: String = ""
    ) {
        if (activity.isFinishing || activity.isDestroyed) return
        try {
            pendingPlanType = planType
            pendingAmount = amountRupees
            lastUserPhone = userPhone
            activeAppContext = activity.applicationContext

            val productId = if (planType.contains("YEAR", ignoreCase = true)) PRODUCT_ID_YEARLY else PRODUCT_ID_MONTHLY

            val client = billingClient ?: run {
                init(activity)
                billingClient
            } ?: run {
                Toast.makeText(activity, "Google Play Billing client unavailable", Toast.LENGTH_SHORT).show()
                return
            }

            if (!client.isReady) {
                Log.w(TAG, "BillingClient not ready. Reconnecting...")
                client.startConnection(object : BillingClientStateListener {
                    override fun onBillingSetupFinished(result: BillingResult) {
                        if (activity.isFinishing || activity.isDestroyed) return
                        if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                            queryAndLaunch(activity, productId)
                        } else {
                            activity.runOnUiThread {
                                if (!activity.isFinishing && !activity.isDestroyed) {
                                    Toast.makeText(activity, "Google Play से कनेक्ट नहीं हो सका। कृपया पुनः प्रयास करें।", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }
                    override fun onBillingServiceDisconnected() {}
                })
                return
            }

            queryAndLaunch(activity, productId)
        } catch (t: Throwable) {
            Log.w(TAG, "startPurchase failed safely: ${t.message}")
            try {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    Toast.makeText(activity, "Google Play बिलिंग उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Throwable) {}
        }
    }

    private fun queryAndLaunch(activity: Activity, productId: String) {
        try {
            val client = billingClient ?: return
            val productList = listOf(
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(productId)
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build()
            )

            val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()

            client.queryProductDetailsAsync(params) { billingResult, productDetailsList ->
                try {
                    if (activity.isFinishing || activity.isDestroyed) return@queryProductDetailsAsync
                    val list = productDetailsList as? java.util.List<ProductDetails>
                    val productDetails = if (list != null && !list.isEmpty()) list[0] else null
                    if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && productDetails != null) {
                        val offerToken = productDetails.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: ""

                        val productDetailsParamsList = listOf(
                            BillingFlowParams.ProductDetailsParams.newBuilder()
                                .setProductDetails(productDetails)
                                .setOfferToken(offerToken)
                                .build()
                        )

                        val billingFlowParams = BillingFlowParams.newBuilder()
                            .setProductDetailsParamsList(productDetailsParamsList)
                            .build()

                        activity.runOnUiThread {
                            if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
                            try {
                                val responseCode = client.launchBillingFlow(activity, billingFlowParams).responseCode
                                if (responseCode != BillingClient.BillingResponseCode.OK) {
                                    Toast.makeText(activity, "बिलिंग flow शुरू करने में त्रुटि (Code: $responseCode)", Toast.LENGTH_LONG).show()
                                }
                            } catch (t: Throwable) {
                                Log.w(TAG, "launchBillingFlow failed safely: ${t.message}")
                            }
                        }
                    } else {
                        Log.e(TAG, "Product not found in Google Play Console: $productId. Result: ${billingResult.debugMessage}")
                        activity.runOnUiThread {
                            if (!activity.isFinishing && !activity.isDestroyed) {
                                Toast.makeText(activity, "उत्पाद (Product ID: $productId) Google Play पर उपलब्ध नहीं है।", Toast.LENGTH_LONG).show()
                            }
                            mainScope.launch {
                                _paymentEvents.emit(PaymentEvent.Error(billingResult.responseCode, "Product not found: $productId"))
                            }
                        }
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "queryProductDetailsAsync callback failed safely: ${t.message}")
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "queryAndLaunch failed safely: ${t.message}")
        }
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: List<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && !purchases.isNullOrEmpty()) {
            for (purchase in purchases) {
                handlePurchase(purchase)
            }
        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            Log.i(TAG, "User canceled the purchase.")
            mainScope.launch {
                _paymentEvents.emit(PaymentEvent.Error(BillingClient.BillingResponseCode.USER_CANCELED, "पेमेंट रद्द कर दिया गया।"))
            }
        } else {
            Log.w(TAG, "Purchase failed or error: ${billingResult.responseCode} - ${billingResult.debugMessage}")
            mainScope.launch {
                _paymentEvents.emit(PaymentEvent.Error(billingResult.responseCode, billingResult.debugMessage ?: "खरीद विफल"))
            }
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            val purchaseToken = purchase.purchaseToken
            val orderId = purchase.orderId ?: "GP_${System.currentTimeMillis()}"
            val isYearly = purchase.products.any { it.contains("year", ignoreCase = true) }
            val planType = if (isYearly) "YEARLY" else "MONTHLY"
            val daysToAdd = if (isYearly) 365 else 30

            // Acknowledge purchase if not already acknowledged
            if (!purchase.isAcknowledged) {
                val acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchaseToken)
                    .build()
                billingClient?.acknowledgePurchase(acknowledgePurchaseParams) { billingResult ->
                    if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        Log.d(TAG, "Purchase acknowledged successfully.")
                    }
                }
            }

            val context = activeAppContext
            if (context != null) {
                // 1. Locally update subscription days in SharedPreferences
                val newTotalDays = RemoteConfigService.addVipSubscription(
                    context = context,
                    planType = planType,
                    daysToAdd = daysToAdd,
                    phone = lastUserPhone
                )
                val expiryTimestamp = RemoteConfigService.vipExpiryTimestamp.value

                // 2. Securely sync/verify subscription with Supabase backend so Supabase remains source of truth
                val phoneToSync = lastUserPhone
                ioScope.launch {
                    try {
                        syncSubscriptionToSupabase(
                            context = context,
                            paymentId = orderId,
                            planType = planType,
                            amount = pendingAmount,
                            phone = phoneToSync,
                            daysAdded = daysToAdd,
                            totalDaysRemaining = newTotalDays,
                            expiryTimestamp = expiryTimestamp,
                            purchaseToken = purchaseToken
                        )
                    } catch (t: Throwable) {
                        Log.w(TAG, "syncSubscriptionToSupabase failed: ${t.message}")
                    }
                }
            }

            mainScope.launch {
                _paymentEvents.emit(PaymentEvent.Success(orderId, planType, pendingAmount))
            }
        }
    }

    /**
     * Securely syncs and updates the subscription status in Supabase backend tables (`profiles` & `app_subscriptions`).
     */
    private suspend fun syncSubscriptionToSupabase(
        context: Context,
        paymentId: String,
        planType: String,
        amount: Double,
        phone: String,
        daysAdded: Int,
        totalDaysRemaining: Int,
        expiryTimestamp: Long,
        purchaseToken: String
    ) {
        if (!SupabaseAuthService.isConfigured(context)) return
        val baseUrl = SupabaseAuthService.getSupabaseUrl(context)
        val anonKey = SupabaseAuthService.getSupabaseAnonKey(context)

        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val isoExpiry = sdf.format(Date(expiryTimestamp))

        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").trim()
        if (cleanPhone.length >= 6) {
            try {
                val encodedPhone = java.net.URLEncoder.encode("*$cleanPhone*", "UTF-8")
                val profileEndpoint = "$baseUrl/rest/v1/profiles?phone=ilike.$encodedPhone"
                val profileConn = (URL(profileEndpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "PATCH"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "return=minimal")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }
                val profileBody = JSONObject().apply {
                    put("vip_member", true)
                    put("is_premium", true)
                    put("vip_plan", planType)
                    put("vip_days_remaining", totalDaysRemaining)
                    put("vip_expiry", isoExpiry)
                    put("updated_at", System.currentTimeMillis())
                }
                OutputStreamWriter(profileConn.outputStream).use { it.write(profileBody.toString()) }
                val pCode = profileConn.responseCode
                Log.d(TAG, "Supabase profiles VIP updated via Google Play Billing, code: $pCode, days: $totalDaysRemaining")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to update profiles VIP columns: ${e.message}")
            }
        }

        // Insert into app_subscriptions / user_subscriptions table
        val targetTables = listOf("app_subscriptions", "user_subscriptions")
        for (tbl in targetTables) {
            try {
                val endpoint = "$baseUrl/rest/v1/$tbl"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Prefer", "return=minimal")
                    SupabaseAuthService.applyAuthHeaders(this, anonKey)
                }

                val body = JSONObject().apply {
                    put("payment_id", paymentId)
                    put("phone", phone)
                    put("plan_type", planType)
                    put("amount", amount)
                    put("days_added", daysAdded)
                    put("total_days_remaining", totalDaysRemaining)
                    put("expires_at", isoExpiry)
                    put("is_premium", true)
                    put("is_active", true)
                    put("payment_status", "SUCCESS")
                    put("platform", "GOOGLE_PLAY_BILLING")
                    put("purchase_token", purchaseToken)
                }

                OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
                val code = conn.responseCode
                Log.d(TAG, "Supabase $tbl Google Play sync response code: $code")
                if (code in 200..299) break
            } catch (e: Exception) {
                Log.w(TAG, "Failed to insert into $tbl: ${e.message}")
            }
        }
    }
}
