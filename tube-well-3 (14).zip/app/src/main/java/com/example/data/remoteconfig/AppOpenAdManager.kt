package com.example.data.remoteconfig

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Date

/**
 * AppOpenAdManager - Manages Google AdMob App Open Ads following official Google Publisher Policies.
 *
 * Strict Policy & Business Rules:
 * 1. ONE AD PER SCREEN / ZERO OVERLAP: Tracks isAppOpenAdShowing so banner ads stay hidden until App Open Ad is closed.
 * 2. SHOW ONCE PER LAUNCH/SESSION: Displays strictly ONCE per app launch session.
 * 3. VIP ONLY AD-FREE: Only active VIP membership disables App Open Ads and Banner Ads.
 * 4. REMOTE CONFIG & SUPABASE TOGGLE: Can be controlled remotely via Supabase table 'app_remote_config' (screen_name='APP_OPEN').
 * 5. ROBUST PRELOAD & TIMEOUT: If ad is still loading when splash completes, waits up to maxWaitMs to show, then gracefully continues.
 */
object AppOpenAdManager {

    private const val TAG = "AppOpenAdManager"

    // Official Google AdMob Test App Open Ad Unit ID (Cleared to force production usage)
    const val DEFAULT_TEST_APP_OPEN_ID = ""

    // Live reference to the current foreground Activity
    var currentActivity: Activity? = null

    private var appOpenAd: AppOpenAd? = null
    private var isLoadingAd = false
    private var loadTime: Long = 0

    // List of pending callbacks waiting for ad load
    private val pendingCallbacks = mutableListOf<(Boolean) -> Unit>()

    // Tracks if an App Open Ad is currently taking up full screen
    private val _isAppOpenAdShowing = MutableStateFlow(false)
    val isAppOpenAdShowing: StateFlow<Boolean> = _isAppOpenAdShowing.asStateFlow()

    // Tracks last status message for transparency/debugging
    private val _lastStatus = MutableStateFlow("आइडल (प्रतीक्षा में)")
    val lastStatus: StateFlow<String> = _lastStatus.asStateFlow()

    private var loadingStartTime = 0L
    private var lastShownTimeMs = 0L

    // Flag: Only show once per app launch/session
    var hasShownInThisSession = false
        private set

    // If ad finished loading while a system permission/consent popup paused the Activity,
    // show it as soon as Activity resumes instead of discarding the matched ad.
    private var pendingShowOnResume = false

    /**
     * Checks if a cached ad exists and was loaded less than 4 hours ago.
     */
    fun isAdAvailable(): Boolean {
        val isNotExpired = (Date().time - loadTime) < (4L * 3600000L)
        return appOpenAd != null && isNotExpired
    }

    /**
     * Preloads an App Open Ad in background on the Main Thread.
     */
    fun loadAd(context: Context, onResult: ((Boolean) -> Unit)? = null) {
        val mainHandler = Handler(Looper.getMainLooper())
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { loadAd(context, onResult) }
            return
        }

        // Do not load if already shown in this session (prevents wasted 0-impression ad requests)
        if (hasShownInThisSession) {
            Log.d(TAG, "App Open Ad already shown in this session - skipping extra load.")
            onResult?.invoke(false)
            return
        }

        // Do not load if user is VIP
        if (RemoteConfigService.isAdFreeUser.value) {
            Log.d(TAG, "User is VIP - skipping App Open Ad load.")
            _lastStatus.value = "VIP यूजर (ऐड बंद)"
            onResult?.invoke(false)
            return
        }

        // Check if remote config has App Open ads enabled
        val config = RemoteConfigService.configsFlow.value["APP_OPEN"]
        if (config != null && !config.isEnabled) {
            Log.d(TAG, "App Open Ad is disabled by Remote Config (Supabase).")
            _lastStatus.value = "रिमोट कॉन्फ़िग द्वारा बंद"
            onResult?.invoke(false)
            return
        }

        if (isAdAvailable()) {
            _lastStatus.value = "ऐड पहले से लोड है (तैयार)"
            onResult?.invoke(true)
            return
        }

        if (onResult != null) {
            pendingCallbacks.add(onResult)
        }

        // Recovery: If previously stuck loading for > 15 seconds, reset and allow retry
        val now = System.currentTimeMillis()
        if (isLoadingAd && (now - loadingStartTime < 15_000L)) {
            _lastStatus.value = "ऐड लोड हो रहा है..."
            return
        }

        isLoadingAd = true
        loadingStartTime = now
        val rawUnitId = config?.adUnitId?.trim() ?: ""
        val adUnitId = if (rawUnitId.isNotBlank() && rawUnitId.startsWith("ca-app-pub-")) {
            rawUnitId
        } else {
            "ca-app-pub-8640508231791309/6228809416"
        }
        _lastStatus.value = "AdMob अनुरोध भेजा जा रहा है ($adUnitId)..."
        Log.d(TAG, "Loading App Open Ad with Unit ID: $adUnitId (raw was '$rawUnitId')")

        try {
            val request = AdRequest.Builder().build()
            AppOpenAd.load(
                context.applicationContext,
                adUnitId,
                request,
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        Log.d(TAG, "✅ App Open Ad loaded successfully for $adUnitId")
                        appOpenAd = ad
                        isLoadingAd = false
                        loadTime = Date().time
                        _lastStatus.value = "✅ विज्ञापन लोड हो गया"

                        val callbacks = ArrayList(pendingCallbacks)
                        pendingCallbacks.clear()
                        callbacks.forEach { it.invoke(true) }
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        Log.w(TAG, "❌ App Open Ad failed to load for $adUnitId: ${loadAdError.message} (code=${loadAdError.code})")
                        isLoadingAd = false
                        appOpenAd = null
                        _lastStatus.value = "❌ लोड विफल (कोड: ${loadAdError.code}): ${loadAdError.message}"

                        val callbacks = ArrayList(pendingCallbacks)
                        pendingCallbacks.clear()
                        callbacks.forEach { it.invoke(false) }
                    }
                }
            )
        } catch (t: Throwable) {
            Log.w(TAG, "AppOpenAd.load threw exception safely caught: ${t.message}")
            isLoadingAd = false
            appOpenAd = null
            _lastStatus.value = "विज्ञापन उपलब्ध नहीं"
            val callbacks = ArrayList(pendingCallbacks)
            pendingCallbacks.clear()
            callbacks.forEach { it.invoke(false) }
        }
    }

    /**
     * Shows the App Open Ad if available or waits up to maxWaitMs for it to finish loading.
     * If force = true, overrides previous session flag so it will display on Home page.
     */
    fun showAdOrWait(
        activity: Activity? = null,
        maxWaitMs: Long = 5000L,
        force: Boolean = false,
        onDone: () -> Unit
    ) {
        val mainHandler = Handler(Looper.getMainLooper())
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { showAdOrWait(activity, maxWaitMs, force, onDone) }
            return
        }

        val targetActivity = activity ?: currentActivity
        if (targetActivity == null || targetActivity.isFinishing || targetActivity.isDestroyed) {
            Log.d(TAG, "No valid activity available to show App Open Ad.")
            onDone()
            return
        }

        // 1. If user is VIP -> Never show
        if (RemoteConfigService.isAdFreeUser.value) {
            Log.d(TAG, "VIP user - suppressing App Open Ad.")
            onDone()
            return
        }

        // 2. Check Remote Config toggle
        val config = RemoteConfigService.configsFlow.value["APP_OPEN"]
        if (config != null && !config.isEnabled) {
            Log.d(TAG, "App Open Ad disabled via remote config / Supabase.")
            onDone()
            return
        }

        // 3. Rule: Check session / frequency
        if (force) {
            hasShownInThisSession = false
        } else if (hasShownInThisSession) {
            Log.d(TAG, "App Open Ad already shown in this session.")
            onDone()
            return
        }

        // 4. If ad already available, show immediately
        if (isAdAvailable() && appOpenAd != null) {
            displayLoadedAd(targetActivity, onDone)
            return
        }

        // 5. If ad is not ready, trigger load with timeout
        var isHandled = false

        val timeoutRunnable = Runnable {
            if (!isHandled) {
                isHandled = true
                Log.d(TAG, "App Open Ad wait timed out (${maxWaitMs}ms). Proceeding to app.")
                onDone()
            }
        }
        mainHandler.postDelayed(timeoutRunnable, maxWaitMs)

        loadAd(targetActivity.applicationContext) { success ->
            mainHandler.removeCallbacks(timeoutRunnable)
            if (!isHandled) {
                isHandled = true
                if (success && isAdAvailable() && !targetActivity.isFinishing && !targetActivity.isDestroyed) {
                    displayLoadedAd(targetActivity, onDone)
                } else {
                    onDone()
                }
            }
        }
    }

    /**
     * Internal helper to display loaded ad with callbacks on main thread.
     */
    private fun displayLoadedAd(activity: Activity, onDismissed: () -> Unit) {
        val mainHandler = Handler(Looper.getMainLooper())
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { displayLoadedAd(activity, onDismissed) }
            return
        }

        val ad = appOpenAd
        val isResumed = (activity as? androidx.lifecycle.LifecycleOwner)
            ?.lifecycle?.currentState?.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED) ?: true
        if (ad == null || activity.isFinishing || activity.isDestroyed) {
            _isAppOpenAdShowing.value = false
            pendingShowOnResume = false
            onDismissed()
            return
        }
        if (!isResumed) {
            // Activity is temporarily paused (e.g. system notification permission dialog); keep ad and show on resume
            pendingShowOnResume = true
            _isAppOpenAdShowing.value = false
            onDismissed()
            return
        }

        pendingShowOnResume = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "App Open Ad displayed full screen.")
                _isAppOpenAdShowing.value = true
                hasShownInThisSession = true
                lastShownTimeMs = System.currentTimeMillis()
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "App Open Ad dismissed by user.")
                _isAppOpenAdShowing.value = false
                appOpenAd = null
                pendingShowOnResume = false
                lastShownTimeMs = System.currentTimeMillis()
                onDismissed()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "App Open Ad failed to show: ${adError.message}")
                _isAppOpenAdShowing.value = false
                appOpenAd = null
                pendingShowOnResume = false
                onDismissed()
            }
        }

        try {
            hasShownInThisSession = true
            ad.show(activity)
        } catch (t: Throwable) {
            Log.w(TAG, "AppOpenAd.show threw exception safely caught: ${t.message}")
            _isAppOpenAdShowing.value = false
            appOpenAd = null
            onDismissed()
        }
    }

    /**
     * Clears any stale ad-showing overlay flag when the host Activity regains foreground focus.
     */
    fun onHostActivityResumed() {
        if (_isAppOpenAdShowing.value) {
            _isAppOpenAdShowing.value = false
        }
    }

    /**
     * Shows a deferred App Open Ad when Activity returns to RESUMED state after a permission/consent popup.
     */
    fun showPendingAdIfReady(activity: Activity) {
        if (!pendingShowOnResume || hasShownInThisSession) return
        if (activity.isFinishing || activity.isDestroyed) return
        if (isAdAvailable() && appOpenAd != null) {
            displayLoadedAd(activity) {}
        }
    }

    /**
     * Resets session state (e.g. on manual logout/restart).
     */
    fun resetSessionState() {
        hasShownInThisSession = false
        pendingShowOnResume = false
    }
}
