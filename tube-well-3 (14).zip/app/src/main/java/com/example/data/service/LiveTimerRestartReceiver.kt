package com.example.data.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * BroadcastReceiver to keep Live Pump Timer running across process recreation,
 * app clearing from recents, phone boot, and to process due payment reminders.
 */
class LiveTimerRestartReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "TimerRestartReceiver"
        const val ACTION_RESTART_TIMER_SERVICE = "com.example.service.ACTION_RESTART_TIMER_SERVICE"
        const val ACTION_CHECK_DUE_REMINDERS = "com.example.service.ACTION_CHECK_DUE_REMINDERS"

        private val receiverScope = CoroutineScope(
            SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, t ->
                Log.w(TAG, "Receiver coroutine error: ${t.message}")
            }
        )
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val appContext = context.applicationContext
        Log.d(TAG, "Broadcast received: $action")

        try {
            when (action) {
                Intent.ACTION_BOOT_COMPLETED,
                Intent.ACTION_MY_PACKAGE_REPLACED,
                "android.intent.action.QUICKBOOT_POWERON",
                ACTION_RESTART_TIMER_SERVICE -> {
                    // Ensure Background WorkManager & Alarms are scheduled
                    BackgroundNotificationScheduler.schedulePeriodicWork(appContext)

                    // Initialize state from SharedPreferences without double-starting foreground service
                    LiveTimerManager.init(appContext, notifyService = false)
                    val isRunning = LiveTimerPreferences.getIsRunning(appContext)
                    val isPaused = LiveTimerPreferences.getIsPaused(appContext)

                    if (isRunning) {
                        Log.d(TAG, "Restoring Live Pump Timer Foreground Service after restart/kill...")
                        val serviceIntent = Intent(appContext, LivePumpTimerService::class.java).apply {
                            this.action = if (isPaused) LivePumpTimerService.ACTION_PAUSE else LivePumpTimerService.ACTION_START
                        }
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                ContextCompat.startForegroundService(appContext, serviceIntent)
                            } else {
                                appContext.startService(serviceIntent)
                            }
                        } catch (t: Throwable) {
                            Log.e(TAG, "Failed to restore LivePumpTimerService: ${t.message}")
                        }
                    }
                }

                ACTION_CHECK_DUE_REMINDERS -> {
                    // Background check for overdue customer payments
                    if (DuePaymentReminderManager.isAutoReminderEnabled(appContext)) {
                        receiverScope.launch {
                            try {
                                DuePaymentReminderManager.checkAndPostDueNotifications(
                                    context = appContext,
                                    minDuration = DuePaymentReminderManager.getSelectedDuration(appContext),
                                    isManualTrigger = false
                                )
                            } catch (t: Throwable) {
                                Log.e(TAG, "Failed to run due reminders: ${t.message}")
                            }
                        }
                    }
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Unhandled error in LiveTimerRestartReceiver: ${t.message}")
        }
    }
}
