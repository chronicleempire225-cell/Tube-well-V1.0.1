package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.localization.AppLanguage
import com.example.data.remoteconfig.AppOpenAdManager
import com.example.data.util.AppUpdateUiState
import com.example.data.util.InAppUpdateManager
import com.example.ui.theme.AgriGreenContainer
import com.example.ui.theme.AgriGreenPrimary
import com.example.ui.theme.DividerColor
import com.example.ui.theme.PaidGreen
import com.example.ui.theme.RoyalOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Top-level App Update overlay that coordinates:
 * 1. Friendly Update Available Dialog (with BIG prominent Close button + top-right ✕ close button).
 * 2. Background Download progress bar banner (non-blocking).
 * 3. Ready-to-Install restart card once the flexible update finishes downloading.
 *
 * Automatically suppresses the popup while an App Open Ad is visible so screens never overlap.
 */
@Composable
fun AppUpdateOverlay(
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by InAppUpdateManager.uiState.collectAsState()
    val showDialog by InAppUpdateManager.showUpdateDialog.collectAsState()
    val isBannerDismissed by InAppUpdateManager.isDownloadBannerDismissed.collectAsState()
    val isAppOpenAdShowing by AppOpenAdManager.isAppOpenAdShowing.collectAsState()

    val isHindi = currentLanguage != AppLanguage.ENGLISH

    // 1. Friendly Optional Update Dialog (NEVER forced, ALWAYS has big clear Close button)
    if (showDialog && !isAppOpenAdShowing) {
        val availableVersion = (uiState as? AppUpdateUiState.UpdateAvailable)?.availableVersionCode
        AppUpdateAvailableDialog(
            isHindi = isHindi,
            onUpdateNow = {
                InAppUpdateManager.startFlexibleUpdate(context)
            },
            onClose = {
                InAppUpdateManager.dismissUpdatePrompt(context, availableVersion)
            }
        )
    }

    // 2. Non-blocking top banner for background download progress or Ready-to-Install
    val showDownloadingBanner = uiState is AppUpdateUiState.Downloading && !isBannerDismissed && !isAppOpenAdShowing
    val showReadyBanner = uiState is AppUpdateUiState.ReadyToInstall && !isBannerDismissed && !isAppOpenAdShowing

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        AnimatedVisibility(
            visible = showDownloadingBanner,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            val percent = (uiState as? AppUpdateUiState.Downloading)?.progressPercent ?: 0
            AppUpdateProgressBanner(
                isHindi = isHindi,
                progressPercent = percent,
                onDismiss = { InAppUpdateManager.dismissBanner() }
            )
        }

        AnimatedVisibility(
            visible = showReadyBanner,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            AppUpdateReadyBanner(
                isHindi = isHindi,
                onRestartAndInstall = { InAppUpdateManager.completeDownloadedUpdate(context) },
                onClose = { InAppUpdateManager.dismissBanner() }
            )
        }
    }
}

/**
 * Clean, bright-white Material 3 Update Popup with:
 * - Big top-right circular Close (✕) button (48dp touch target)
 * - Prominent Green "अभी अपडेट करें" button
 * - BIG full-width "✕ बंद करें (बाद में अपडेट करें)" close button so farmers/users never feel stuck
 */
@Composable
fun AppUpdateAvailableDialog(
    isHindi: Boolean,
    onUpdateNow: () -> Unit,
    onClose: () -> Unit
) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            shadowElevation = 12.dp,
            border = BorderStroke(1.dp, DividerColor),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .testTag("app_update_dialog")
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header banner with subtle agricultural green gradient + BIG top-right Close (✕) button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(AgriGreenPrimary, PaidGreen)
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 18.dp)
                ) {
                    // Big circular Close (✕) button at top-right (minimum 48dp touch target)
                    Surface(
                        onClick = onClose,
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.22f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.55f)),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(48.dp)
                            .testTag("update_dialog_top_close_btn")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = if (isHindi) "बंद करें" else "Close",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp, end = 36.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White,
                            modifier = Modifier.size(52.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.SystemUpdate,
                                    contentDescription = null,
                                    tint = AgriGreenPrimary,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isHindi) "नया अपडेट उपलब्ध है!" else "New Update Available!",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontSize = 21.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isHindi) {
                                "डिजिटल बही-खाता का नया और बेहतर वर्ज़न आ गया है"
                            } else {
                                "A newer, improved version of Digital Bahi Khata is ready"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.92f),
                            fontSize = 13.sp
                        )
                    }
                }

                // Body content
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    UpdateBenefitRow(
                        icon = Icons.Rounded.Speed,
                        text = if (isHindi) "तेज़ स्पीड, नए फ़ीचर्स और जरूरी सुधार" else "Faster speed, new features & bug fixes"
                    )
                    UpdateBenefitRow(
                        icon = Icons.Rounded.Security,
                        text = if (isHindi) "आपका पूरा बही-खाता डेटा 100% सुरक्षित रहेगा" else "All your ledger records remain 100% safe"
                    )
                    UpdateBenefitRow(
                        icon = Icons.Rounded.Download,
                        text = if (isHindi) "बैकग्राउंड में डाउनलोड होगा — आपका काम नहीं रुकेगा" else "Downloads in background without stopping your work"
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Primary Update Button
                    Button(
                        onClick = onUpdateNow,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AgriGreenPrimary,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(vertical = 14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("update_dialog_install_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Download,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "अभी अपडेट करें" else "Update Now",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp
                        )
                    }

                    // BIG Clear Close Button (Explicitly requested so user never gets stuck!)
                    OutlinedButton(
                        onClick = onClose,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.5.dp, Color(0xFF94A3B8)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color(0xFFF8FAFC),
                            contentColor = TextPrimary
                        ),
                        contentPadding = PaddingValues(vertical = 14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("update_dialog_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = null,
                            tint = Color(0xFF475569),
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "बंद करें (बाद में)" else "Close (Later)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UpdateBenefitRow(
    icon: ImageVector,
    text: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(AgriGreenContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = AgriGreenPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp
        )
    }
}

@Composable
private fun AppUpdateProgressBanner(
    isHindi: Boolean,
    progressPercent: Int,
    onDismiss: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 6.dp,
        border = BorderStroke(1.dp, AgriGreenPrimary.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("app_update_progress_banner")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Download,
                        contentDescription = null,
                        tint = AgriGreenPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isHindi) {
                            "नया अपडेट डाउनलोड हो रहा है... $progressPercent%"
                        } else {
                            "Downloading update... $progressPercent%"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary
                    )
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("update_progress_close_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = if (isHindi) "छिपाएं" else "Hide",
                        tint = TextSecondary
                    )
                }
            }
            LinearProgressIndicator(
                progress = { (progressPercent / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = AgriGreenPrimary,
                trackColor = AgriGreenContainer
            )
        }
    }
}

@Composable
private fun AppUpdateReadyBanner(
    isHindi: Boolean,
    onRestartAndInstall: () -> Unit,
    onClose: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        shadowElevation = 8.dp,
        border = BorderStroke(1.5.dp, PaidGreen),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("app_update_ready_banner")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = PaidGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isHindi) {
                            "नया अपडेट डाउनलोड हो गया है!"
                        } else {
                            "Update downloaded and ready!"
                        },
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                }
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("update_ready_top_close_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = if (isHindi) "बंद करें" else "Close",
                        tint = TextSecondary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onClose,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFF94A3B8)),
                    modifier = Modifier
                        .weight(0.42f)
                        .height(48.dp)
                        .testTag("update_ready_close_btn")
                ) {
                    Text(
                        text = if (isHindi) "बंद करें" else "Close",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        textAlign = TextAlign.Center
                    )
                }
                Button(
                    onClick = onRestartAndInstall,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RoyalOrange,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(0.58f)
                        .height(48.dp)
                        .testTag("update_ready_restart_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isHindi) "इंस्टॉल करें" else "Restart & Install",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
