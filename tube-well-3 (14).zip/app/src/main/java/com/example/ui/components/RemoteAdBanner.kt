package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.ViewGroup
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.DigitalBahiKhataApplication
import com.example.data.remoteconfig.AdSlotConfig
import com.example.data.remoteconfig.AppOpenAdManager
import com.example.data.remoteconfig.RemoteConfigService
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import kotlinx.coroutines.flow.first

/**
 * Persistent Google AdMob Banner that stays alive across screen/tab navigation.
 *
 * AdMob Policy & Revenue Optimization:
 * 1. PERSISTENCE: Reuses the single AdView instance across tabs (Home, Customers, Reports, History)
 *    so Google AdMob can measure continuous view time without resetting or spamming reload requests.
 * 2. GOOGLE-MANAGED 1-MINUTE REFRESH: Does NOT use custom manual refresh loops in app code.
 *    Relies exclusively on Google AdMob's 1-minute auto-refresh configured in the AdMob Console.
 *    Keeps the AdView mounted in the window hierarchy so Google's internal refresh scheduler functions cleanly.
 * 3. ATTRIBUTION: Displays clear "विज्ञापन • Ad" label compliant with Google Publisher Policies.
 * 4. NO OVERLAP: Anchored inside Scaffold bottomBar so it never covers clickable interactive elements.
 * 5. STRICT LIFECYCLE MANAGEMENT: Pauses ad when app is backgrounded (ON_PAUSE), resumes when app is foregrounded (ON_RESUME),
 *    and destroys when finished (ON_DESTROY) to strictly follow AdMob background policy.
 */
@Composable
fun PersistentBottomAdBanner(
    currentScreen: String,
    modifier: Modifier = Modifier,
    isSuppressed: Boolean = false
) {
    val configs by RemoteConfigService.configsFlow.collectAsState()
    val isAdFree by RemoteConfigService.isAdFreeUser.collectAsState()
    val isAppOpenAdShowing by AppOpenAdManager.isAppOpenAdShowing.collectAsState()

    val screenUpper = currentScreen.uppercase()
    val config = (configs[screenUpper]
        ?: if (screenUpper == "REPORTS") configs["HISTORY"]
        else if (screenUpper == "HISTORY") configs["REPORTS"]
        else null)

    // Check if this screen is enabled by remote config
    val isScreenEnabled = config?.isEnabled ?: true
    val isAllowedToShow = !isAdFree && isScreenEnabled

    if (isSuppressed || !isAllowedToShow) {
        return
    }

    var isAdLoaded by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Retain the single AdView instance for the lifecycle of the MainContainer
    val adView = remember {
        try {
            val adContext = context.findActivity() ?: context
            AdView(adContext).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setAdSize(AdSize.BANNER)
                val targetUnitId = config?.adUnitId?.takeIf { it.isNotBlank() && it.startsWith("ca-app-pub-") }
                    ?: "ca-app-pub-8640508231791309/4269694631"
                adUnitId = targetUnitId
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        val wasLoaded = isAdLoaded
                        isAdLoaded = true
                        if (!wasLoaded || width == 0 || height == 0) {
                            post {
                                if (isAttachedToWindow) {
                                    requestLayout()
                                }
                            }
                        }
                        android.util.Log.d("RemoteAdBanner", "Bottom banner refreshed/loaded successfully for $adUnitId")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                        android.util.Log.d("RemoteAdBanner", "Bottom banner impression recorded for $adUnitId")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        super.onAdFailedToLoad(error)
                        android.util.Log.w("RemoteAdBanner", "Bottom banner load error: ${error.message} (code ${error.code}) for unit $adUnitId")
                        isAdLoaded = false
                    }
                }
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        } catch (t: Throwable) {
            null
        }
    }

    // Load initial ad request ONCE after MobileAds SDK has finished initializing.
    // All subsequent refreshes are controlled natively by Google AdMob at the 1-minute interval.
    LaunchedEffect(adView) {
        if (adView != null) {
            try {
                DigitalBahiKhataApplication.isMobileAdsInitializedFlow.first { it }
                adView.loadAd(AdRequest.Builder().build())
            } catch (t: Throwable) {
                android.util.Log.e("RemoteAdBanner", "Error initiating initial banner load", t)
            }
        }
    }

    // Google AdMob Compliance: Pause refresh when app is in background or AppOpen ad is displayed
    DisposableEffect(lifecycleOwner, adView, isAppOpenAdShowing) {
        if (adView == null) return@DisposableEffect onDispose {}

        try {
            if (isAppOpenAdShowing) adView.pause() else adView.resume()
        } catch (_: Throwable) {}

        val observer = LifecycleEventObserver { _, event ->
            try {
                when (event) {
                    Lifecycle.Event.ON_RESUME -> if (!isAppOpenAdShowing) adView.resume()
                    Lifecycle.Event.ON_PAUSE -> adView.pause()
                    else -> {}
                }
            } catch (_: Throwable) {}
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Properly destroy AdView when this composable leaves composition (prevents WebView/GPU leaks)
    DisposableEffect(adView) {
        onDispose {
            try {
                adView?.pause()
                (adView?.parent as? ViewGroup)?.removeView(adView)
                adView?.destroy()
            } catch (_: Throwable) {}
        }
    }

    if (adView == null) {
        return
    }

    val showChrome = isAdLoaded && !isAppOpenAdShowing

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(if (showChrome) Color(0xFFF8FAFC) else Color.Transparent)
            .padding(
                horizontal = if (showChrome) 8.dp else 0.dp,
                vertical = if (showChrome) 3.dp else 0.dp
            )
            .testTag("persistent_bottom_ad_banner"),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = if (showChrome) Color.White else Color.Transparent,
            shape = RoundedCornerShape(8.dp),
            shadowElevation = if (showChrome) 1.dp else 0.dp,
            border = if (showChrome) BorderStroke(1.dp, Color(0xFFE2E8F0)) else null
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(
                    horizontal = if (showChrome) 4.dp else 0.dp,
                    vertical = if (showChrome) 2.dp else 0.dp
                )
            ) {
                if (showChrome) {
                    Text(
                        text = "विज्ञापन • Ad",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(bottom = 1.dp)
                    )
                }

                // Single persistent AndroidView — never reparented across branches
                AndroidView(
                    factory = {
                        (adView.parent as? ViewGroup)?.removeView(adView)
                        adView
                    },
                    update = { view ->
                        val desiredVisibility = if (showChrome) android.view.View.VISIBLE else android.view.View.INVISIBLE
                        if (view.visibility != desiredVisibility) {
                            view.visibility = desiredVisibility
                        }
                    },
                    modifier = if (showChrome) {
                        Modifier.widthIn(min = 320.dp).heightIn(min = 50.dp)
                    } else {
                        Modifier.size(1.dp)
                    }
                )
            }
        }
    }
}

/**
 * High-eCPM Medium Rectangle (300x250) Ad Banner shown exclusively during active Live Running Sessions.
 *
 * Appears directly in the empty space below the Live Timer on the Home Screen.
 * Provides ~3x higher eCPM compared to standard 320x50 banners while maintaining 100% Google AdMob compliance:
 * - Proper separation from the "सत्र समाप्त करें" (Stop) action button to avoid accidental clicks
 * - Clear discreet "विज्ञापन • Ad" attribution tag
 * - Paused on lifecycle pause, resumed on resume
 * - AdMob-driven 1-minute auto-refresh without custom app reload loops
 * - Automatically hidden when disabled via remote config or premium user
 */
@Composable
fun LiveSessionMediumRectangleAd(
    modifier: Modifier = Modifier
) {
    val configs by RemoteConfigService.configsFlow.collectAsState()
    val isAdFree by RemoteConfigService.isAdFreeUser.collectAsState()
    val isAppOpenAdShowing by AppOpenAdManager.isAppOpenAdShowing.collectAsState()

    val config = configs["LIVE_SESSION"]
    val isScreenEnabled = config?.isEnabled ?: true
    val isAllowedToShow = !isAdFree && isScreenEnabled

    if (!isAllowedToShow) {
        return
    }

    var isAdLoaded by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val adView = remember {
        try {
            val adContext = context.findActivity() ?: context
            AdView(adContext).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setAdSize(AdSize.MEDIUM_RECTANGLE)
                val targetUnitId = config?.adUnitId?.takeIf { it.isNotBlank() && it.startsWith("ca-app-pub-") }
                    ?: "ca-app-pub-8640508231791309/2848801758"
                adUnitId = targetUnitId
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        val wasLoaded = isAdLoaded
                        isAdLoaded = true
                        if (!wasLoaded || width == 0 || height == 0) {
                            post {
                                if (isAttachedToWindow) {
                                    requestLayout()
                                }
                            }
                        }
                        android.util.Log.d("RemoteAdBanner", "Medium rectangle loaded/refreshed for unit $adUnitId")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                        android.util.Log.d("RemoteAdBanner", "Medium rectangle impression recorded for unit $adUnitId")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        super.onAdFailedToLoad(error)
                        android.util.Log.w("RemoteAdBanner", "Medium rectangle load error: ${error.message} (code ${error.code}) for unit $adUnitId")
                        isAdLoaded = false
                    }
                }
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        } catch (t: Throwable) {
            null
        }
    }

    // Initial load ONCE after MobileAds SDK has initialized. AdMob handles subsequent 1-minute refreshes.
    LaunchedEffect(adView) {
        if (adView != null) {
            try {
                DigitalBahiKhataApplication.isMobileAdsInitializedFlow.first { it }
                adView.loadAd(AdRequest.Builder().build())
            } catch (t: Throwable) {
                android.util.Log.e("RemoteAdBanner", "Error initiating medium rectangle load", t)
            }
        }
    }

    // Safely pause on background, resume on foreground
    DisposableEffect(lifecycleOwner, adView, isAppOpenAdShowing) {
        if (adView == null) return@DisposableEffect onDispose {}

        try {
            if (isAppOpenAdShowing) adView.pause() else adView.resume()
        } catch (_: Throwable) {}

        val observer = LifecycleEventObserver { _, event ->
            try {
                when (event) {
                    Lifecycle.Event.ON_RESUME -> if (!isAppOpenAdShowing) adView.resume()
                    Lifecycle.Event.ON_PAUSE -> adView.pause()
                    else -> {}
                }
            } catch (_: Throwable) {}
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    DisposableEffect(adView) {
        onDispose {
            try {
                adView?.pause()
                (adView?.parent as? ViewGroup)?.removeView(adView)
                adView?.destroy()
            } catch (_: Throwable) {}
        }
    }

    if (adView == null) {
        return
    }

    val showChrome = isAdLoaded && !isAppOpenAdShowing

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("live_session_medium_rectangle_ad"),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = if (showChrome) Color.White else Color.Transparent,
            shape = RoundedCornerShape(16.dp),
            shadowElevation = if (showChrome) 2.dp else 0.dp,
            border = if (showChrome) BorderStroke(1.dp, Color(0xFFE2E8F0)) else null
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(if (showChrome) 8.dp else 0.dp)
            ) {
                if (showChrome) {
                    Text(
                        text = "विज्ञापन • Ad",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }

                AndroidView(
                    factory = {
                        (adView.parent as? ViewGroup)?.removeView(adView)
                        adView
                    },
                    update = { view ->
                        val desiredVisibility = if (showChrome) android.view.View.VISIBLE else android.view.View.INVISIBLE
                        if (view.visibility != desiredVisibility) {
                            view.visibility = desiredVisibility
                        }
                    },
                    modifier = if (showChrome) Modifier.width(300.dp).height(250.dp) else Modifier.size(1.dp)
                )
            }
        }
    }
}

/**
 * Dynamic Remote-Controlled AdMob Banner Composable.
 * 
 * Automatically responds to:
 * 1. Admin toggles (ON / OFF) via RemoteConfigService / Supabase
 * 2. User Premium status (Ad-Free users never see ads)
 * 3. Dynamic Ad Sizes (BANNER, LARGE_BANNER, MEDIUM_RECTANGLE)
 * 4. AdMob 1-minute native auto-refresh support
 * 5. Lifecycle pause/resume compliance
 */
@Composable
fun RemoteAdBanner(
    screenName: String,
    modifier: Modifier = Modifier
) {
    val configs by RemoteConfigService.configsFlow.collectAsState()
    val isAdFree by RemoteConfigService.isAdFreeUser.collectAsState()
    val isAppOpenAdShowing by AppOpenAdManager.isAppOpenAdShowing.collectAsState()

    if (isAdFree) {
        return
    }

    val upperScreen = screenName.uppercase()
    val config = (configs[upperScreen]
        ?: if (upperScreen == "REPORTS") configs["HISTORY"]
        else if (upperScreen == "HISTORY") configs["REPORTS"]
        else null)
        ?: return
    if (!config.isEnabled) {
        return
    }

    var isAdLoaded by remember(config.adSize, config.adUnitId) { mutableStateOf(false) }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val targetAdSize = when (config.adSize.uppercase()) {
        "LARGE_BANNER" -> AdSize.LARGE_BANNER
        "MEDIUM_RECTANGLE" -> AdSize.MEDIUM_RECTANGLE
        else -> AdSize.BANNER
    }

    val adView = remember(config.adSize, config.adUnitId) {
        try {
            val adContext = context.findActivity() ?: context
            AdView(adContext).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setAdSize(targetAdSize)
                adUnitId = config.adUnitId.ifBlank { AdSlotConfig.GOOGLE_TEST_BANNER_ID }
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        val wasLoaded = isAdLoaded
                        isAdLoaded = true
                        if (!wasLoaded || width == 0 || height == 0) {
                            post {
                                if (isAttachedToWindow) {
                                    requestLayout()
                                }
                            }
                        }
                        android.util.Log.d("RemoteAdBanner", "Remote ad loaded/refreshed for screen $screenName, unit $adUnitId")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                        android.util.Log.d("RemoteAdBanner", "Remote ad impression recorded for screen $screenName, unit $adUnitId")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        super.onAdFailedToLoad(error)
                        android.util.Log.w("RemoteAdBanner", "Remote ad load error on $screenName: ${error.message} (code ${error.code}) for unit $adUnitId")
                        isAdLoaded = false
                    }
                }
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        } catch (t: Throwable) {
            null
        }
    }

    // Load initial ad request ONCE after MobileAds SDK has initialized. Subsequent refreshes managed by AdMob.
    LaunchedEffect(adView) {
        if (adView != null) {
            try {
                DigitalBahiKhataApplication.isMobileAdsInitializedFlow.first { it }
                adView.loadAd(AdRequest.Builder().build())
            } catch (t: Throwable) {
                android.util.Log.e("RemoteAdBanner", "Error initiating load for $screenName", t)
            }
        }
    }

    // Observe lifecycle for pause/resume
    DisposableEffect(lifecycleOwner, adView, isAppOpenAdShowing) {
        if (adView == null) return@DisposableEffect onDispose {}

        try {
            if (isAppOpenAdShowing) adView.pause() else adView.resume()
        } catch (_: Throwable) {}

        val observer = LifecycleEventObserver { _, event ->
            try {
                when (event) {
                    Lifecycle.Event.ON_RESUME -> if (!isAppOpenAdShowing) adView.resume()
                    Lifecycle.Event.ON_PAUSE -> adView.pause()
                    else -> {}
                }
            } catch (_: Throwable) {}
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    DisposableEffect(adView) {
        onDispose {
            try {
                adView?.pause()
                (adView?.parent as? ViewGroup)?.removeView(adView)
                adView?.destroy()
            } catch (_: Throwable) {}
        }
    }

    if (adView == null) {
        return
    }

    val showChrome = isAdLoaded && !isAppOpenAdShowing

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(
                horizontal = if (showChrome) 8.dp else 0.dp,
                vertical = if (showChrome) 6.dp else 0.dp
            )
            .testTag("remote_ad_banner_${screenName.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = if (showChrome) Color(0xFFF8FAFC) else Color.Transparent,
            shape = RoundedCornerShape(12.dp),
            tonalElevation = if (showChrome) 1.dp else 0.dp,
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(
                    vertical = if (showChrome) 4.dp else 0.dp,
                    horizontal = if (showChrome) 4.dp else 0.dp
                )
            ) {
                if (showChrome) {
                    Text(
                        text = "विज्ञापन • Ad",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }

                val minW = when (targetAdSize) {
                    AdSize.MEDIUM_RECTANGLE -> 300.dp
                    else -> 320.dp
                }
                val minH = when (targetAdSize) {
                    AdSize.MEDIUM_RECTANGLE -> 250.dp
                    AdSize.LARGE_BANNER -> 100.dp
                    else -> 50.dp
                }
                AndroidView(
                    factory = {
                        (adView.parent as? ViewGroup)?.removeView(adView)
                        adView
                    },
                    update = { view ->
                        val desiredVisibility = if (showChrome) android.view.View.VISIBLE else android.view.View.INVISIBLE
                        if (view.visibility != desiredVisibility) {
                            view.visibility = desiredVisibility
                        }
                    },
                    modifier = if (showChrome) {
                        Modifier.widthIn(min = minW).heightIn(min = minH).align(Alignment.CenterHorizontally)
                    } else {
                        Modifier.size(1.dp)
                    }
                )
            }
        }
    }
}
