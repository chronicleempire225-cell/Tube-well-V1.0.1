package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.data.payment.GooglePlayBillingManager
import com.example.data.remoteconfig.AppOpenAdManager
import com.example.data.util.EmailVerificationManager
import com.example.data.util.InAppUpdateManager
import com.example.ui.screens.*
import com.example.ui.theme.DigitalBahiKhataTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.BahiKhataViewModel
import com.example.ui.viewmodel.MainTab

class MainActivity : ComponentActivity() {
    private val viewModel: BahiKhataViewModel by viewModels()

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    private val inAppUpdateLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        InAppUpdateManager.onUpdateFlowResult(result.resultCode, this)
    }

    private val startupHandler = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Maintain reference to foreground activity early
        AppOpenAdManager.currentActivity = this

        // Handle incoming deep link if launched via email confirmation
        try {
            handleDeepLink(intent)
        } catch (t: Throwable) {
            android.util.Log.w("MainActivity", "Deep link handling failed safely: ${t.message}")
        }

        // Render Compose UI IMMEDIATELY so cold start / Streaming Emulator shows Frame 1 with zero blocking
        setContent {
            val fontScale by viewModel.fontScale.collectAsState()
            val currentLanguage by viewModel.currentLanguage.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()

            androidx.compose.runtime.LaunchedEffect(currentScreen) {
                if (currentScreen == AppScreen.MAIN_CONTAINER || currentScreen == AppScreen.AUTH_CHOICE) {
                    requestNotificationPermissionIfNeeded()
                }
            }

            DigitalBahiKhataTheme(fontScale = fontScale) {
                key(currentLanguage) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        AppNavigation(viewModel = viewModel)
                    }
                }
            }
        }

        // Stagger heavy GMS / Play Store SDK initializations safely AFTER first frame renders
        window?.decorView?.post {
            if (isFinishing || isDestroyed) return@post

            // 0. Initialize Google Mobile Ads cleanly after Frame 1 settles
            startupHandler.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                DigitalBahiKhataApplication.initializeMobileAdsOnce(applicationContext)
            }, 350L)

            // 1. Initialize Google Play Billing client safely (only when Play Store is present)
            startupHandler.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                try {
                    GooglePlayBillingManager.init(this)
                } catch (t: Throwable) {
                    android.util.Log.w("MainActivity", "GooglePlayBillingManager init failed safely: ${t.message}")
                }
            }, 700L)

            // 2. Initialize UMP Privacy Consent safely
            startupHandler.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                initializeConsentAndAdsSafely()
            }, 1100L)

            // 3. Initialize Google Play Flexible In-App Update check cleanly after splash/UI is stable
            startupHandler.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                try {
                    InAppUpdateManager.init(this, inAppUpdateLauncher)
                } catch (t: Throwable) {
                    android.util.Log.w("MainActivity", "InAppUpdateManager init failed safely: ${t.message}")
                }
            }, 2500L)
        }
    }

    private var hasRequestedNotificationPermissionThisSession = false

    private fun requestNotificationPermissionIfNeeded() {
        if (hasRequestedNotificationPermissionThisSession || isFinishing || isDestroyed) return
        hasRequestedNotificationPermissionThisSession = true
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        } catch (t: Throwable) {
            android.util.Log.w("MainActivity", "Notification permission request skipped safely: ${t.message}")
        }
    }

    private fun initializeConsentAndAdsSafely() {
        try {
            val consentParams = com.google.android.ump.ConsentRequestParameters.Builder().build()
            val consentInfo = com.google.android.ump.UserMessagingPlatform.getConsentInformation(this)
            consentInfo.requestConsentInfoUpdate(
                this,
                consentParams,
                {
                    if (isFinishing || isDestroyed) return@requestConsentInfoUpdate
                    try {
                        com.google.android.ump.UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) { formError ->
                            if (formError != null) {
                                android.util.Log.w("MainActivity", "UMP Consent form error: ${formError.message}")
                            }
                            try {
                                if (consentInfo.canRequestAds()) {
                                    DigitalBahiKhataApplication.initializeMobileAdsOnce(applicationContext)
                                    AppOpenAdManager.loadAd(applicationContext)
                                }
                            } catch (_: Throwable) {}
                        }
                    } catch (t: Throwable) {
                        android.util.Log.w("MainActivity", "UMP form show failed safely: ${t.message}")
                        DigitalBahiKhataApplication.initializeMobileAdsOnce(applicationContext)
                    }
                },
                { requestConsentError ->
                    android.util.Log.w("MainActivity", "UMP Consent update error: ${requestConsentError.message}")
                    try {
                        DigitalBahiKhataApplication.initializeMobileAdsOnce(applicationContext)
                        AppOpenAdManager.loadAd(applicationContext)
                    } catch (_: Throwable) {}
                }
            )
            if (consentInfo.canRequestAds()) {
                DigitalBahiKhataApplication.initializeMobileAdsOnce(applicationContext)
            }
        } catch (_: Throwable) {
            try {
                DigitalBahiKhataApplication.initializeMobileAdsOnce(applicationContext)
            } catch (_: Throwable) {}
        }
    }

    override fun onResume() {
        super.onResume()
        AppOpenAdManager.currentActivity = this
        // Safely synchronize foreground service only when app is genuinely in the foreground
        try {
            com.example.data.service.LiveTimerManager.syncServiceIfRunning(this)
        } catch (t: Throwable) {
            android.util.Log.w("MainActivity", "LiveTimerManager foreground sync failed safely: ${t.message}")
        }

        AppOpenAdManager.onHostActivityResumed()

        // Show deferred App Open Ad only after splash has finished
        try {
            if (viewModel.currentScreen.value != AppScreen.SPLASH) {
                AppOpenAdManager.showPendingAdIfReady(this)
            }
        } catch (_: Throwable) {}

        // Surface any flexible update that finished downloading while app was in background
        try {
            InAppUpdateManager.checkOnResume(this)
        } catch (t: Throwable) {
            android.util.Log.w("MainActivity", "InAppUpdateManager onResume check failed safely: ${t.message}")
        }
    }

    override fun onDestroy() {
        startupHandler.removeCallbacksAndMessages(null)
        try {
            InAppUpdateManager.cleanup(inAppUpdateLauncher)
        } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDeepLink(intent)
    }

    private fun handleDeepLink(intent: android.content.Intent?) {
        val data = intent?.data ?: return
        android.util.Log.d("MainActivity", "Deep link received: $data")
        if (data.scheme == "tubewell") {
            val queryEmail = data.getQueryParameter("email")?.trim()?.lowercase() ?: ""
            val profile = viewModel.profile.value
            val targetEmail = queryEmail.ifBlank {
                profile?.email?.ifBlank { null } ?: EmailVerificationManager.getLastOtpEmail(this)
            }
            if (targetEmail.isNotBlank()) {
                viewModel.updateOwnerEmail(targetEmail, true)
            }
            EmailVerificationManager.notifyEmailConfirmedViaDeepLink(targetEmail)
            android.widget.Toast.makeText(this, "🎉 बधाई हो! ईमेल सफलतापूर्वक सत्यापित हो गया!", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
fun AppNavigation(viewModel: BahiKhataViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val selectedCustomerId by viewModel.selectedCustomerId.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()

    // Determine if back press should navigate within app or allow system back to exit/minimize
    val shouldInterceptBack = when (currentScreen) {
        AppScreen.MAIN_CONTAINER -> (selectedCustomerId != null || currentTab != MainTab.HOME)
        AppScreen.AUTH_CHOICE -> true
        AppScreen.SIGN_UP, AppScreen.LOGIN, AppScreen.FORGOT_PASSWORD -> true
        else -> false
    }

    // Handle back button for screens
    BackHandler(enabled = shouldInterceptBack) {
        when (currentScreen) {
            AppScreen.MAIN_CONTAINER -> {
                if (selectedCustomerId != null) {
                    viewModel.clearSelectedCustomer()
                } else if (currentTab != MainTab.HOME) {
                    viewModel.setTab(MainTab.HOME)
                }
            }
            AppScreen.AUTH_CHOICE -> viewModel.navigateTo(AppScreen.LANGUAGE_SELECT)
            AppScreen.SIGN_UP, AppScreen.LOGIN -> viewModel.navigateTo(AppScreen.AUTH_CHOICE)
            AppScreen.FORGOT_PASSWORD -> viewModel.navigateTo(AppScreen.LOGIN)
            else -> {}
        }
    }

    Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
        when (screen) {
            AppScreen.SPLASH -> SplashScreen(viewModel = viewModel)
            AppScreen.LANGUAGE_SELECT -> LanguageSelectScreen(viewModel = viewModel)
            AppScreen.AUTH_CHOICE -> AuthChoiceScreen(viewModel = viewModel)
            AppScreen.SIGN_UP -> SignUpScreen(viewModel = viewModel)
            AppScreen.LOGIN -> LoginScreen(viewModel = viewModel)
            AppScreen.FORGOT_PASSWORD -> ForgotPasswordScreen(viewModel = viewModel)
            AppScreen.MAIN_CONTAINER -> MainContainerScreen(viewModel = viewModel)
        }
    }
}
