package com.example

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.data.remoteconfig.AppOpenAdManager
import com.example.data.remoteconfig.RemoteConfigService
import com.example.data.remoteconfig.RewardedAdManager
import com.example.data.service.BackgroundNotificationScheduler
import com.example.data.service.DuePaymentReminderManager
import com.example.data.service.LiveTimerManager
import com.google.android.gms.ads.MobileAds

import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Main Application class for Digital Bahi Khata.
 * Keeps Application.onCreate() ultra-fast on the Main Thread so cold start renders
 * immediately without ANRs or freezes on emulators and low-RAM devices.
 */
class DigitalBahiKhataApplication : Application(), Application.ActivityLifecycleCallbacks {

    companion object {
        private const val TAG = "BahiKhataApp"
        private val isMobileAdsInitStarted = java.util.concurrent.atomic.AtomicBoolean(false)
        private val _isMobileAdsInitializedFlow = kotlinx.coroutines.flow.MutableStateFlow(false)
        val isMobileAdsInitializedFlow: kotlinx.coroutines.flow.StateFlow<Boolean> = _isMobileAdsInitializedFlow
        @Volatile
        var isMobileAdsInitialized: Boolean = false
            private set
        private val mainHandler = Handler(Looper.getMainLooper())
        private val appInitScope = CoroutineScope(
            SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, t ->
                Log.w(TAG, "Background Application init error safely caught: ${t.message}")
            }
        )

        fun initializeMobileAdsOnce(context: android.content.Context) {
            if (!isMobileAdsInitStarted.compareAndSet(false, true)) return
            val appContext = context.applicationContext
            try {
                val reqConfig = com.google.android.gms.ads.RequestConfiguration.Builder()
                    .setTestDeviceIds(listOf(com.google.android.gms.ads.AdRequest.DEVICE_ID_EMULATOR))
                    .build()
                MobileAds.setRequestConfiguration(reqConfig)
                MobileAds.initialize(appContext) { initStatus ->
                    isMobileAdsInitialized = true
                    _isMobileAdsInitializedFlow.value = true
                    Log.d(TAG, "Google Mobile Ads SDK initialized successfully: $initStatus")
                    // With OPTIMIZE_INITIALIZATION=true this callback can run on a background thread.
                    // Always hop to the Main Thread before calling AppOpenAd.load / RewardedAd.load!
                    mainHandler.post {
                        try {
                            AppOpenAdManager.loadAd(appContext)
                        } catch (t: Throwable) {
                            Log.w(TAG, "AppOpenAd preload error: ${t.message}")
                        }
                    }
                }
            } catch (t: Throwable) {
                isMobileAdsInitStarted.set(false)
                Log.w(TAG, "MobileAds initialization error: ${t.message}")
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "DigitalBahiKhataApplication initialized.")

        registerActivityLifecycleCallbacks(this)

        val appContext = applicationContext

        // Offload disk I/O, WorkManager DB init, AlarmManager setup, and RemoteConfig init off Main Thread
        appInitScope.launch {
            try {
                // Ensure WebView Code Cache directories exist so Chromium doesn't fail with opendir errors on first run
                try {
                    val codeCacheDir = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache")
                    java.io.File(codeCacheDir, "js").mkdirs()
                    java.io.File(codeCacheDir, "wasm").mkdirs()
                } catch (_: Throwable) {}

                // 1. Initialize notification channels
                try {
                    DuePaymentReminderManager.createNotificationChannel(appContext)
                } catch (t: Throwable) {
                    Log.w(TAG, "Notification channel init error: ${t.message}")
                }

                // 2. Restore live timer state from disk WITHOUT calling startForegroundService() from Application.onCreate()
                try {
                    LiveTimerManager.init(appContext, notifyService = false)
                } catch (t: Throwable) {
                    Log.w(TAG, "LiveTimerManager init error: ${t.message}")
                }

                // 3. Schedule WorkManager Periodic Worker & Alarms on IO thread (never block Main Thread)
                try {
                    BackgroundNotificationScheduler.schedulePeriodicWork(appContext)
                } catch (t: Throwable) {
                    Log.w(TAG, "BackgroundNotificationScheduler init error: ${t.message}")
                }

                // 4. Initialize Dynamic Remote Config & Feature Flags
                try {
                    RemoteConfigService.init(appContext)
                } catch (t: Throwable) {
                    Log.w(TAG, "RemoteConfigService init error: ${t.message}")
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Failed during background Application initialization: ${t.message}", t)
            }
        }

        // Trigger MobileAds SDK safely after Frame 1 renders (MainActivity invokes it at +350ms post-frame;
        // this 1200ms delayed fallback is idempotent via AtomicBoolean for non-UI cold starts).
        mainHandler.postDelayed({
            initializeMobileAdsOnce(appContext)
        }, 1200L)
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        AppOpenAdManager.currentActivity = activity
    }

    override fun onActivityStarted(activity: Activity) {
        AppOpenAdManager.currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        AppOpenAdManager.currentActivity = activity
    }

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {}

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {
        if (AppOpenAdManager.currentActivity == activity) {
            AppOpenAdManager.currentActivity = null
        }
    }
}
