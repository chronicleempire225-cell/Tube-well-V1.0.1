-- ==============================================================================
-- 🗑️ KISAN TUBEWELL BAHI KHATA - SUPABASE DELETED RECORDS AUTO-CLEANUP MIGRATION
-- ==============================================================================
-- यह SQL स्क्रिप्ट Supabase डेटाबेस में `deleted_records` टेबल से 1 साल (365 दिन) 
-- पुराने टॉमबस्टोन रिकॉर्ड्स को ऑटोमैटिक हटाने के लिए फंक्शन और क्रॉन जॉब सेट करती है।
-- ==============================================================================

-- 1. 1 साल से पुराने डिलीटेड रिकॉर्ड्स को साफ करने का PostgreSQL फंक्शन
CREATE OR REPLACE FUNCTION public.cleanup_old_deleted_records()
RETURNS void AS $$
BEGIN
  DELETE FROM public.deleted_records
  WHERE deleted_at < (NOW() - INTERVAL '1 year');
  
  RAISE NOTICE 'Successfully purged deleted_records older than 1 year.';
END;
$$ LANGUAGE plpgsql;

-- 2. RLS (Row Level Security) पॉलिसी सुनिश्चित करें ताकि ऐप या एडमिन इसे एक्सेक्यूटे कर सके
ALTER TABLE IF EXISTS public.deleted_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow app access to deleted_records" ON public.deleted_records;
CREATE POLICY "Allow app access to deleted_records" ON public.deleted_records 
    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- 3. pg_cron एक्सटेंशन सक्षम करें (यदि Supabase प्रोजेक्ट में उपलब्ध है)
-- नोट: आप इसे Supabase Dashboard > Database > Extensions में जाकर भी 'pg_cron' सर्च करके Enable कर सकते हैं।
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- 4. क्रॉन जॉब शेड्यूल करें: हर रविवार रात 2:00 बजे यह ऑटोमैटिक 1 साल पुराना कचरा साफ कर देगा
-- (यदि pg_cron सक्षम नहीं है, तो आप इस ब्लॉक को छोड़ सकते हैं और सीधे फंक्शन का उपयोग कर सकते हैं)
DO $$
BEGIN
  -- यदि पहले से जॉब है तो हटा दें ताकि डुप्लीकेट न हो
  PERFORM cron.unschedule('weekly-deleted-records-cleanup');
  
  -- हर रविवार रात 2:00 बजे चलने के लिए शेड्यूल करें
  PERFORM cron.schedule(
    'weekly-deleted-records-cleanup',
    '0 2 * * 0',
    'SELECT public.cleanup_old_deleted_records();'
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'pg_cron schedule skipped or not supported on this tier: %', SQLERRM;
END $$;
