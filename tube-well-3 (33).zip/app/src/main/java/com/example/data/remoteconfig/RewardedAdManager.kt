package com.example.data.remoteconfig

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Rewarded Video Ad Manager.
 * 
 * Preloads AdMob Rewarded Ads in background so users experience zero lag
 * when unlocking the 24-hour feature pass.
 * Automatically reloads a fresh ad whenever an ad is displayed or closed.
 */
object RewardedAdManager {
    private const val TAG = "RewardedAdManager"
    const val DEFAULT_LIVE_REWARDED_ID = "ca-app-pub-8640508231791309/8839495033"

    private var rewardedAd: RewardedAd? = null
    private var isAdLoading = false
    private var loadingStartTime = 0L

    private val _isReadyFlow = MutableStateFlow(false)
    val isReadyFlow: StateFlow<Boolean> = _isReadyFlow.asStateFlow()

    var lastErrorMessage: String = ""
        private set
    var lastErrorCode: Int = -1
        private set

    fun init(context: Context) {
        preload(context)
    }

    /**
     * Preloads a rewarded ad using the ad unit ID configured in RemoteConfigService or fallback test ID.
     */
    fun preload(context: Context, onResult: ((Boolean, String) -> Unit)? = null) {
        if (rewardedAd != null) {
            onResult?.invoke(true, "तैयार है")
            return
        }

        val now = System.currentTimeMillis()
        if (isAdLoading && (now - loadingStartTime < 15_000L)) {
            onResult?.invoke(false, "लोड हो रहा है...")
            return
        }

        isAdLoading = true
        loadingStartTime = now
        val config = RemoteConfigService.getConfigForScreen("REWARDED_FEATURE_UNLOCK")
        val rawUnitId = config?.adUnitId?.trim() ?: ""
        val adUnitId = if (rawUnitId.isNotBlank() && rawUnitId.startsWith("ca-app-pub-")) {
            rawUnitId
        } else {
            "ca-app-pub-8640508231791309/8839495033"
        }

        lastErrorMessage = "AdMob को अनुरोध भेजा जा रहा है ($adUnitId)..."
        Log.d(TAG, "Preloading Rewarded Ad with Unit ID: $adUnitId")

        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "Rewarded Ad loaded successfully for $adUnitId!")
                    rewardedAd = ad
                    isAdLoading = false
                    lastErrorMessage = "सफलतापूर्वक लोड हो गया"
                    lastErrorCode = 200
                    _isReadyFlow.value = true
                    onResult?.invoke(true, "सफलता")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    val errMsg = "कोड ${loadAdError.code}: ${loadAdError.message}"
                    Log.w(TAG, "Failed to load Rewarded Ad for $adUnitId: $errMsg")
                    rewardedAd = null
                    isAdLoading = false
                    lastErrorMessage = errMsg
                    lastErrorCode = loadAdError.code
                    _isReadyFlow.value = false
                    onResult?.invoke(false, errMsg)
                }
            }
        )
    }

    /**
     * Checks if a rewarded ad is currently cached and ready to show immediately.
     */
    fun isAdReady(): Boolean = rewardedAd != null

    /**
     * Displays the rewarded ad to the user.
     * If user watches for at least requiredSeconds (e.g. 7 or 8 seconds), the reward is granted
     * even if they dismiss earlier, or when AdMob issues the reward event.
     * Automatically requests preloading of the next ad upon dismissal.
     */
    fun showRewardedAd(
        activity: Activity,
        requiredSeconds: Int = 0,
        onUserEarnedReward: () -> Unit,
        onAdDismissed: () -> Unit = {},
        onAdFailed: (String) -> Unit = {}
    ) {
        val ad = rewardedAd
        if (ad == null) {
            preload(activity)
            onAdFailed("विज्ञापन अभी लोड हो रहा है, कृपया 2 सेकंड बाद पुनः प्रयास करें।")
            return
        }

        var rewardGranted = false
        var showStartTimeMs = 0L

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "Rewarded ad showed full screen.")
                showStartTimeMs = System.currentTimeMillis()
                rewardedAd = null
                _isReadyFlow.value = false
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.e(TAG, "Failed to show full screen ad: ${adError.message}")
                rewardedAd = null
                _isReadyFlow.value = false
                preload(activity)
                onAdFailed("विज्ञापन दिखाने में त्रुटि: ${adError.message}")
            }

            override fun onAdDismissedFullScreenContent() {
                val elapsedSeconds = if (showStartTimeMs > 0L) {
                    ((System.currentTimeMillis() - showStartTimeMs) / 1000L).toInt()
                } else 0

                Log.d(TAG, "Rewarded ad dismissed after $elapsedSeconds seconds. Reward granted status: $rewardGranted")

                // Per Google AdMob Publisher Policy:
                // Rewards must ONLY be granted when the official AdMob onUserEarnedRewardListener fires.
                // Dismissing the ad before completion does not grant reward.

                rewardedAd = null
                _isReadyFlow.value = false
                preload(activity)
                onAdDismissed()
            }
        }

        // Official Google AdMob Reward Callback - strictly follows Google Publisher Policy
        ad.show(activity) { rewardItem ->
            Log.d(TAG, "Google AdMob verified user earned reward: ${rewardItem.type}, amount: ${rewardItem.amount}")
            if (!rewardGranted) {
                rewardGranted = true
                onUserEarnedReward()
            }
        }
    }
}
