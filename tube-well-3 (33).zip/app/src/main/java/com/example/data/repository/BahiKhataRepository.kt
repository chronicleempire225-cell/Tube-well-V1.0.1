package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.db.*
import com.example.data.localization.AppLanguage
import com.example.data.supabase.SupabaseAuthService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf

class BahiKhataRepository(
    private val database: AppDatabase,
    private val context: Context
) {
    private val profileDao: ProfileDao = database.profileDao()
    private val customerDao: CustomerDao = database.customerDao()
    private val sessionDao: SessionDao = database.sessionDao()
    private val transactionDao: TransactionDao = database.transactionDao()

    private val prefs: SharedPreferences = context.getSharedPreferences("bahi_khata_prefs", Context.MODE_PRIVATE)

    private val _activeProfileId = MutableStateFlow(getActiveProfileIdFromPrefs())
    val activeProfileId = _activeProfileId.asStateFlow()

    private fun getActiveProfileIdFromPrefs(): String {
        val secured = com.example.data.security.SecurePreferencesManager.getSecureString(context, "bahi_khata_prefs", "active_profile_id", "")
        if (secured.isNotBlank()) return secured
        val legacy = prefs.getString("active_profile_id", "") ?: ""
        if (legacy.isNotBlank()) {
            com.example.data.security.SecurePreferencesManager.putSecureString(context, "bahi_khata_prefs", "active_profile_id", legacy)
        }
        return legacy
    }

    fun getActiveProfileId(): String {
        return _activeProfileId.value
    }

    fun setActiveProfileId(id: String) {
        com.example.data.security.SecurePreferencesManager.putSecureString(context, "bahi_khata_prefs", "active_profile_id", id)
        _activeProfileId.value = id
    }

    // Language Preference
    fun getSavedLanguage(): AppLanguage {
        val code = prefs.getString("app_language", AppLanguage.HINDI.code) ?: AppLanguage.HINDI.code
        return AppLanguage.values().firstOrNull { it.code == code } ?: AppLanguage.HINDI
    }

    fun setSavedLanguage(language: AppLanguage) {
        prefs.edit().putString("app_language", language.code).apply()
    }

    // Munshi Voice Assistant Active Language Preference
    fun getSavedMunshiLanguage(): com.example.data.gemini.MunshiLang {
        val code = prefs.getString("munshi_active_lang", com.example.data.gemini.MunshiLang.HINDI.code) ?: com.example.data.gemini.MunshiLang.HINDI.code
        return com.example.data.gemini.MunshiLang.values().firstOrNull { it.code == code } ?: com.example.data.gemini.MunshiLang.HINDI
    }

    fun setSavedMunshiLanguage(lang: com.example.data.gemini.MunshiLang) {
        prefs.edit().putString("munshi_active_lang", lang.code).apply()
    }

    // Font scale preference (0.85 to 1.35)
    fun getSavedFontScale(): Float {
        return prefs.getFloat("app_font_scale", 1.0f)
    }

    fun setSavedFontScale(scale: Float) {
        prefs.edit().putFloat("app_font_scale", scale).apply()
    }

    // First time onboarding check
    fun isFirstLaunch(): Boolean {
        return prefs.getBoolean("is_first_launch", true)
    }

    fun setFirstLaunchComplete() {
        prefs.edit().putBoolean("is_first_launch", false).apply()
    }

    // Gemini AI API Key preference (Farmer's custom key or Cloudflare proxy)
    fun getGeminiApiKey(): String {
        val secured = com.example.data.security.SecurePreferencesManager.getSecureString(context, "bahi_khata_prefs", "custom_gemini_api_key", "")
        if (secured.isNotBlank()) return secured.trim()
        val legacy = prefs.getString("custom_gemini_api_key", "")?.trim() ?: ""
        if (legacy.isNotBlank()) {
            com.example.data.security.SecurePreferencesManager.putSecureString(context, "bahi_khata_prefs", "custom_gemini_api_key", legacy)
        }
        return legacy
    }

    fun setGeminiApiKey(key: String) {
        val cleanKey = key.trim()
        com.example.data.security.SecurePreferencesManager.putSecureString(context, "bahi_khata_prefs", "custom_gemini_api_key", cleanKey)
    }

    fun getCloudflareProxyUrl(): String {
        val secured = com.example.data.security.SecurePreferencesManager.getSecureString(context, "bahi_khata_prefs", "cloudflare_proxy_url", "")
        if (secured.isNotBlank()) return secured.trim()
        val saved = prefs.getString("cloudflare_proxy_url", "")?.trim() ?: ""
        if (saved.isNotBlank()) return saved
        return com.example.data.gemini.GeminiMunshiService.masterCloudflareWorkerUrl
    }

    fun setCloudflareProxyUrl(url: String) {
        val clean = url.trim()
        com.example.data.security.SecurePreferencesManager.putSecureString(context, "bahi_khata_prefs", "cloudflare_proxy_url", clean)
    }

    // Munshi AI continuous learned memory / insights
    fun getMunshiLearnedMemory(): String {
        return prefs.getString("munshi_learned_memory", "") ?: ""
    }

    fun saveMunshiLearnedMemory(memory: String) {
        prefs.edit().putString("munshi_learned_memory", memory).apply()
    }

    // Munshi Learned Q&A Knowledge Base (Device-local caching of Gemini insights)
    fun saveLearnedQA(question: String, answer: String) {
        val qClean = question.trim().lowercase(java.util.Locale.ROOT)
        if (qClean.length < 4 || answer.isBlank()) return

        try {
            val existingJson = prefs.getString("munshi_learned_qa_json", "[]") ?: "[]"
            val array = org.json.JSONArray(existingJson)

            // Avoid exact duplicate questions
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                if (obj.optString("q") == qClean) {
                    obj.put("a", answer.trim())
                    obj.put("ts", System.currentTimeMillis())
                    prefs.edit().putString("munshi_learned_qa_json", array.toString()).apply()
                    return
                }
            }

            // Append new learned Q&A (keep last 50 high-value entries)
            val newObj = org.json.JSONObject().apply {
                put("q", qClean)
                put("a", answer.trim())
                put("ts", System.currentTimeMillis())
            }
            array.put(newObj)

            // Prune if exceeded 50
            val finalArray = org.json.JSONArray()
            val startIdx = (array.length() - 50).coerceAtLeast(0)
            for (i in startIdx until array.length()) {
                finalArray.put(array.get(i))
            }
            prefs.edit().putString("munshi_learned_qa_json", finalArray.toString()).apply()
        } catch (_: Exception) {}
    }

    fun findLearnedAnswer(query: String): String? {
        val qClean = query.trim().lowercase(java.util.Locale.ROOT)
        if (qClean.length < 4) return null

        try {
            val json = prefs.getString("munshi_learned_qa_json", "[]") ?: "[]"
            val array = org.json.JSONArray(json)
            val qWords = qClean.split(" ", "।", "?", "-", ",").filter { it.length > 2 }.toSet()
            if (qWords.isEmpty()) return null

            var bestAnswer: String? = null
            var bestScore = 0.0

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val storedQ = obj.optString("q")
                val storedWords = storedQ.split(" ", "।", "?", "-", ",").filter { it.length > 2 }.toSet()
                if (storedWords.isEmpty()) continue

                val intersection = qWords.intersect(storedWords).size
                val score = (intersection * 2.0) / (qWords.size + storedWords.size)
                if (score > 0.70 && score > bestScore) {
                    bestScore = score
                    bestAnswer = obj.optString("a")
                }
            }
            return bestAnswer
        } catch (_: Exception) {
            return null
        }
    }

    // Off-topic general trivia query limiter (24-Hour window: Allows up to 2 non-farming questions per day)
    fun getOffTopicCount(): Int {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val dateKey = "munshi_offtopic_date"
        val countKey = "munshi_offtopic_query_count"
        val savedDate = prefs.getString(dateKey, "")
        if (savedDate != today) {
            prefs.edit().putString(dateKey, today).putInt(countKey, 0).apply()
            return 0
        }
        return prefs.getInt(countKey, 0)
    }

    fun incrementOffTopicCount(): Int {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val dateKey = "munshi_offtopic_date"
        val countKey = "munshi_offtopic_query_count"
        val current = getOffTopicCount()
        val next = current + 1
        prefs.edit()
            .putString(dateKey, today)
            .putInt(countKey, next)
            .apply()
        return next
    }

    fun resetOffTopicCount() {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val dateKey = "munshi_offtopic_date"
        val countKey = "munshi_offtopic_query_count"
        prefs.edit().putString(dateKey, today).putInt(countKey, 0).apply()
    }

    // Daily Gemini API Quota: Maximum calls per account/device per day (Hard-limit: 5 calls to protect API Key)
    fun getGeminiDailyCallsCount(accountId: String = ""): Int {
        val cleanAccount = accountId.ifBlank { "default_account" }
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        
        // 1. Account-specific counter
        val dateKey = "gemini_calls_date_$cleanAccount"
        val countKey = "gemini_calls_count_$cleanAccount"
        val savedDate = prefs.getString(dateKey, "")
        val accountCount = if (savedDate != today) {
            prefs.edit().putString(dateKey, today).putInt(countKey, 0).apply()
            0
        } else {
            prefs.getInt(countKey, 0)
        }

        // 2. Device-global counter (prevents bypassing limit by switching local profiles on same phone)
        val devDateKey = "gemini_calls_date_device_global"
        val devCountKey = "gemini_calls_count_device_global"
        val savedDevDate = prefs.getString(devDateKey, "")
        val deviceCount = if (savedDevDate != today) {
            prefs.edit().putString(devDateKey, today).putInt(devCountKey, 0).apply()
            0
        } else {
            prefs.getInt(devCountKey, 0)
        }

        return maxOf(accountCount, deviceCount)
    }

    fun canMakeGeminiCallToday(accountId: String = "", dailyLimit: Int = 5): Boolean {
        val effectiveLimit = minOf(dailyLimit, 5)
        return getGeminiDailyCallsCount(accountId) < effectiveLimit
    }

    fun incrementGeminiDailyCallsCount(accountId: String = ""): Int {
        val cleanAccount = accountId.ifBlank { "default_account" }
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        
        val dateKey = "gemini_calls_date_$cleanAccount"
        val countKey = "gemini_calls_count_$cleanAccount"
        val curAcc = getGeminiDailyCallsCount(cleanAccount)
        val nextAcc = curAcc + 1

        val devDateKey = "gemini_calls_date_device_global"
        val devCountKey = "gemini_calls_count_device_global"
        val curDev = if (prefs.getString(devDateKey, "") == today) prefs.getInt(devCountKey, 0) else 0
        val nextDev = curDev + 1

        prefs.edit()
            .putString(dateKey, today)
            .putInt(countKey, nextAcc)
            .putString(devDateKey, today)
            .putInt(devCountKey, nextDev)
            .apply()

        return maxOf(nextAcc, nextDev)
    }

    fun getGeminiRemainingCallsToday(accountId: String = "", dailyLimit: Int = 5): Int {
        val effectiveLimit = minOf(dailyLimit, 5)
        return maxOf(0, effectiveLimit - getGeminiDailyCallsCount(accountId))
    }

    // 4-Hour Internet Warning Rate Limiter Rule
    fun shouldShowInternetWarning(): Boolean {
        val lastShown = prefs.getLong("last_internet_warning_ts", 0L)
        val now = System.currentTimeMillis()
        val fourHoursMillis = 4 * 60 * 60 * 1000L
        if (now - lastShown >= fourHoursMillis) {
            prefs.edit().putLong("last_internet_warning_ts", now).apply()
            return true
        }
        return false
    }

    // Unsynced Data & Change Tracking
    fun getLastSyncTimestamp(profileId: String): Long {
        return prefs.getLong("last_sync_ts_$profileId", 0L)
    }

    fun setLastSyncTimestamp(profileId: String, time: Long) {
        prefs.edit().putLong("last_sync_ts_$profileId", time).apply()
    }

    fun getLastDataModificationTimestamp(profileId: String): Long {
        return prefs.getLong("last_data_mod_ts_$profileId", 0L)
    }

    fun recordDataModification(profileId: String) {
        if (profileId.isNotBlank()) {
            prefs.edit().putLong("last_data_mod_ts_$profileId", System.currentTimeMillis()).apply()
        }
    }

    suspend fun markAllSessionsSynced(profileId: String) {
        sessionDao.markAllSessionsSynced(profileId)
    }

    data class UnsyncedDataSummary(
        val hasUnsynced: Boolean,
        val unsyncedSessionsCount: Int,
        val pendingOfflineChanges: Boolean,
        val message: String
    )

    suspend fun getUnsyncedSummary(): UnsyncedDataSummary {
        val pId = getActiveProfileId()
        if (pId.isBlank()) {
            return UnsyncedDataSummary(false, 0, false, "कोई सक्रिय खाता नहीं है")
        }
        val unsyncedSessions = sessionDao.getUnsyncedSessionCount(pId)
        val lastSync = getLastSyncTimestamp(pId)
        val lastMod = getLastDataModificationTimestamp(pId)

        val hasPending = unsyncedSessions > 0 || (lastMod > 0L && lastMod > lastSync)
        val msg = when {
            unsyncedSessions > 0 -> "⚠️ $unsyncedSessions सिंचाई सत्र अभी क्लाउड पर सिंक नहीं हुए हैं।"
            hasPending -> "⚠️ कुछ हालिया बदलाव अभी क्लाउड पर सिंक नहीं हुए हैं।"
            else -> "✅ सारा डेटा क्लाउड पर सुरक्षित सिंक है।"
        }
        return UnsyncedDataSummary(
            hasUnsynced = hasPending,
            unsyncedSessionsCount = unsyncedSessions,
            pendingOfflineChanges = hasPending,
            message = msg
        )
    }

    // Profile Operations
    val profileFlow: Flow<ProfileEntity?> = _activeProfileId.flatMapLatest { pId ->
        if (pId.isNotBlank()) {
            profileDao.getProfileByIdFlow(pId)
        } else {
            flowOf(null)
        }
    }

    suspend fun getProfileOnce(): ProfileEntity? {
        val pId = getActiveProfileId()
        return if (pId.isNotBlank()) {
            profileDao.getProfileById(pId)
        } else {
            null
        }
    }

    suspend fun getProfileByPhone(phone: String): ProfileEntity? {
        return profileDao.getProfileByPhone(phone)
    }

    suspend fun getProfileByEmail(email: String): ProfileEntity? {
        return profileDao.getProfileByEmail(email.trim().lowercase())
    }

    suspend fun saveProfile(profile: ProfileEntity) {
        profileDao.insertOrUpdateProfile(profile)
        setActiveProfileId(profile.id)
    }
    suspend fun migrateAllLocalDataToProfile(newProfileId: String) {
        customerDao.updateAllCustomerProfiles(newProfileId)
        sessionDao.updateAllSessionProfiles(newProfileId)
        transactionDao.updateAllTransactionProfiles(newProfileId)
    }

    suspend fun getAllCustomersOnce(): List<CustomerEntity> = customerDao.getAllCustomersOnce()
    suspend fun getAllSessionsOnce(): List<TubewellSessionEntity> = sessionDao.getAllSessionsOnce()
    suspend fun getAllTransactionsOnce(): List<TransactionEntity> = transactionDao.getAllTransactionsOnce()


    suspend fun updateEmail(profileId: String, email: String, isVerified: Boolean) {
        profileDao.updateEmail(profileId, email.trim().lowercase(), isVerified)
    }

    suspend fun updateRate(profileId: String, rate: Double) {
        profileDao.updateRate(profileId, rate)
    }

    suspend fun updatePin(profileId: String, newPin: String) {
        profileDao.updatePin(profileId, newPin)
    }

    suspend fun logout() {
        val currentId = getActiveProfileId()
        if (currentId == "demo_reviewer_profile") {
            try {
                profileDao.deleteProfileById("demo_reviewer_profile")
            } catch (_: Exception) {}
        }
        setActiveProfileId("")
    }

    // Customer Operations Scoped by active profile
    val allCustomersFlow: Flow<List<CustomerEntity>> = _activeProfileId.flatMapLatest { pId ->
        if (pId.isNotBlank()) {
            customerDao.getCustomersByProfile(pId)
        } else {
            flowOf(emptyList())
        }
    }

    fun getCustomerById(id: String): Flow<CustomerEntity?> = customerDao.getCustomerById(id)

    suspend fun getCustomerByIdOnce(id: String): CustomerEntity? = customerDao.getCustomerByIdOnce(id)

    suspend fun insertCustomer(customer: CustomerEntity) {
        val pId = if (customer.profileId.isNotBlank() && customer.profileId != "default") {
            customer.profileId
        } else {
            getActiveProfileId().ifBlank { "default" }
        }
        customerDao.insertCustomer(customer.copy(profileId = pId))
        recordDataModification(pId)
    }

    suspend fun insertCustomers(customers: List<CustomerEntity>) {
        val pId = getActiveProfileId().ifBlank { "default" }
        val updated = customers.map { c ->
            if (c.profileId.isNotBlank() && c.profileId != "default") c else c.copy(profileId = pId)
        }
        customerDao.insertCustomers(updated)
        recordDataModification(pId)
    }

    suspend fun updateCustomer(customer: CustomerEntity) {
        customerDao.updateCustomer(customer)
        val pId = customer.profileId.ifBlank { getActiveProfileId() }
        recordDataModification(pId)

        if (pId.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    SupabaseAuthService.pushSingleCustomer(pId, customer, context)
                } catch (e: Exception) {
                    android.util.Log.e("BahiKhataRepo", "Remote customer update error: ${e.message}")
                }
            }
        }
    }

    suspend fun deleteCustomer(id: String) {
        val pId = getActiveProfileId()
        // 1. Delete transactions and sessions locally for cascade cleanup
        transactionDao.deleteTransactionsForCustomer(id)
        sessionDao.deleteSessionsForCustomer(id)
        customerDao.deleteCustomer(id)
        recordDataModification(pId)

        // 2. Trigger remote cloud delete from Supabase
        if (pId.isNotBlank()) {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    SupabaseAuthService.deleteCustomerRemotely(pId, id, context)
                } catch (e: Exception) {
                    android.util.Log.e("BahiKhataRepo", "Remote customer delete error: ${e.message}")
                }
            }
        }
    }

    suspend fun getCustomersByProfileOnce(profileId: String): List<CustomerEntity> =
        customerDao.getCustomersByProfileOnce(profileId)

    // Session Operations Scoped by active profile
    val allSessionsFlow: Flow<List<TubewellSessionEntity>> = _activeProfileId.flatMapLatest { pId ->
        if (pId.isNotBlank()) {
            sessionDao.getSessionsByProfile(pId)
        } else {
            flowOf(emptyList())
        }
    }

    fun getSessionsForCustomer(customerId: String): Flow<List<TubewellSessionEntity>> {
        val pId = getActiveProfileId()
        return if (pId.isNotBlank()) {
            sessionDao.getSessionsForCustomerAndProfile(customerId, pId)
        } else {
            sessionDao.getSessionsForCustomer(customerId)
        }
    }

    suspend fun insertSession(session: TubewellSessionEntity) {
        val pId = if (session.profileId.isNotBlank() && session.profileId != "default") {
            session.profileId
        } else {
            getActiveProfileId().ifBlank { "default" }
        }
        val withProfile = session.copy(profileId = pId, isSynced = false)
        sessionDao.insertSession(withProfile)
        recordDataModification(pId)

        // Immediately push to cloud
        if (pId.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val ok = SupabaseAuthService.pushSingleSession(pId, withProfile, context)
                    if (ok) {
                        sessionDao.updateSession(withProfile.copy(isSynced = true))
                    }
                } catch (e: Exception) {
                    android.util.Log.e("BahiKhataRepo", "Remote session insert error: ${e.message}")
                }
            }
        }
    }

    suspend fun insertSessions(sessions: List<TubewellSessionEntity>) {
        val pId = getActiveProfileId().ifBlank { "default" }
        val updated = sessions.map { s ->
            if (s.profileId.isNotBlank() && s.profileId != "default") s else s.copy(profileId = pId)
        }
        sessionDao.insertSessions(updated)
        recordDataModification(pId)
    }

    suspend fun updateSession(session: TubewellSessionEntity) {
        val updated = session.copy(isSynced = false)
        sessionDao.updateSession(updated)
        val pId = updated.profileId.ifBlank { getActiveProfileId() }
        recordDataModification(pId)

        if (pId.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val ok = SupabaseAuthService.pushSingleSession(pId, updated, context)
                    if (ok) {
                        sessionDao.updateSession(updated.copy(isSynced = true))
                    }
                } catch (e: Exception) {
                    android.util.Log.e("BahiKhataRepo", "Remote session update error: ${e.message}")
                }
            }
        }
    }

    suspend fun deleteSession(id: String) {
        val pId = getActiveProfileId()
        sessionDao.deleteSession(id)
        recordDataModification(pId)

        if (pId.isNotBlank()) {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    SupabaseAuthService.deleteSessionRemotely(pId, id, context)
                } catch (e: Exception) {
                    android.util.Log.e("BahiKhataRepo", "Remote session delete error: ${e.message}")
                }
            }
        }
    }

    suspend fun getSessionsByProfileOnce(profileId: String): List<TubewellSessionEntity> =
        sessionDao.getSessionsByProfileOnce(profileId)

    // Rate: Return owner's default configured rate per hour
    suspend fun getSuggestedRate(customerId: String? = null): Double {
        val profile = getProfileOnce()
        return profile?.ratePerHour ?: 160.0
    }

    // Transaction Operations Scoped by active profile
    val allTransactionsFlow: Flow<List<TransactionEntity>> = _activeProfileId.flatMapLatest { pId ->
        if (pId.isNotBlank()) {
            transactionDao.getTransactionsByProfile(pId)
        } else {
            flowOf(emptyList())
        }
    }

    fun getTransactionsForCustomer(customerId: String): Flow<List<TransactionEntity>> {
        val pId = getActiveProfileId()
        return if (pId.isNotBlank()) {
            transactionDao.getTransactionsForCustomerAndProfile(customerId, pId)
        } else {
            transactionDao.getTransactionsForCustomer(customerId)
        }
    }

    suspend fun insertTransaction(transaction: TransactionEntity) {
        val pId = if (transaction.profileId.isNotBlank() && transaction.profileId != "default") {
            transaction.profileId
        } else {
            getActiveProfileId().ifBlank { "default" }
        }
        val withProfile = transaction.copy(profileId = pId)
        transactionDao.insertTransaction(withProfile)
        recordDataModification(pId)

        if (pId.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    SupabaseAuthService.pushSingleTransaction(pId, withProfile, context)
                } catch (e: Exception) {
                    android.util.Log.e("BahiKhataRepo", "Remote txn insert error: ${e.message}")
                }
            }
        }
    }

    suspend fun insertTransactions(transactions: List<TransactionEntity>) {
        val pId = getActiveProfileId().ifBlank { "default" }
        val updated = transactions.map { t ->
            if (t.profileId.isNotBlank() && t.profileId != "default") t else t.copy(profileId = pId)
        }
        transactionDao.insertTransactions(updated)
        recordDataModification(pId)
    }

    suspend fun updateTransaction(transaction: TransactionEntity) {
        transactionDao.updateTransaction(transaction)
        val pId = transaction.profileId.ifBlank { getActiveProfileId() }
        recordDataModification(pId)

        if (pId.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    SupabaseAuthService.pushSingleTransaction(pId, transaction, context)
                } catch (e: Exception) {
                    android.util.Log.e("BahiKhataRepo", "Remote txn update error: ${e.message}")
                }
            }
        }
    }

    suspend fun deleteTransaction(id: String) {
        val pId = getActiveProfileId()
        transactionDao.deleteTransaction(id)
        recordDataModification(pId)

        if (pId.isNotBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    SupabaseAuthService.deleteTransactionRemotely(pId, id, context)
                } catch (e: Exception) {
                    android.util.Log.e("BahiKhataRepo", "Remote txn delete error: ${e.message}")
                }
            }
        }
    }

    suspend fun getTransactionsByProfileOnce(profileId: String): List<TransactionEntity> =
        transactionDao.getTransactionsByProfileOnce(profileId)

    // 2-Way Supabase Sync
    suspend fun performSync(): SupabaseAuthService.SyncResult {
        var pId = getActiveProfileId()
        val currentProfile = getProfileOnce()
        if (pId.isBlank() && currentProfile != null) {
            pId = currentProfile.id
            setActiveProfileId(pId)
        }
        if (pId.isBlank()) {
            return SupabaseAuthService.SyncResult(false, "कोई सक्रिय प्रोफ़ाइल नहीं मिली! कृपया पहले लॉगिन करें।")
        }

        // Also push current profile if needed
        if (currentProfile != null) {
            try {
                SupabaseAuthService.signUp(currentProfile, context, this)
            } catch (e: Exception) {
                android.util.Log.d("BahiKhataRepo", "Profile push during sync: ${e.message}")
            }
        }

        val localCustomers = customerDao.getCustomersByProfileOnce(pId)
        val localSessions = sessionDao.getSessionsByProfileOnce(pId)
        val localTxns = transactionDao.getTransactionsByProfileOnce(pId)

        val result = SupabaseAuthService.syncUserData(pId, localCustomers, localSessions, localTxns, context)
        if (result.success) {
            markAllSessionsSynced(pId)
            setLastSyncTimestamp(pId, System.currentTimeMillis())

            // 1. Purge Tombstoned Records (If any other device deleted them, wipe from this phone too)
            if (result.deletedCustomerIds.isNotEmpty()) {
                result.deletedCustomerIds.forEach { cId ->
                    transactionDao.deleteTransactionsForCustomer(cId)
                    sessionDao.deleteSessionsForCustomer(cId)
                    customerDao.deleteCustomer(cId)
                }
                android.util.Log.d("BahiKhataRepo", "Purged ${result.deletedCustomerIds.size} tombstoned customers locally")
            }
            if (result.deletedSessionIds.isNotEmpty()) {
                result.deletedSessionIds.forEach { sId ->
                    sessionDao.deleteSession(sId)
                }
                android.util.Log.d("BahiKhataRepo", "Purged ${result.deletedSessionIds.size} tombstoned sessions locally")
            }
            if (result.deletedTransactionIds.isNotEmpty()) {
                result.deletedTransactionIds.forEach { tId ->
                    transactionDao.deleteTransaction(tId)
                }
                android.util.Log.d("BahiKhataRepo", "Purged ${result.deletedTransactionIds.size} tombstoned transactions locally")
            }

            // 2. Insert fresh pulled records from cloud
            if (result.pulledCustomers.isNotEmpty()) {
                customerDao.insertCustomers(result.pulledCustomers)
            }
            if (result.pulledSessions.isNotEmpty()) {
                sessionDao.insertSessions(result.pulledSessions)
            }
            if (result.pulledTransactions.isNotEmpty()) {
                transactionDao.insertTransactions(result.pulledTransactions)
            }
        }
        return result
    }

    suspend fun seedDemoReviewData() {
        val demoProfile = ProfileEntity(
            id = "demo_reviewer_profile",
            name = "Kisan Ramchandra",
            agencyName = "Kisan Tubewell & Sinchai Seva",
            phone = "9876543210",
            ratePerHour = 160.0,
            pinHash = "1234"
        )
        saveProfile(demoProfile)
        setActiveProfileId(demoProfile.id)

        val pId = demoProfile.id
        val balwan = CustomerEntity(
            id = "cust_balwan_singh",
            profileId = pId,
            name = "Balwan Singh",
            sO = "Ranveer Singh",
            phone = "9812345678",
            avatarBgColor = 0xFF1B5E20,
            initialBalance = 1500.0,
            createdAt = System.currentTimeMillis() - (10 * 24 * 3600 * 1000L)
        )
        val mukesh = CustomerEntity(
            id = "cust_mukesh_kumar",
            profileId = pId,
            name = "Mukesh Kumar",
            sO = "Mahaveer Prasad",
            phone = "9876501234",
            avatarBgColor = 0xFFE65100,
            initialBalance = 3200.0,
            createdAt = System.currentTimeMillis() - (8 * 24 * 3600 * 1000L)
        )
        val ramesh = CustomerEntity(
            id = "cust_ramesh_kumar",
            profileId = pId,
            name = "Ramesh Kumar",
            sO = "Surajbhan",
            phone = "9823456781",
            avatarBgColor = 0xFFC62828,
            initialBalance = 0.0,
            createdAt = System.currentTimeMillis() - (5 * 24 * 3600 * 1000L)
        )
        val suresh = CustomerEntity(
            id = "cust_suresh_sharma",
            profileId = pId,
            name = "Suresh Sharma",
            sO = "Pandit Radhe",
            phone = "9811223344",
            avatarBgColor = 0xFF0D47A1,
            initialBalance = 0.0,
            createdAt = System.currentTimeMillis() - (3 * 24 * 3600 * 1000L)
        )

        customerDao.insertCustomers(listOf(balwan, mukesh, ramesh, suresh))

        val session1 = TubewellSessionEntity(
            id = "sess_demo_1",
            profileId = pId,
            customerId = balwan.id,
            hours = 5.0,
            rate = 160.0,
            totalAmount = 800.0,
            paidAmount = 500.0,
            dueAmount = 300.0,
            sessionDate = System.currentTimeMillis() - (2 * 24 * 3600 * 1000L),
            note = "धान सिंचाई"
        )
        val session2 = TubewellSessionEntity(
            id = "sess_demo_2",
            profileId = pId,
            customerId = ramesh.id,
            hours = 4.5,
            rate = 160.0,
            totalAmount = 720.0,
            paidAmount = 200.0,
            dueAmount = 520.0,
            sessionDate = System.currentTimeMillis() - (1 * 24 * 3600 * 1000L),
            note = "गेहूं सिंचाई"
        )
        sessionDao.insertSessions(listOf(session1, session2))
    }
}
